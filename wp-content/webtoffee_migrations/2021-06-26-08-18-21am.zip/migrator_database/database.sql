

DROP TABLE IF EXISTS `webtoffee_commentmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_comments` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_comments VALUES
("1","1","A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2021-06-24 10:07:15","2021-06-24 10:07:15","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","comment","0","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_links` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_ms_snippets` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_ms_snippets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tags` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scope` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `priority` smallint(6) NOT NULL DEFAULT 10,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_options` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_options VALUES
("1","siteurl","http://localhost/wordpress","yes"),
("2","home","http://localhost/wordpress","yes"),
("3","blogname","Wordpress_tutorials","yes"),
("4","blogdescription","Just another WordPress site","yes"),
("5","users_can_register","0","yes"),
("6","admin_email","admin@gmail.com","yes"),
("7","start_of_week","1","yes"),
("8","use_balanceTags","0","yes"),
("9","use_smilies","1","yes"),
("10","require_name_email","1","yes"),
("11","comments_notify","1","yes"),
("12","posts_per_rss","10","yes"),
("13","rss_use_excerpt","0","yes"),
("14","mailserver_url","mail.example.com","yes"),
("15","mailserver_login","login@example.com","yes"),
("16","mailserver_pass","password","yes"),
("17","mailserver_port","110","yes"),
("18","default_category","1","yes"),
("19","default_comment_status","open","yes"),
("20","default_ping_status","open","yes"),
("21","default_pingback_flag","1","yes"),
("22","posts_per_page","10","yes"),
("23","date_format","F j, Y","yes"),
("24","time_format","g:i a","yes"),
("25","links_updated_date_format","F j, Y g:i a","yes"),
("26","comment_moderation","0","yes"),
("27","moderation_notify","1","yes"),
("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes"),
("29","rewrite_rules","a:95:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=7&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes"),
("30","hack_file","0","yes"),
("31","blog_charset","UTF-8","yes"),
("32","moderation_keys","","no"),
("33","active_plugins","a:2:{i:0;s:31:\"code-snippets/code-snippets.php\";i:1;s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";}","yes"),
("34","category_base","","yes"),
("35","ping_sites","http://rpc.pingomatic.com/","yes"),
("36","comment_max_links","2","yes"),
("37","gmt_offset","0","yes"),
("38","default_email_category","1","yes"),
("39","recently_edited","a:3:{i:0;s:62:\"C:\\xampp\\htdocs\\wordpress/wp-content/themes/sinatra/header.php\";i:2;s:61:\"C:\\xampp\\htdocs\\wordpress/wp-content/themes/sinatra/style.css\";i:3;s:0:\"\";}","no"),
("40","template","sinatra","yes"),
("41","stylesheet","sinatra","yes"),
("42","comment_registration","0","yes"),
("43","html_type","text/html","yes"),
("44","use_trackback","0","yes"),
("45","default_role","subscriber","yes"),
("46","db_version","49752","yes"),
("47","uploads_use_yearmonth_folders","1","yes"),
("48","upload_path","","yes"),
("49","blog_public","1","yes"),
("50","default_link_category","2","yes"),
("51","show_on_front","page","yes"),
("52","tag_base","","yes"),
("53","show_avatars","1","yes"),
("54","avatar_rating","G","yes"),
("55","upload_url_path","","yes"),
("56","thumbnail_size_w","150","yes"),
("57","thumbnail_size_h","150","yes"),
("58","thumbnail_crop","1","yes"),
("59","medium_size_w","300","yes"),
("60","medium_size_h","300","yes"),
("61","avatar_default","mystery","yes"),
("62","large_size_w","1024","yes"),
("63","large_size_h","1024","yes"),
("64","image_default_link_type","none","yes"),
("65","image_default_size","","yes"),
("66","image_default_align","","yes"),
("67","close_comments_for_old_posts","0","yes"),
("68","close_comments_days_old","14","yes"),
("69","thread_comments","1","yes"),
("70","thread_comments_depth","5","yes"),
("71","page_comments","0","yes"),
("72","comments_per_page","50","yes"),
("73","default_comments_page","newest","yes"),
("74","comment_order","asc","yes"),
("75","sticky_posts","a:0:{}","yes"),
("76","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes"),
("77","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes"),
("78","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes"),
("79","uninstall_plugins","a:0:{}","no"),
("80","timezone_string","","yes"),
("81","page_for_posts","0","yes"),
("82","page_on_front","7","yes"),
("83","default_post_format","0","yes"),
("84","link_manager_enabled","0","yes"),
("85","finished_splitting_shared_terms","1","yes"),
("86","site_icon","0","yes"),
("87","medium_large_size_w","768","yes"),
("88","medium_large_size_h","0","yes"),
("89","wp_page_for_privacy_policy","3","yes"),
("90","show_comments_cookies_opt_in","1","yes"),
("91","admin_email_lifespan","1640081226","yes"),
("92","disallowed_keys","","no"),
("93","comment_previously_approved","1","yes"),
("94","auto_plugin_theme_update_emails","a:0:{}","no"),
("95","auto_update_core_dev","enabled","yes"),
("96","auto_update_core_minor","enabled","yes"),
("97","auto_update_core_major","enabled","yes"),
("98","initial_db_version","49752","yes"),
("99","webtoffee_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes"),
("100","fresh_site","0","yes");/*END*/
INSERT INTO webtoffee_options VALUES
("101","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes"),
("102","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes"),
("103","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes"),
("104","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes"),
("105","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes"),
("106","sidebars_widgets","a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:20:\"custom-header-widget\";a:1:{i:0;s:13:\"media_image-2\";}s:15:\"sinatra-sidebar\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:16:\"sinatra-footer-1\";a:0:{}s:16:\"sinatra-footer-2\";a:0:{}s:16:\"sinatra-footer-3\";a:0:{}s:16:\"sinatra-footer-4\";a:0:{}s:13:\"array_version\";i:3;}","yes"),
("107","cron","a:7:{i:1624698438;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1624702037;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1624702038;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1624702111;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1624702113;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1625220437;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","yes"),
("108","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("109","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("110","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("111","widget_media_image","a:2:{i:2;a:15:{s:4:\"size\";s:4:\"full\";s:5:\"width\";i:271;s:6:\"height\";i:186;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:24:\"https://www.facebook.com\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";s:13:\"attachment_id\";i:45;s:3:\"url\";s:64:\"http://localhost/wordpress/wp-content/uploads/2021/06/images.jpg\";s:5:\"title\";s:8:\"FaceBook\";}s:12:\"_multiwidget\";i:1;}","yes"),
("112","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("113","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("114","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("115","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("116","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes"),
("118","recovery_keys","a:1:{s:22:\"UjyQhyrISDmijWIz3mvSvC\";a:2:{s:10:\"hashed_key\";s:34:\"$P$Bp8qSasfbplt9v4DpxKNeheg9TMyFT0\";s:10:\"created_at\";i:1624682387;}}","yes"),
("119","theme_mods_twentytwentyone","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1624530008;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}","yes"),
("121","https_detection_errors","a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}","yes"),
("122","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.7.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.7.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1624695407;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}","no"),
("128","_site_transient_timeout_browser_d57bf7af33bc5b7923c68ca46271944f","1625134112","no"),
("129","_site_transient_browser_d57bf7af33bc5b7923c68ca46271944f","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"91.0.4472.114\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no"),
("130","_site_transient_timeout_php_check_dcf448a31f072675e98776ba60f55c18","1625134113","no"),
("131","_site_transient_php_check_dcf448a31f072675e98776ba60f55c18","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no"),
("134","can_compress_scripts","1","no"),
("149","finished_updating_comment_type","1","yes"),
("151","_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1624695415;s:7:\"checked\";a:4:{s:7:\"sinatra\";s:5:\"1.2.1\";s:14:\"twentynineteen\";s:3:\"2.0\";s:12:\"twentytwenty\";s:3:\"1.7\";s:15:\"twentytwentyone\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:4:{s:7:\"sinatra\";a:6:{s:5:\"theme\";s:7:\"sinatra\";s:11:\"new_version\";s:5:\"1.2.1\";s:3:\"url\";s:37:\"https://wordpress.org/themes/sinatra/\";s:7:\"package\";s:55:\"https://downloads.wordpress.org/theme/sinatra.1.2.1.zip\";s:8:\"requires\";s:3:\"5.0\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.0.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.7.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.3.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}","no"),
("152","current_theme","Sinatra","yes"),
("153","theme_mods_sinatra","a:19:{i:0;b:0;s:18:\"custom_css_post_id\";i:52;s:18:\"nav_menu_locations\";a:1:{s:15:\"sinatra-primary\";i:2;}s:28:\"sinatra_single_post_elements\";a:6:{s:5:\"thumb\";b:1;s:8:\"category\";b:1;s:4:\"tags\";b:1;s:12:\"last-updated\";b:1;s:12:\"about-author\";b:1;s:14:\"prev-next-post\";b:1;}s:30:\"sinatra_header_heading_widgets\";b:1;s:37:\"sinatra_header_heading_design_options\";b:1;s:25:\"sinatra_header_background\";a:17:{s:15:\"background-type\";s:8:\"gradient\";s:16:\"background-color\";s:7:\"#FFFFFF\";s:16:\"background-image\";s:0:\"\";s:17:\"background-repeat\";s:9:\"no-repeat\";s:21:\"background-position-x\";i:50;s:21:\"background-position-y\";i:50;s:15:\"background-size\";s:5:\"cover\";s:21:\"background-attachment\";s:7:\"inherit\";s:19:\"background-image-id\";s:0:\"\";s:24:\"background-color-overlay\";s:15:\"rgba(0,0,0,0.5)\";s:16:\"gradient-color-1\";s:7:\"#0c0005\";s:25:\"gradient-color-1-location\";d:0;s:16:\"gradient-color-2\";s:7:\"#3A6073\";s:25:\"gradient-color-2-location\";d:100;s:13:\"gradient-type\";s:6:\"linear\";s:21:\"gradient-linear-angle\";d:45;s:17:\"gradient-position\";s:13:\"center center\";}s:11:\"custom_logo\";i:31;s:24:\"sinatra_sidebar_position\";s:10:\"no-sidebar\";s:34:\"sinatra_main_nav_heading_animation\";b:1;s:34:\"sinatra_main_nav_heading_sub_menus\";b:0;s:36:\"sinatra_main_nav_heading_mobile_menu\";b:0;s:26:\"sinatra_nav_design_options\";b:1;s:27:\"sinatra_main_nav_font_color\";a:3:{s:10:\"text-color\";s:0:\"\";s:10:\"link-color\";s:7:\"#ffffff\";s:16:\"link-hover-color\";s:0:\"\";}s:21:\"sinatra_header_layout\";s:8:\"layout-1\";s:22:\"sinatra_header_widgets\";a:0:{}s:21:\"sinatra_enable_footer\";b:0;s:33:\"sinatra_copyright_heading_widgets\";b:0;s:40:\"sinatra_copyright_heading_design_options\";b:1;}","yes"),
("154","theme_switched","","yes"),
("155","_transient_sinatra_has_dynamic_css","1","yes"),
("156","sinatra-theme-updater","1.2.1","yes"),
("162","recovery_mode_email_last_sent","1624682386","yes"),
("165","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes"),
("175","_transient_health-check-site-status-result","{\"good\":\"14\",\"recommended\":\"5\",\"critical\":\"1\"}","yes"),
("176","_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e","1624731802","no"),
("177","_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e","a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:1:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:69:\"Watch Party + Discussion group: How to Create and Use Reusable Blocks\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/278699399/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-06-25 07:00:00\";s:8:\"end_date\";s:19:\"2021-06-25 08:00:00\";s:20:\"start_unix_timestamp\";i:1624629600;s:18:\"end_unix_timestamp\";i:1624633200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}}}","no"),
("178","_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3","1624716863","no"),
("179","_transient_feed_9bbd59226dc36b9b26cd43f15694c5c3","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Jun 2021 17:14:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.8-beta3-51237\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.8 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Jun 2021 17:14:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10855\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:331:\"WordPress 5.8 Beta 4 is now available for testing! This software is still in development,&#160;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it. You can test the WordPress 5.8 Beta 4 in three ways: Install/activate the WordPress Beta Tester plugin (select [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Jeffrey Paul\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4104:\"
<p>WordPress 5.8 Beta 4 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 4 in three ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the&nbsp;<code>Bleeding edge</code>&nbsp;channel and the&nbsp;<code>Beta/RC Only</code> stream).</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta4.zip\">zip</a>).</li><li>Using WP-CLI to test: <code>wp core update --version=5.8-beta4</code></li></ul>



<p>The current target for the final release is July 20, 2021. That’s less than <strong>four weeks away</strong>, so we need your help to make sure the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\" data-type=\"post\">Beta 3</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=06%2F24%2F2021..06%2F26%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">18</a> bugs have been fixed. Most tickets focused on polishing existing default themes, fixing bugs in the new block Widget screen, and squashing Editor bugs collected during beta.</p>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=..06%2F25%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">254 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;changetime=..06%2F25%2F2021&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=changetime&amp;col=owner&amp;col=priority&amp;col=keywords&amp;order=changetime\">91 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\'https://profiles.wordpress.org/desrosj/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>desrosj</a> <a href=\'https://profiles.wordpress.org/clorith/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>clorith</a> for reviews and <a href=\'https://profiles.wordpress.org/chanthaboune/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chanthaboune</a> for final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Releasing software<br>Is complex when open source<br>Yet WordPressers do</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10855\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.8 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Jun 2021 02:36:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10843\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:331:\"WordPress 5.8 Beta 3 is now available for testing! This software is still in development,&#160;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it. You can test the WordPress 5.8 Beta 3 in three ways: Install/activate the WordPress Beta Tester plugin (select [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5777:\"
<p>WordPress 5.8 Beta 3 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 3 in three ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the&nbsp;<code>Bleeding edge</code>&nbsp;channel and the&nbsp;<code>Beta/RC Only</code> stream).</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta3.zip\">zip</a>).</li><li>Using WP-CLI to test: <code>wp core update --version=5.8-beta3</code></li></ul>



<p>The current target for the final release is July 20, 2021. That’s just <strong>four weeks away</strong>, so we need your help to make the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-2/\" data-type=\"post\">Beta 2</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=06%2F16%2F2021..06%2F23%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">38</a> bugs have been fixed. Here is a summary of some of the included changes:</p>



<ul><li>Block Editor: Move caching to endpoint for unique responses. (<a href=\"https://core.trac.wordpress.org/ticket/53435\">#53435</a>)</li><li>Bundled Themes: Improve display of blocks in widget areas. (<a href=\"https://core.trac.wordpress.org/ticket/53422\">#53422</a>)</li><li>Coding Standards: Bring some consistency to HTML formatting in <code>wp-admin/comment.php</code>. (<a href=\"https://core.trac.wordpress.org/ticket/52627\">#52627</a>)</li><li>Editor: Include Cover block in the list of block types registered using metadata files. (<a href=\"https://core.trac.wordpress.org/ticket/53440\">#53440</a>)</li><li>Editor: Include Cover block in the list of block types registered using metadata files. (<a href=\"https://core.trac.wordpress.org/ticket/53440\">#53440</a>)</li><li>Media: Add new functions to return the previous/next attachment links. (<a href=\"https://core.trac.wordpress.org/ticket/45708\">#45708</a>)</li><li>Media: Improve upload page media item layout on smaller screens. (<a href=\"https://core.trac.wordpress.org/ticket/51754\">#51754</a>)</li><li>Media: Update total attachment count when media added or removed. (<a href=\"https://core.trac.wordpress.org/ticket/53171\">#53171</a>)</li><li>REST API: Decode single and double quote entities in widget names and descriptions. (<a href=\"https://core.trac.wordpress.org/ticket/53407\">#53407</a>)</li><li>Twenty Nineteen: Update margins on full- and wide-aligned blocks in the editor. (<a href=\"https://core.trac.wordpress.org/ticket/53428\">#53428</a>)</li><li>Widgets: Add editor styles to the widgets block editor. (<a href=\"https://core.trac.wordpress.org/ticket/53344\">#53344</a>)</li></ul>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=..06%2F23%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">254 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;changetime=..06%2F23%2F2021&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=changetime&amp;col=owner&amp;col=priority&amp;col=keywords&amp;order=changetime\">91 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\'https://profiles.wordpress.org/jeffpaul/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>jeffpaul</a> <a href=\'https://profiles.wordpress.org/desrosj/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>desrosj</a> <a href=\'https://profiles.wordpress.org/hellofromtonya/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>hellofromtonya</a> <a href=\'https://profiles.wordpress.org/pbiron/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>pbiron</a> for reviews and final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Esperanza first.<br>Want to know the next jazzer?<br>Then please test beta.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10843\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:55:\"
		
		
		
		
		
				

					
										
					
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WP Briefing: Episode 11: WordCamp Europe 2021 in Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wordpress.org/news/2021/06/episode-11-wordcamp-europe-2021-in-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Jun 2021 12:33:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10837\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:364:\"In this episode, Josepha Haden Chomphosy does a mini deep dive into WordCamp Europe 2021, specifically the conversation between the project’s co-founder, Matt Mullenweg, and Brian Krogsgard formerly of PostStatus. Tune in to hear her take and for this episode’s small list of big things. Have a question you&#8217;d like answered? You can submit them [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://wordpress.org/news/files/2021/06/WP-Briefing-011.mp3\";s:6:\"length\";s:1:\"0\";s:4:\"type\";s:0:\"\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:10500:\"
<p>In this episode, Josepha Haden Chomphosy does a mini deep dive into WordCamp Europe 2021, specifically the conversation between the project’s co-founder, Matt Mullenweg, and Brian Krogsgard formerly of PostStatus. Tune in to hear her take and for this episode’s small list of big things.</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<p>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></p>



<p>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></p>



<p>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></p>



<p>Song: Fearless First by Kevin MacLeod</p>



<h2>References </h2>



<p><a href=\"https://wordpress.org/news/2021/06/gutenberg-highlights/\">Gutenberg Highlights&nbsp;</a></p>



<p><a href=\"https://www.youtube.com/watch?v=o-IvKy3322k&amp;t=12428s\">Matt Mullenweg in conversation with Brian Krogsgard&nbsp;</a></p>



<p><a href=\"https://make.wordpress.org/core/5-8/\">5.8 Development Cycle</a></p>



<p><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></p>



<p><a href=\"https://europe.wordcamp.org/2021/a-recap-on-wceu-2021/\">A recap on WCEU 2021</a></p>



<h2>Transcript</h2>



<span id=\"more-10837\"></span>



<p><strong>Josepha Haden Chomphosy 00:10</strong></p>



<p>Hello, everyone, and welcome to the WordPress Briefing, the podcast where you can catch quick explanations of the ideas behind the WordPress open source project, some insights into the community that supports it, and get a small list of big things coming up in the next two weeks. I&#8217;m your host, Josepha Haden Chomphosy. Here we go!</p>



<p><strong>Josepha Haden Chomphosy 00:40</strong></p>



<p>A couple of weeks ago, we hosted WordCamp Europe and had the double pleasure of a demo that showed us a bit about the future of WordPress and an interview that looked back while also looking a bit forward. If you haven&#8217;t seen the demo, it was beautiful. And I&#8217;ve included a link to it in the show notes. And if you haven&#8217;t heard the interview, there were a few specific moments that I&#8217;d like to take the time to delve into a little more. Brian Krogsgard, in his conversation with Matt Mullenweg, brought up three really interesting points. I mean, he brought up a lot of interesting points, but there were three that I would particularly like to look into today. The first was about balance. The second was about cohesion. And the third was about those we leave behind.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 01:24</strong></p>



<p>So first is this question of balance. Brian brought this up in the context of the overall economic health of the WordPress ecosystem. And in that particular moment, he talked about companies that are coming together, companies that are merging. And in Matt&#8217;s answer, the part that I found the most interesting was when he said, &#8220;the point at which there is the most commercial opportunity is also the point at which there is the most opportunity for short-termism. He went on to talk about the importance of long-term thinking and collective thinking about what makes us, and us here means probably the WordPress project, more vibrant and vital in 10 or 20 or 30 years. One of the things that he specifically called out in that answer was the responsibility of larger companies in the ecosystem. For instance, like Automattic, to commit fully to giving back, there are many ways now that companies can give back to WordPress so that we all replenish the Commons. They can pay for volunteer contributors&#8217; time; they can create and sponsor entire teams through the Five for the Future program. They can contribute time through our outreach program. And they can even contribute to WordPress&#8217;s ability to own our own voice by engaging their audience&#8217;s awareness of what&#8217;s next in WordPress, or whatever. And I know this balance, this particular balance of paid contributors or sponsored contributors, compared to our volunteer contributors or self-sponsored contributors; I know that this balance is one that people keep an eagle eye on. I am consistently on a tight rope to appropriately balanced those voices. But as with so many things where balance is key, keeping an eye on the middle or the long-distance can really help us get it right.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 03:23</strong></p>



<p>The second question was one of cohesion and specifically cohesion over the competition. Brian asked how, if people feel disadvantaged, you can foster a feeling of cohesion rather than competition? And Matt&#8217;s first answer was that competition is great. Specifically, he said that competition is great as long as you consider where your collaboration fits into the mission. And he also spent some time exploring how competitors in the ecosystem can still work from a community-first mindset. I personally cannot agree enough about some of the benefits of collaboration alongside your competitors. I remind sponsored contributors from time to time, and I think it&#8217;s true for any contributor that you are an employee of your company first and a contributor to WordPress second. However, once you step into contribution time, your main concern is the users of WordPress, or new contributors, or the health of the WordPress ecosystem as a whole or the WordPress project. So you get all this subject matter expertise from competitive forces, collaborating in a very us versus the problem way. And when you do that, you&#8217;re always going to find a great solution. It may not be as fast as you want it to build things out in the open in public. And so sometimes we get it wrong and have to come back and fix it but still, given time, we&#8217;re going to come out with the best solution because we have so many skilled people working on this.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 05:01</strong></p>



<p>And then the third question that I wanted to really touch on is the question of those we leave behind. Brian asked Matt if he thought mid-sized agencies and mid-sized consultants were being squeezed out with the block editor. Matt&#8217;s high-level answer was no, and I tend to agree with him. It&#8217;s not all mid-sized anything any more than it&#8217;s all small-sized anything. His answer continued to look at what stands to change for users with the block editor and who really can stand to benefit. It made me think back to my WordPress 5.0 listening tour. We launched WordPress 5.0, which was, in case anyone forgets, the first release with the block editor in it. I took a six-month-long tour to anywhere that WordPressers were so I could hear their main worries, what Brian is saying in there, and what Matt is saying to really came up all the time in those conversations. And basically, it was that this update takes all the power away from people who are building websites. And in these conversations, and Matt and Brian&#8217;s conversation, it was really focused on our freelancers and consultants. But at the same time, all of them heard that this update gives power back to all of the people who could build websites.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 06:28</strong></p>



<p>I could not shake the feeling at the time. And honestly, I can&#8217;t shake it now that no high-end consultants, or freelancers, or any other developer or site creator sit around just longing for maintenance work. After six months of talking to people, I didn&#8217;t hear anyone say, &#8220;you know, I just love making the same author card over and over and over.&#8221; Or, &#8220;updated the footer every week, this month. And that&#8217;s why I got into this business.&#8221; And more than the feeling that there just wasn&#8217;t anyone who just loved maintenance, I got a feeling that there were real problems that needed to be solved for these clients and that they wanted to solve them. And that they also would gladly trade updating footers for the much more interesting work of creating modern and stylish business hubs based on WordPress for the clients who trust them so much. All of that, I guess, is to say that, yes, the block editor does give power back to our clients again, but not at the expense of those who have to build the sites in the first place. I think it stands to restore everyone&#8217;s sense of agency more than we truly realize. So that&#8217;s my deep dive on WordCamp Europe; I included links to the demo and the talk below, just in case you haven&#8217;t seen them yet. And you want to get a little bit of insight into the full context of the conversations that I just did a bit of a deep dive into.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 08:15</strong></p>



<p>And now it&#8217;s time for our smallest of big things. All right, I have three things for you today. Number one, tomorrow, we package WordPress 5.8 beta three. If you&#8217;ve never had a chance to stop by the core channel in slack for the past packaging process, I really encourage you to stop by; we call them release parties. It&#8217;s a bunch of people who stand around and help get it done. So you can also see how it gets done. And if you&#8217;re feeling brave, you can even try your hand at testing out one of the packages as soon as it&#8217;s ready. The second thing is that a week from tomorrow, we reach our first release candidate milestone. So if you have meant to submit any bugs or patches or if you&#8217;ve been procrastinating on documentation, or dev notes, right now is the time so that we can have a chance to get everything into the release by the time we reach the release candidate milestone on the 29th. And the third thing is that we are currently right in the middle of WordCamp Japan. That is a great opportunity to meet some contributors and maybe even get started with contributions yourself. So stop by if you haven&#8217;t had a chance to check it out already. I will leave a link in the show notes. And that, my friends, is your small list of big things. </p>



<p>Thank you for tuning in today for the WordPress Briefing. I&#8217;m your host, Josepha Haden Chomphosy, and I&#8217;ll see you again in a couple of weeks.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10837\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.8 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Jun 2021 18:34:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10808\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:344:\"WordPress 5.8 Beta 2 is now available for testing! This software is still in development,&#160;so it’s not recommended to run this version on a production site. Consider setting up a test site to play with it. You can test the WordPress 5.8 Beta 2 in two ways: Install/activate the WordPress Beta Tester plugin (select the Bleeding [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Jonathan Desrosiers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6174:\"
<p>WordPress 5.8 Beta 2 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it’s not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 2 in two ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the <code>Bleeding edge</code> channel and the <code>Beta/RC Only</code> stream)</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta2.zip\">zip</a>).</li></ul>



<p>The current target for the final release is July 20, 2021. That’s just <strong>five weeks away</strong>, so your help is vital to ensure that the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\" data-type=\"post\" data-id=\"10733\">Beta 1</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=06%2F09%2F2021..06%2F15%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">26</a> bugs have been fixed. Here is a summary of some of the included changes:</p>



<ul><li>Block Editor: Remove bundled block patterns and support the patterns directory. (<a href=\"https://core.trac.wordpress.org/ticket/53246\">#53246</a>)</li><li>Block Editor: Add a type property to allow Core to identify the source of the editor styles. (<a href=\"https://core.trac.wordpress.org/ticket/53175\">#53175</a>)</li><li>Build/Test Tools: Adds some tests for Quick Draft section in Dashboard. (<a href=\"https://core.trac.wordpress.org/ticket/52905\">#52905</a>)</li><li>Build/Test Tools: Replaced <code>@babel/polyfill</code> with <code>core-js/stable</code>. (<a href=\"https://core.trac.wordpress.org/ticket/52941\">#52941</a>)</li><li>Coding Standards: Further update the code for bulk menu items deletion to better follow WordPress coding standards. (<a href=\"https://core.trac.wordpress.org/ticket/21603\">#21603</a>)</li><li>External Libraries: Update Underscore to version 1.13.1. (<a href=\"https://core.trac.wordpress.org/ticket/45785\">#45785</a>)</li><li>General: A number of block editor, template mode and widget screen related fixes. (<a href=\"https://core.trac.wordpress.org/changeset/51149\">#51149</a>)</li><li>Login and Registration: Improve the unknown username error message. (<a href=\"https://core.trac.wordpress.org/ticket/52915\">#52915</a>)</li><li>Media: Restore AJAX response data shape in media library. (<a href=\"https://core.trac.wordpress.org/ticket/50105\">#50105</a>)</li><li>Site Health: Display a list of file formats supported by the GD library. (<a href=\"https://core.trac.wordpress.org/ticket/53022\">#53022</a>)</li><li><span style=\"color: initial;, sans-serif\">Twemoji: It&#8217;s the new one! (</span><a href=\"https://core.trac.wordpress.org/ticket/52852\">#52852</a>)</li></ul>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=..06%2F15%2F2021&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">214 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;changetime=..06%2F15%2F2021&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;group=component&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=changetime&amp;col=owner&amp;col=priority&amp;col=keywords&amp;order=changetime\">87 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\'https://profiles.wordpress.org/chanthaboune/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chanthaboune</a> for revision, <a href=\'https://profiles.wordpress.org/webcommsat/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>webcommsat</a>, <a href=\'https://profiles.wordpress.org/youknowriad/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>youknowriad</a>, <a href=\'https://profiles.wordpress.org/jorbin/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>jorbin</a>, <a href=\'https://profiles.wordpress.org/felipeelia/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>felipeelia</a> , and <a href=\'https://profiles.wordpress.org/jeffpaul/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>jeffpaul</a> for proofreading, and <a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a> for final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Install won’t you please<br>WordPress 5-8 Beta 2?<br>We need your help: test!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10808\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Gutenberg Highlights\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/gutenberg-highlights/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Jun 2021 11:03:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10779\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:346:\"During WordCamp Europe this past Wednesday Matt and I gathered to discuss the latest developments of Gutenberg and to share a video with some of the current and upcoming highlights. The video is wonderfully narrated by @beafialho and it was a great opportunity to celebrate all the incredible work that contributors are doing around the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matias Ventura\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1386:\"
<p>During <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a> this past Wednesday Matt and I gathered to discuss the latest developments of Gutenberg and to share a video with some of the current and upcoming highlights. The video is wonderfully narrated by <a href=\'https://profiles.wordpress.org/beafialho/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>beafialho</a> and it was a great opportunity to celebrate all the incredible work that contributors are doing around the globe to improve the editing and customization experience of WordPress. For those that weren&#8217;t able to attend live it&#8217;s now available for watching online.</p>



<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-4-3 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">
<iframe class=\'youtube-player\' width=\'632\' height=\'356\' src=\'https://www.youtube.com/embed/a1Sf7PxfmLQ?version=3&#038;rel=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;fs=1&#038;hl=en-US&#038;autohide=2&#038;wmode=transparent\' allowfullscreen=\'true\' style=\'border:0;\' sandbox=\'allow-scripts allow-same-origin allow-popups allow-presentation\'></iframe>
</div></figure>



<p>Matt also opened a thread for questions <a href=\"https://ma.tt/2021/06/wceu-open-thread/\">on his blog</a>, so be sure to chime in there if you have any!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10779\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:63:\"
		
		
		
		
		
				
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.8 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Jun 2021 02:47:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"5.8\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10733\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"WordPress 5.8 Beta 1 is now available for testing!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Jeffrey Paul\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:10110:\"
<p>WordPress 5.8 Beta 1 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Instead, we recommend that you run this on a test site to play with the new version.</p>



<p>You can test the WordPress 5.8 Beta 1 in two ways:</p>



<ul><li>Install and activate the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (select the “Bleeding edge” channel and &#8220;Beta/RC Only&#8221; stream).</li><li>Direct download the <a href=\"https://wordpress.org/wordpress-5.8-beta1.zip\">beta version here&nbsp;(zip)</a>.</li></ul>



<p>The current target for the final release is July 20, 2021.  This is just&nbsp;<strong>six weeks away</strong>, so your help is vital to ensure this release is tested properly and as good as it can be.</p>



<p>Keep your eyes on the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;for&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a>&nbsp;in the coming weeks, breaking down these and other changes in greater detail.</p>



<p>So what&#8217;s new in this 5.8?  Let&#8217;s start with some highlights.</p>



<h2>Highlights</h2>



<h3>Powerful Blocks</h3>



<ul><li>Discover several new blocks and expressive tools, including blocks for&nbsp;<em>Page Lists</em>,&nbsp;<em>Site Title</em>,&nbsp;<em>Logo</em>, and&nbsp;<em>Tagline</em>. A powerful&nbsp;<em>Query Loop</em>&nbsp;block offers multiple ways for displaying lists of posts and comes with new block patterns that take advantage of its flexibility and creative possibilities.</li><li>Interacting with nested blocks has been made easier with a permanent toolbar button for selecting a parent. Block outlines are shown when hovering or focusing on the different block type buttons. Block handles are now also present for drag and drop when in “select” mode.</li><li>Introduces the&nbsp;<strong>List View</strong>, a panel that can be toggled and helps navigate complex blocks and patterns.</li><li>Reusable blocks have an improved creation flow and support for history revisions. </li><li>A cool new duotone block adds images effects which can be used in media blocks or supported in third-party blocks. Color presets can also be customized by the theme.</li></ul>



<h3>Handpicked Patterns</h3>



<p>Patterns can now also be recommended and selected during block setup, offering powerful new flows. Pattern transformations are also possible and allow converting a block or a collection of blocks into different patterns.</p>



<p>New collection of Patterns and an initial integration with the upcoming Pattern Directory on WordPress.org.</p>



<h3>Better Tools</h3>



<ul><li><span style=\"color: initial;, sans-serif\">New template editor that allows creating new custom templates for a page using blocks.</span></li><li>Themes can now control and configure styling with a theme.json file, including layout configuration, block supports, color palettes, and more.</li><li>New design tools and enhancements to existing blocks, including more color, typography, and spacing options, drag and drop for Cover backgrounds, additions to block transformation options, ability to embed PDFs within the File block, and more.</li><li>Includes improvements to how the editor is rendered to more accurately resemble the frontend.</li></ul>



<h3>Internet Explorer 11</h3>



<p>Support for Internet Explorer 11 is ending in WordPress this year. In this release, most of those changes are being merged so use the Beta and RC periods to test!</p>



<h3>Blocks in Widgets Area</h3>



<ul><li>You can now use any block in your theme’s widget areas using the all new Widgets screen and updated Customizer.</li><li>Existing third party widgets continue to work via the <a href=\"https://developer.wordpress.org/block-editor/how-to-guides/widgets/legacy-widget-block/\">Legacy Widget block</a>.</li><li>Not quite ready for a full switch? To ease the transition, users can use the <a href=\"https://wordpress.org/plugins/classic-widgets/\">Classic Widgets plugin</a> and themes can call <a href=\"https://developer.wordpress.org/block-editor/how-to-guides/widgets/opting-out/\">remove_theme_support( &#8216;widgets-block-editor&#8217; )</a>.</li></ul>



<p><em>Looking for a change and can&#8217;t find it? There are more improvements listed after the break.</em></p>



<h2><strong>How You Can Help</strong></h2>



<h3>Do some testing!</h3>



<p>Testing for bugs is an important part of polishing the release during the beta stage and a great way to contribute.</p>



<p>If you think you’ve found a bug, please post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>. That’s also where you can find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p>Thanks for joining us, and happy testing!</p>



<p class=\"has-text-align-left\"><em><span><i>Props to </i></span><a href=\'https://profiles.wordpress.org/audrasjb/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>audrasjb</a>, <a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a>, <a href=\'https://profiles.wordpress.org/youknowriad/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>youknowriad</a>, <a href=\'https://profiles.wordpress.org/annezazu/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>annezazu</a>, <a href=\'https://profiles.wordpress.org/matveb/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>matveb</a>, and <a href=\'https://profiles.wordpress.org/desrosj/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>desrosj</a><span><i> for </i>editing/proof reading</span> this post, and <a href=\'https://profiles.wordpress.org/chanthaboune/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chanthaboune</a> for final review.</em></p>



<hr class=\"wp-block-separator is-style-default\" />



<p><em>Full Site Editing<br>Coming at the end of year<br>But first, Beta 1</em></p>



<span id=\"more-10733\"></span>



<h2><strong>Improvements in this Release</strong></h2>



<ul><li>Improvements to Reusable blocks, Cover block, Table block, List View, Rich text placeholder, Template Editing Mode, Block Inserter, and Top Toolbar</li><li>Query loop block that uses a query/filter to create a flexible post list based on templates. Best used with patterns.</li><li>Parity refinement between editor and frontend, Standardization to block toolbars organization</li><li>Block widgets in the Customizer</li><li>Introducing the Global Styles and Global Settings APIs: control the editor settings and available customization tools and style blocks using a theme.json file.Template editor opens inside an iframe to more accurately resemble the front end.</li><li>Ability to transform Media and Text into Columns</li><li>Embedded PDFs within File block</li><li>Spacing options for Social Links and Buttons, Spacer block width adjustments</li><li>Twemoji has been updated to version 13.1, bringing you many new Emoji.</li><li>Editor performance improvements</li><li>Hide writing prompt from subsequent empty paragraphs</li><li>More descriptive publishing UI</li><li>Added capability to set the default format for image sub-sizes as well as WebP support</li><li>Added widgets block editor to widgets.php and customize.php</li><li>Added block patterns to default themes</li><li>Added ability to mark a plugin as unmanaged</li><li>Enable revisions for the reusable block custom post type</li><li>Enqueue script and style assets only for blocks present on the page</li><li>Abstracted block editor configuration by deprecating existing filters and introducing replacements that are context-aware</li><li>New sidebars, widget, and widget-types REST API endpoints</li><li>Added support for modifying the term relation when querying posts in the REST API</li><li>Site Health now supports custom sub-menus and pages</li><li>Themes now display the number of available theme updates in the admin menu</li><li>Speed up cached <code>get_pages()</code> calls</li><li>Underscore updates from 1.8.3 to 1.9.1</li></ul>



<p>To see all of the features for Gutenberg release in detail check out these posts: <a href=\"https://make.wordpress.org/core/2021/02/17/whats-new-in-gutenberg-10-0-february/\">10.0</a>, <a href=\"https://make.wordpress.org/core/2021/03/02/whats-new-in-gutenberg-10-1-3-march/\">10.1</a>, <a href=\"https://make.wordpress.org/core/2021/03/17/whats-new-in-gutenberg-10-2-17-march/\">10.2</a>, <a href=\"https://make.wordpress.org/core/2021/04/02/whats-new-in-gutenberg-10-3-31-march/\">10.3</a>, <a href=\"https://make.wordpress.org/core/2021/04/14/whats-new-in-gutenberg-10-4-14-april/\">10.4</a>, <a href=\"https://make.wordpress.org/core/2021/04/30/whats-new-in-gutenberg-10-5-28-april/\">10.5</a>, <a href=\"https://make.wordpress.org/core/2021/05/14/whats-new-in-gutenberg-10-6-12-may/\">10.6</a>, and <a href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\">10.7</a>. In addition to those changes, contributors have fixed&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.8&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">215 tickets in WordPress 5.8</a>, including&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;type=enhancement&amp;type=feature+request&amp;milestone=5.8&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=owner&amp;col=priority&amp;col=changetime&amp;col=keywords&amp;order=changetime\">88 new features and enhancements</a>, with more bug fixes on the way.</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10733\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:55:\"
		
		
		
		
		
				

					
										
					
		
		

			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WP Briefing: Episode 10: Finding the Good In Disagreement\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wordpress.org/news/2021/06/episode-10-finding-the-good-in-disagreement/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 12:22:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10424\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:408:\"To Agree, disagree, and everything in-between. In this episode, Josepha talks about forming opinions and decision-making in the WordPress project. Have a question you&#8217;d like answered? You can submit them to wpbriefing@wordpress.org, either written or as a voice recording. Credits Editor: Dustin Hartzler Logo: Beatriz Fialho Production: Chloé Bringmann Song: Fearless First by Kevin MacLeod [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"enclosure\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:3:\"url\";s:60:\"https://wordpress.org/news/files/2021/06/WP-Briefing-010.mp3\";s:6:\"length\";s:1:\"0\";s:4:\"type\";s:0:\"\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:12068:\"
<p>To Agree, disagree, and everything in-between. In this episode, Josepha talks about forming opinions and decision-making in the WordPress project.</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<p>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></p>



<p>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></p>



<p>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></p>



<p>Song: Fearless First by Kevin MacLeod</p>



<h2>References</h2>



<p><a href=\"https://www.oprah.com/spirit/suzy-welchs-rule-of-10-10-10-decision-making-guide/all\">10/10/10 Rule</a></p>



<p><a href=\"https://en.wikipedia.org/wiki/Time_management#The_Eisenhower_Method\">The Eisenhower Matrix&nbsp;</a></p>



<p><a href=\"https://en.wikipedia.org/wiki/Minimax\">The Maximin Strategy&nbsp;</a></p>



<p><a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a></p>



<p><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></p>



<p><a href=\"https://make.wordpress.org/core/5-8/\">WordPress 5.8 Development Cycle</a></p>



<h2>Transcript</h2>



<span id=\"more-10424\"></span>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:10</p>



<p>Hello, everyone, and welcome to the WordPress Briefing, the podcast where you can catch quick explanations of some of the ideas behind the WordPress open source project and the community around it, as well as get a small list of big things coming up in the next two weeks. I&#8217;m your host, Joseph Haden Chomphosy. Here we go!</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:40</p>



<p>For anyone who has ever organized something, whether it&#8217;s a social event, a school project, or an annual family gathering, you know that there are many different opinions. The more opinions you have, the more likely people don&#8217;t see eye to eye. And before you know it, you&#8217;ve got some disagreements. Some things make disagreements worse, like imbalance of information, lack of showing your work, and sometimes just “too many cooks in the kitchen,” to use a regional phrase. Frankly, sometimes it seems like the second you have more than one cook in your kitchen, you&#8217;re going to get some disagreements. But I think that&#8217;s a healthy thing. WordPress is huge. And there are huge numbers of people contributing to WordPress or any other open source project you want to name. So there&#8217;s a lot of stuff available to disagree about. If we never saw anyone pointing out an area that wasn&#8217;t quite right, there would probably be something wrong. If you, like me, think that a healthy tension of collaborative disagreement can be useful when approached thoughtfully, then this quick start guide is for you.&nbsp;</p>



<p>Step one, prepare to host a discussion. This is, by the way, just the hardest step out there. You have to take a little time to figure out what problem you&#8217;re solving with the solution you&#8217;re suggesting, any goals that it relates to, and then figure out what the bare minimum best outcome would be and what the wildest dreams magic wand waving outcome would be. And you have to be honest with yourself.&nbsp;</p>



<p>Step two, host the discussion. The venue will be different for different discussions, but you see a lot of these on team blogs or within the actual tickets where work is being done. Wherever you&#8217;re hosting it, state the problem, state your idea for the solution and ask for what you missed. If you&#8217;re hosting a discussion in person, like in a town hall format, this can be hard. And generally, hosting discussions in an in-person or voice call or zoom call kind of way is hard. So if you have an opportunity to start doing this in text first and level your way up to in person, that&#8217;s my recommendation.&nbsp;</p>



<p>Step three is to summarize the discussion and post a decision if possible. So organizing a big discussion into main points is a really good practice for the people you&#8217;re summarizing it for and yourself. It helps you to confirm your understanding, and it also gives you the chance to pair other solutions with the problem and goals you outlined in step one. If a different solution solves the same problem but with less time or effort, it&#8217;s worth taking a second look with less time or effort. There’s something that I say to WordPress contributors frequently, and that is there are a lot of yeses. There are a lot of right ways to do things and only a few clear wrong ways to do things. So be open-minded about whether or not someone else&#8217;s right way to do things could still achieve the goals you&#8217;re trying to accomplish with your solution. A note on step three where I said, “and post the decision if possible.” Sometimes you&#8217;re the person to make that decision, but sometimes you are not the person who can give something the green light, and so you&#8217;re preparing a recommendation. Whether you&#8217;re making a decision or a recommendation, sometimes you may experience a little decision-making paralysis. I know I do. So here are a few of the tools that I use.</p>



<p>If you&#8217;re avoiding the decision, use the 10/10/10 rule; it can help you figure out if you&#8217;re stuck on a short-term problem. If there are too many good choices, use the Eisenhower Matrix that can help you to prioritize objectively. If there are too many bad choices, use the Maximin strategy. It can help you to identify how to minimize any potential negative impacts.&nbsp;</p>



<p>Okay, so you&#8217;ve considered your position. You’ve discussed everything. You summarized the big points. Maybe you also worked your way through to a recommendation or a decision. What about everyone who disagreed with the decision? Or have you made a recommendation, and it wasn&#8217;t accepted? How do you deal with that? That&#8217;s where “disagree and commit” shows up. This phrase was made popular by the folks over at Amazon, I think. But it first showed up, I believe at Sun Microsystems as this phrase, “agreeing, commit, disagree and commit or get out of the way.”</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>05:34</p>



<p>Disagree and commit as a concept works pretty well when everyone agrees on the vision and the goals, but not necessarily how to get to those goals. We&#8217;ve had moments in recent history where folks we&#8217;re not able to agree, we’re not able to commit, and so then left the project. I hate when that happens. I want people to thrive in this community for the entire length of their careers. But I also understand that situation shows up in the top five learnings of open source when you no longer have interest in the project and handed it off to a competent successor. So there it is &#8211; disagreements in open source in WordPress.&nbsp;</p>



<p>As with so many of the things I discuss on this podcast, this is incredibly complex and nuanced in practice. Taking an argument, distilling facts from feelings, and adjusting frames of reference until the solution is well informed and risk-balanced. That is a skill set unto itself. But one that increases the health of any organization. I’ll share that list of references and general materials in the show notes, including a link explaining each of those decision-making tools that I shared. I&#8217;m also going to include the contributor training module on decision-making in the WordPress project. It&#8217;s got excellent information. It&#8217;s part of a series of modules that I asked team reps to take and sponsored contributors. I don&#8217;t require it from anyone, but I do hope that it is useful for you. Also, speaking of useful for you, if you are just here for leadership insights, I included some hot takes after the outro music for you. It&#8217;s like an Easter egg, but I just told you about it.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>07:33</p>



<p>And that brings us to our small list of big things! First off, WordCamp Europe is happening this we; I hope that everybody has an opportunity to attend. If you still haven&#8217;t gotten your tickets, they are free, and I think there are still a few left. I will include a link in the show notes as well. There&#8217;s going to be a little demo with Matt Mullenweg and Matias Ventura on the WordPress 5.8 release that&#8217;s coming up. And then kind of a retrospective discussion between Matt and Brian Krogsgard. I encourage you to join; I think it&#8217;s going to be very interesting.&nbsp;</p>



<p>There&#8217;s also WordCamp, Japan coming up June 20 through 26th. I mentioned it last time &#8211;&nbsp; it has a big section of contributing and contribution time. So if you&#8217;re looking to get started, some projects are laid out, and I encourage you to take a look at that as well.&nbsp;</p>



<p>The new thing on this list, and I don&#8217;t know how new It is, in general, I hope it&#8217;s not too new to you, is that WordPress 5.8 release is reaching its beta one milestone on June 8th, so right in the middle of WordCamp Europe. I encourage every single theme developer, plugin developer that we have, agency owners that we have to really take a look at this release and dig into testing it. It&#8217;s a gigantic release. And I have so many questions about what will work and will not work once we get it into a broader testing area. We&#8217;ve been doing a lot of testing in the outreach program. But it&#8217;s always helpful to get people who are using WordPress daily in their jobs to really give a good solid test to the beta product to the beta package. And put it all through its paces for us.&nbsp;</p>



<p>So, that my friends, is your small list of big things. Thank you for tuning in today for the WordPress Briefing. I&#8217;m your host Josepha Haden Chomphosy, and I&#8217;ll see you again in a couple of weeks.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>10:09</p>



<p>Hey there, you must be here because I told you about this totally not hidden easter egg about my hot takes on organizational health; I have three for you. And if you&#8217;ve ever worked with me, none of this will surprise you. But if you haven&#8217;t worked with me, hopefully, it kind of gives you some idea about how I approach all of this a bit differently. So, number one, critical feedback is the sign of a healthy organization. And I will never be dissuaded from that opinion. A complete lack of dissent doesn&#8217;t look like “alignment.” To me, that looks like fear. And it goes against the open source idea that many eyes make all bugs shallow.&nbsp;</p>



<p>Tip number two, a bit of tension is good, a bit of disagreement is good. The same thing that I say about women in tech, we&#8217;re not all the same. And if we were, then we wouldn&#8217;t need to collaborate anyway. But diversity, whether that&#8217;s the diversity of thought or of a person or of experience, just doesn&#8217;t happen without some misunderstandings. It&#8217;s how we choose to grow through those misunderstandings that make all the difference for the type of organization we are.&nbsp;</p>



<p>And hot take number three, changing your mind isn&#8217;t flip-flopping or hypocritical. I think that&#8217;s a sign of growth and willingness to hear others. I like to think of my embarrassment at past bad decisions &#8211; as the sore muscles of a learning brain. And I, again, probably won&#8217;t be dissuaded from that opinion. Although, you know, if I&#8217;m sticking true to changing your mind some flip-flopping or hypocritical, maybe I will, but you can always try to, to give me the counter-argument for that, and we&#8217;ll see how it goes. Thank you for joining me for my little public easter egg.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10424\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:66:\"
		
		
		
		
		
				
		
		
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"People of WordPress: Tijana Andrejic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2021/06/people-of-wordpress-tijana-andrejic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 12:01:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:10:\"Interviews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:16:\"ContributorStory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:9:\"HeroPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10427\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:178:\"This month to coincide with WordCamp Europe, we feature Tijana Andrejic from Belgrade, Serbia, about her journey from fitness trainer to the opportunities in the WordPress world.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"webcommsat AbhaNonStopNewsUK\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:14291:\"
<p><strong>WordPress is open source software, maintained by a global network of contributors. There are many examples of how WordPress has changed people’s lives for the better. In this monthly series, we share some of the amazing stories.</strong></p>



<p>This month to coincide with WordCamp Europe, we feature Tijana Andrejic from Belgrade, Serbia, about her journey from fitness trainer to the WordPress world, with the freelance and corporate opportunities it introduced. </p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"387\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/06/2021-07-Tijana-Andrejic_Featured-Img_1.jpg?resize=632%2C387&#038;ssl=1\" alt=\"Tijana - portrait picture\" class=\"wp-image-10713\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2021/06/2021-07-Tijana-Andrejic_Featured-Img_1.jpg?w=1024&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2021/06/2021-07-Tijana-Andrejic_Featured-Img_1.jpg?resize=300%2C184&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2021/06/2021-07-Tijana-Andrejic_Featured-Img_1.jpg?resize=768%2C470&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>As a professional manager with a college degree in Organizational Science and a certified fitness instructor, Tijana is nothing if not driven and goal-oriented.&nbsp;</p>



<p>Following her time as a fitness trainer, Tijana moved to work in IT around 2016. She first explored content creation and design before focusing on SEO and becoming an independent specialist.&nbsp;&nbsp;</p>



<p>Tijana was hired as a Customer Happiness Engineer for a hosting company, where she discovered the benefits of having a team. She realized that having close working relationships with colleagues is helpful for business success and accelerates personal growth.</p>



<p>Tijana hopes that by sharing her story, she can help others who are either starting their career or are moving roles. She describes the opportunities she discovered in the WordPress community as ‘a huge epiphany’, especially in the world of freelancing.</p>



<p>She highlights <strong>5 things that helped her to start a new freelancing career</strong>. Let’s dive into them.</p>



<h2>What motivates me?</h2>



<p>“Why am I doing this?” is the first question that Tijana asks herself before starting anything new. This self-review and honesty, she feels, allows her to determine her priorities. She also benchmarks options around her motivations of wanting a flexible schedule and to grow professionally.&nbsp;</p>



<p>She lists the reasons to make a particular choice, like being a freelancer, to help her choose the right job, pathway, or identify alternatives.&nbsp;</p>



<p>She recommends that others can take a similar approach. If freelancing is still the best solution after examining all their goals and motivations, Tijana believes a good next step would be to learn WordPress-related skills.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh6.googleusercontent.com/cdHeIL-H_mE6QFCUxUT-gfKS2GzizRHtn4iCENoaWOimC82BfModRJh44QbhvHPW0GNVP5eUPhgxQteDRbA_9EUzpssTXMGWje1hUuKyrfXUgGhCnvXQdraaUQiaGBjFr73dNYxr\" alt=\"WordCamp Europe 2019 group picture\" /></figure>



<h2>Develop WordPress related skills</h2>



<p>The next question you may ask: “Why WordPress?”</p>



<p>WordPress is used by more than 40% of websites in some form and offers various roles, many of which are not developer-specific. Tijana highlights a few:&nbsp;</p>



<ul><li>web developer (coding websites, themes, and plugins)</li><li>web implementor (creating websites from existing themes without coding)</li><li>web designer (designing website mock-ups, editing images, or creating online infographics)</li><li>client support professional (helping people with their websites)</li><li>website maintenance (WordPress, themes, and plugins are maintained and backed up regularly)</li><li>WordPress trainer (helping clients with how to use the platform or teaching other web professionals)</li><li>content writer</li><li>accessibility specialist (making sure standards are met and suggesting solutions for accessibility barriers)</li><li>SEO consultant (improving search outcomes and understanding)</li><li>statistics consultant, especially for web shops</li><li>WordPress assistant (adding new content and editing existing posts)</li><li>website migration specialist (moving websites from one server to another)</li><li>web security specialist</li></ul>



<figure class=\"wp-block-image\"><img src=\"https://lh4.googleusercontent.com/16XExYT_P4R4PX3orOaWbueDfkBIA6PFQ-CuYEXdeN9AvUIuIF33aIjT1DpdnFCqhrijWv1f68OR2Qh14xGT9REHGJ-MqK-OxJ9XcrhZ3IkcW8DBI7nVAtvFcCnCHL0woka_FV6t\" alt=\"WCBGD group picture\" /></figure>



<p>Tijana emphasized: “Another reason why WordPress is great for freelancers is the strong community that exists around this content management system (CMS).&#8221; WordCamps and Meetups are a way to get useful information and meet people from a large and very diverse community and get answers to many questions straight away.&nbsp;</p>



<p>In the past year, these events have been primarily online. However, the contributors who run them continue to make an effort to provide an experience as close to in-person events as possible. The biggest advantage to online events is that we can attend events from across the world, even if sometimes during these difficult times, it is difficult to get enough time to deeply into this new experience. Since Tijana’s first Meetup, she has attended many WordPress community events and volunteered as a speaker.</p>



<h2>Plan in advance</h2>



<p>Becoming a freelancer takes time. For Tijana, success came with proper planning and following her plan to ‘acquire or improve relevant skills that will make you stand out in the freelance market.’ She strongly believes that learning and growing as a professional opens more business opportunities.&nbsp;</p>



<p>If you are considering a freelance career, she advises improving relevant skills or developing new skills related to your hobbies as ‘there is nothing better than doing what you love.’ In cases where no previous experience and knowledge can be used, she suggests choosing ‘a job that has a shorter learning curve and builds your knowledge around that.’</p>



<p>Tijana started as a content creator and learned to become an SEO expert. However, she highlights many alternative paths, including starting as a web implementer and moving to train as a developer.&nbsp;</p>



<p>She suggests to others: “It would be a good idea to analyze the market before you jump into the learning process.” She also recommends people check the latest trends and consider the future of the skills they are developing.</p>



<p>Visit the new <a href=\"https://learn.wordpress.org/\">Learn WordPress.org</a> to see what topics are of interest to you. In this newly established resource, the WordPress community aggregates workshops to support those who want to start and improve their skills, provides lesson plans for professional WordPress trainers and helps you create personal learning to develop key skills. There is also material on helping you be part of and organize events for your local community.</p>



<p>Tijana highlights that there are many places for freelancers to find clients. For example, the WordPress Community has a place where companies and individual site owners publish their job advertisements&nbsp; &#8211; <a href=\"https://jobs.wordpress.net/\">Jobs.WordPress.net</a>.</p>



<h2>Hurray, it’s time to get a first freelancing job</h2>



<p>As a pragmatic person, Tijana recommends: “Save money before quitting your job to become a full-time freelancer. Alternatively, try freelancing for a few hours per week to see if you like it. Although some people do benefit when taking a risk, think twice before you take any irreversible actions.”&nbsp;</p>



<p>She shared some possible next steps:&nbsp;</p>



<ul><li>use a freelancing platform</li><li>triple-check your resume</li><li>professionally present yourself</li><li>fill up your portfolio with examples</li><li>use video material</li></ul>



<p>“By using video material, your clients will not see you like a list of skills and previous experiences, but as a real person that has these skills and experiences and that provides a certain service for them.”</p>



<p>She adds: “Have a detailed strategy when choosing your first employer. Choose your first employer wisely, very wisely. I can’t emphasize enough how important this is”.</p>



<p>When Tijana took her first freelancing job, she considered the following:</p>



<ul><li>how was the employer rated by other freelancers who worked for him previously</li><li>how does the employer rate other freelancers</li><li>how much money had they already spent on the platform</li><li>the number of open positions for a specific job and the number of freelancers that have already applied&nbsp;</li></ul>



<p>“The first job is not all about the money. Don’t get greedy on your first job. If you get good recommendations, your second job can pay two to three times more. And your third job can go up to five times more. That was my experience.”</p>



<h2>Take responsibility as a freelancer</h2>



<p>Tijana reminds us: “Freedom often comes with responsibility; individual responsibility is key when it comes to freelancing.”</p>



<p>She advises others not to take a job if you can not make a deadline and have someone reliable who can help you.&nbsp;</p>



<p>Missing deadlines will cost your client money and affect the review the client will be willing to leave about your job, and this can have a big impact on your future opportunities or freelance jobs.</p>



<p>She adds: “This can start a downward spiral for your career. However, we are all humans, and unpredictable things can happen. If for some reason you are not able to complete your work in a timely manner, let your client know immediately so they can have enough time to hire someone else”.</p>



<p>Tijana emphasizes the importance of making expectations clear before accepting a job, both what the client is expecting and what you can expect from the client.&nbsp;</p>



<p>Lastly, she points out that if you are working from home, your friends and family should treat you the way they would if you were in an office. She advises: “Let them know about your working schedule.”</p>



<p>She hopes that these basic guidelines will be useful in launching freelance careers, as they did her, even though there is no universal recipe for all.</p>



<p>Tijana highlights: “It’s just important to stay focused on your goals and to be open to new opportunities.” Freelancing wasn’t the only way she could have fulfilled her goals, but it was an important part of her path, and it helped her be confident in her abilities to make the next big step in her life.</p>



<p>As a freelancer, she was missing close relationships with colleagues and teamwork, which she has now found in her current firm. Her colleagues describe her as a: “walking-talking bundle of superpowers: sports medicine and fitness professional, SEO expert, blogger, designer and a kitty foster mum”.</p>



<figure class=\"wp-block-image\"><img src=\"https://lh4.googleusercontent.com/PIGT9R6FmtEHsNBvWzyViW5htRAm156asTOsohOGOUwfsWjW1TuDhUI9yuZnjIe-1eFHfFUWPULPtw82P3YYXHa0bsY_jA5keelmDHfSkTdd3xUsVZTmG9KvdE8XTojvU3LxYCsi\" alt=\"Conference reception\" /></figure>



<p>If you are considering starting your career as a freelancer, take the courses offered at <a href=\"https://learn.wordpress.org/\">learn.wordpress.org,</a> reach out to companies that you would be interested in working with, and remember that there are a whole host of opportunities in the WordPress project.</p>



<p><a href=\"https://make.wordpress.org/\">The WordPress.org Teams</a> &#8211; what they do, when and where they meet</p>



<p><a href=\"https://learn.wordpress.org/\">Learn WordPress resource</a> &#8211; free to use to expand your knowledge and skills of using the platform and learning about the community around it.</p>



<p>The 3-day <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe 2021</a> online event begins on 7 June 2021. You can discover more about being a contributor in its live sessions and <a href=\"https://europe.wordcamp.org/2021/contribute-to-wordpress/\">section on ways to contribute to WordPress</a>.</p>



<h2>Contributors</h2>



<p>Thanks to Olga Gleckler (<a href=\'https://profiles.wordpress.org/oglekler/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>oglekler</a>), Abha Thakor (<a href=\"https://profiles.wordpress.org/webcommsat/\">@webcommsat</a>), Chloé Bringmann (<a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a>), Surendra Thakor (<a href=\'https://profiles.wordpress.org/sthakor/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>sthakor</a>), and Meher Bala (<a href=\'https://profiles.wordpress.org/meher/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>meher</a>) for working on this story. Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\">@chanthaboune</a>) and also to Topher DeRosia (<a href=\"https://profiles.wordpress.org/topher1kenobe/\">@topher1kenobe</a>) who created HeroPress. Thank you to Tijana Andrejic (<a href=\'https://profiles.wordpress.org/andtijana/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>andtijana</a>) for sharing her #ContributorStory</p>



<figure class=\"wp-block-image\"><img src=\"https://lh4.googleusercontent.com/FEZ2FQJ0vQ311YoPfh6ny15NXh8saTLH_RjyDO4pUOuEGBTa-Czk63PGoWL04FawKviRfNx0QXePx-goK04X12ry1BR_WXh-kVPIfsEeItPAX6reN5fHS96q6-8dUI506ZO38Z0G\" alt=\"HeroPress logo\" /></figure>



<p><em>This post is based on an article originally published on HeroPress.com. It highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members in our <a href=\"https://wordpress.org/news/category/heropress/\">People of WordPress series</a>.</em></p>



<p><em>#ContributorStory #HeroPress</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10427\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"A New Design is Coming to WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2021/06/a-new-design-is-coming-to-wordpress-news/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jun 2021 20:47:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:7:\"General\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"Updates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10418\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"After many years of a tidy, white-space filled design on WordPress.org/news it&#8217;s time to bring new life to the way we present our content. So much has changed since this site was first created: the people who read it, the type and variety of what is published, even the way WordPress works has changed. Which [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1591:\"
<p>After many years of a tidy, white-space filled design on WordPress.org/news it&#8217;s time to bring new life to the way we present our content. So much has changed since this site was first created: the people who read it, the type and variety of what is published, even the way WordPress works has changed.</p>



<p>Which means it makes sense to change our theme. </p>



<p>Earlier this year, Matt requested a new design from Beatriz Fialho (who also created the State of the Word slides for 2020). The design keeps a clean, white-space friendly format while incorporating a more jazzy, playful feeling with a refreshed color palette. </p>



<figure class=\"wp-block-image size-large\"><img loading=\"lazy\" width=\"632\" height=\"449\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/06/25-1024x728-1.png?resize=632%2C449&#038;ssl=1\" alt=\"\" class=\"wp-image-10420\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2021/06/25-1024x728-1.png?w=1024&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2021/06/25-1024x728-1.png?resize=300%2C213&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2021/06/25-1024x728-1.png?resize=768%2C546&amp;ssl=1 768w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /></figure>



<p>More detail on this modern exploration have been posted on <a href=\"https://make.wordpress.org/design/2021/06/03/redesign-of-wordpress-org-news/\">make.wordpress.org/design</a>. I encourage you to stop by and read more about the thoughts behind the coming updates; and keep an eye out for the new look here and across WordPress.org!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10418\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"The Month in WordPress: May 2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2021/06/the-month-in-wordpress-may-2021/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 Jun 2021 18:23:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10393\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:366:\"It’s really fun to contribute to something larger than yourself. Matt Mullenweg’s words in “The Commons of Images” episode of the WP Briefing podcast exemplify the core philosophy of the WordPress project,&#160; especially as we inch closer to the next major release (version 5.8). This post covers exciting updates from the month of May. WordPress [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11073:\"
<blockquote class=\"wp-block-quote\"><p>It’s really fun to contribute to something larger than yourself.</p></blockquote>



<p><a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>’s words in “<a href=\"https://wordpress.org/news/2021/05/the-commons-of-images/\">The Commons of Images</a>” episode of the <a href=\"https://wordpress.org/news/podcast/\">WP Briefing podcast</a> exemplify the core philosophy of the WordPress project,&nbsp; especially as we inch closer to the next major release (version 5.8). This post covers exciting updates from the month of May.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress turns 18</h2>



<p>WordPress <a href=\"https://wordpress.org/news/2021/05/wordpress-at-18/\">celebrated the 18th anniversary</a> of its <a href=\"https://wordpress.org/development/2003/05/wordpress-now-available/\">launch</a> on May 27, 2021. To celebrate 40+ releases and WordPress’ support of 40% of the web, the team <a href=\"https://wordpress.org/news/2021/05/wordpress-at-18/\">released 40 milestones</a> to celebrate the anniversary of the software. Here’s to the next 18 and beyond!&nbsp;</p>



<h2>CC Search joins WordPress and is renamed to Openverse</h2>



<p><a href=\"https://wordpress.org/news/2021/05/welcome-to-openverse/\">Creative Commons Search has officially joined the WordPress project</a>. Creative Commons Search (CC Search) is a <a href=\"https://creativecommons.org/share-your-work/public-domain/cc0/\">CC0</a> image search engine with over 500 million openly licensed images. The search product, which is being renamed to Openverse, will eventually live on the URL: https://wordpress.org/openverse. Contributors working on CC Search will continue their work as part of a <a href=\"https://make.wordpress.org/meta/2021/04/27/new-wordpress-make-team/\">new dedicated Make team</a>: <a href=\"https://make.wordpress.org/openverse\">https://make.wordpress.org/openverse</a>. Check out “<a href=\"https://wordpress.org/news/2021/05/the-commons-of-images/\">The Commons of Images</a>” podcast episode for more information.</p>



<h2>WordPress 5.7.2 released</h2>



<p>WordPress <a href=\"https://wordpress.org/news/2021/05/wordpress-5-7-2-security-release/\">version 5.7.2</a>, a short-cycle security release, came out on May 13. Get the latest version directly from your WordPress dashboard or by <a href=\"https://wordpress.org/download/\">downloading</a> it from WordPress.org.</p>



<p>Want to contribute to WordPress core? Check out the <a href=\"https://make.wordpress.org/core/handbook/\">Core Contributor Handbook</a>. Don’t forget to join the WordPress <a href=\"https://wordpress.slack.com/archives/C02RQBWTW\">#core</a> channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress Slack</a> and follow the <a href=\"https://make.wordpress.org/core/\">Core Team blog</a>. The Core Team hosts weekly chats on Wednesdays at <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=5&amp;min=00&amp;sec=0\">5 AM</a> and <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?hour=20&amp;min=00&amp;sec=0\">8 PM</a> UTC.&nbsp;</p>



<h2>Gutenberg versions 10.6 and 10.7 are out</h2>



<p>Gutenberg <a href=\"https://make.wordpress.org/core/2021/05/14/whats-new-in-gutenberg-10-6-12-may/\">version 10.6</a> and <a href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\">version 10.7</a> were launched this month. <a href=\"https://make.wordpress.org/core/2021/05/14/whats-new-in-gutenberg-10-6-12-may/\">Version 10.6</a> features <a href=\"https://wordpress.org/news/2021/05/coloring-your-images-with-duotone-filters/\">experimental Duotone filters (which are shipping with WordPress 5.8)</a>, block pattern suggestions in placeholders, and enhancements to the table block. <a href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\">Version 10.7</a> adds a responsive navigation block, block design tools, and the ability to load block patterns from the directory.<br></p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core Team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the <a href=\"https://wordpress.slack.com/archives/C02QB2JS7\">#core-editor</a> channel in the <a href=\"https://make.wordpress.org/chat/\">Make WordPress Slack</a>. The latest “<a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/core/2021/03/08/whats-next-in-gutenberg-march-2021/\" target=\"_blank\">What’s next in Gutenberg</a>” post offers more details on the latest updates. If you are unfamiliar with the Gutenberg plugin, <a href=\"https://wordpress.org/news/2021/04/become-an-early-adopter-with-the-gutenberg-plugin/\">learn more in this post</a>.</p>



<h2>Full Site Editing updates</h2>



<p>Don’t miss the <a href=\"https://make.wordpress.org/test/2021/05/26/fse-program-testing-call-7-polished-portfolios/\">latest Full Site Editing (FSE) Outreach program testing call on building portfolio pages</a> using the Template Editing feature shipping with WordPress 5.8! The deadline is June 9. The team has published a recap of the <a href=\"https://make.wordpress.org/test/2021/05/06/fse-program-query-quest-summary/\">Query Quest FSE Testing call</a>, which shares some interesting results. The answers to <a href=\"https://make.wordpress.org/test/2021/05/13/fse-program-answers-from-round-two-of-questions/\">round two of FSE questions</a> are also out.</p>



<h2>Countdown starts for WordCamp Europe 2021</h2>



<p>The countdown to one of the most anticipated WordPress events, <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe 2021 (Online)</a>, has started! The <a href=\"https://europe.wordcamp.org/2021/schedule/\">full schedule of the event</a> is now available, and the team has exciting plans! Don’t miss this event: <a href=\"https://europe.wordcamp.org/2021/registration/\">get your tickets now</a> before they run out!</p>



<hr class=\"wp-block-separator\" />



<h2>Further reading</h2>



<ul><li>The Core Team published its <a href=\"https://make.wordpress.org/core/2021/05/17/introducing-the-wordpress-css-audit-tool/\">first-ever WordPress CSS Audit tool</a>. The team has also <a href=\"https://make.wordpress.org/core/2021/05/03/feature-project-updates-on-updating-the-updaters/\">kicked off a project to improve all the updaters in WordPress core</a>.</li><li>The Community Team proposed <a href=\"https://make.wordpress.org/community/2021/05/12/proposal-adding-vaccination-status-to-the-in-person-meetup-safety-checklist/\">adding vaccination status to the in-person meetup checklist</a> as a criterion to organize in-person WordPress meetups. The team also published results of the <a href=\"https://make.wordpress.org/community/2021/05/28/2020-meetup-organizer-survey-results/\">2020 Meetup Organizer survey</a> and <a href=\"https://make.wordpress.org/community/2021/05/21/2020-meetup-survey-results/\">Meetup Member survey</a>. </li><li><a href=\"https://venezuela.wordcamp.org/2021/\">WordCamp Venezuela</a> and <a href=\"https://neo.wordcamp.org/2021/\">WordCamp North East Ohio </a>were held successfully in May. Don’t forget to grab your free tickets for <a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan 2021</a> and <a href=\"https://japan.wordcamp.org/2021/\">WordCamp Cochabamba 2021</a>, both happening in June.</li><li>The Design Team floated a <a href=\"https://make.wordpress.org/design/2021/05/27/proposal-to-tweak-existing-icons-and-add-new-ones/\">proposal to tweak existing core icons and add new ones</a>.</li><li><a href=\"https://profiles.wordpress.org/chanthaboune\">Josepha Haden</a> published <a href=\"https://make.wordpress.org/updates/2021/05/25/experiment-a-public-channel-for-all-team-reps/\">an experiment to create a public channel for team reps</a>. </li><li>The Support Team is considering adding <a href=\"https://make.wordpress.org/support/2021/05/support-team-deputies/\">two or more deputies to the team</a>. </li><li>The Themes Team requests theme authors to <a href=\"https://make.wordpress.org/themes/2021/05/25/themes-team-meeting-notes-may-25-2021/\">check their themes’ compatibility with WordPress 5.8</a> in view of the upcoming major release. </li><li>The Training Team <a href=\"https://href.li/?https://make.wordpress.org/training/2021/05/27/proposal-adding-custom-user-roles-to-learn-wordpress/\">shared a proposal</a> on adding custom user roles for <a href=\"https://href.li/?https://learn.wordpress.org\">learn.wordpress.org</a> to match the structure and functionality of the site. The team also <a href=\"https://href.li/?https://make.wordpress.org/training/2021/05/28/proposal-an-audit-tool-for-learn/\">proposed an audit tool</a> to improve content auditing for Learn.</li><li>The CLI Team released <a href=\"https://make.wordpress.org/cli/2021/05/19/wp-cli-v2-5-0-release-notes/\">version 2.5.0</a> of WP-CLI.</li><li>The Tide Team <a href=\"https://make.wordpress.org/tide/2021/05/25/tide-chat-summary-may-25th/\">seeks contributors</a> to help with documentation reviews, cleaning up Tide locally, and making the documentation clearer. </li><li>The Hosting Team <a href=\"https://make.wordpress.org/hosting/2021/05/20/why-hosters-should-install-the-php-intl-extension/\">recommends all web hosts to install the Internationalization PHP extension</a>. The team also launched<a href=\"https://www.meetup.com/wphosting/\"> its official meetup chapter</a>.</li><li>The latest edition of “<a href=\"https://wordpress.org/news/category/heropress/\">People of WordPress</a>” features <a href=\"https://wordpress.org/news/2021/05/people-of-wordpress-fike-komala/\">Fike Komala from Indonesia</a>.</li><li>The BuddyPress Team <a href=\"https://buddypress.org/2021/05/buddypress-8-0-0-release-candidate/\">released the BuddyPress 8.0 Release Candidate</a>. </li><li>Read about the brand new <a href=\"https://wordpress.org/news/2021/05/coloring-your-images-with-duotone-filters/\">Duotone filter for blocks</a> feature, that is shipping with WordPress 5.8! </li><li>Catch the latest episode of the <a rel=\"noreferrer noopener\" href=\"https://wordpress.org/news/podcast/\" target=\"_blank\">WP Briefing Podcast</a> where <a rel=\"noreferrer noopener\" href=\"https://profiles.wordpress.org/chanthaboune/\" target=\"_blank\">Josepha</a> talks about <a rel=\"noreferrer noopener\" href=\"https://wordpress.org/news/2021/05/episode-9-the-cartography-of-wordpress/\" target=\"_blank\">the cartography of WordPress</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it using this form</em></a><em>.&nbsp;</em></p>



<p><em>The following folks contributed to May’s Month in WordPress: <a href=\'https://profiles.wordpress.org/meher/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>meher</a> and <a href=\'https://profiles.wordpress.org/chaion07/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chaion07</a></em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"10393\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 26 Jun 2021 02:14:22 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 25 Jun 2021 17:14:06 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";}}s:5:\"build\";s:14:\"20201016115008\";}","no"),
("180","_transient_timeout_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1624716864","no"),
("181","_transient_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1624673664","no"),
("182","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1624716867","no"),
("183","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.8 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10855\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3891:\"<p>WordPress 5.8 Beta 4 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 4 in three ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the&nbsp;<code>Bleeding edge</code>&nbsp;channel and the&nbsp;<code>Beta/RC Only</code> stream).</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta4.zip\">zip</a>).</li><li>Using WP-CLI to test: <code>wp core update --version=5.8-beta4</code></li></ul>



<p>The current target for the final release is July 20, 2021. That’s less than <strong>four weeks away</strong>, so we need your help to make sure the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\">Beta 3</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=06%2F24%2F2021..06%2F26%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">18</a> bugs have been fixed. Most tickets focused on polishing existing default themes, fixing bugs in the new block Widget screen, and squashing Editor bugs collected during beta.</p>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=..06%2F25%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">254 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&status=reopened&changetime=..06%2F25%2F2021&type=enhancement&type=feature+request&milestone=5.8&group=component&col=id&col=summary&col=type&col=status&col=milestone&col=changetime&col=owner&col=priority&col=keywords&order=changetime\">91 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\"https://profiles.wordpress.org/desrosj/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>desrosj</a> <a href=\"https://profiles.wordpress.org/clorith/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>clorith</a> for reviews and <a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a> for final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Releasing software<br />Is complex when open source<br />Yet WordPressers do</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Jun 2021 17:14:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Jeffrey Paul\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:115:\"WPTavern: Gutenberg 10.9 Renames the Query Block, Adds Collapsible List View Items, and Rolls Out Rich URL Previews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=119015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:271:\"https://wptavern.com/gutenberg-10-9-renames-the-query-block-adds-collapsible-list-view-items-and-rolls-out-rich-url-previews?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-10-9-renames-the-query-block-adds-collapsible-list-view-items-and-rolls-out-rich-url-previews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6463:\"<p class=\"has-drop-cap\">Yesterday, <a href=\"https://make.wordpress.org/core/2021/06/24/whats-new-in-gutenberg-10-9-23-june/\">Gutenberg 10.9</a> landed in the WordPress plugin directory. The update overhauls the Query and Query Loop blocks, allows users to expand or collapse items in the editor list view, and introduces rich URL preview cards for links. The new version also packs in an updated template-mode <a href=\"https://github.com/WordPress/gutenberg/pull/32427\">creation modal</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/32166\">moves the blocks manager</a>.</p>



<p>This update ships several enhancements, particularly to the user experience. One of my favorite low-key upgrades is <a href=\"https://github.com/WordPress/gutenberg/pull/32371\">a new set</a> of add-card, bug, key, post author, and security icons by Filipe Varela, a product designer at Automattic.</p>



<p>Another small-but-packs-a-punch UI change is the <a href=\"https://github.com/WordPress/gutenberg/pull/32609\">inclusion of the post type</a> in the editor breadcrumb trail. The type&rsquo;s singular name label now replaces the root &ldquo;Document&rdquo; item.</p>



<p>For the past several cycles, the new template editor slated to launch with WordPress 5.8 has been enabled by default. The goal was always to allow everyone the chance to experience it, regardless of whether they were on a classic or block theme. The development team has now scaled this back to only be <a href=\"https://github.com/WordPress/gutenberg/pull/32858\">auto-enabled for block themes</a>. Classic themes must opt-in to support it. Theme authors should read the recent <a href=\"https://make.wordpress.org/core/2021/06/16/introducing-the-template-editor-in-wordpress-5-8/\">template editor overview</a> by Riad Benguella for the complete details.</p>



<h2>Query and Query Loop Blocks Renamed</h2>



<img />Query Loop block in the editor.



<p class=\"has-drop-cap\"><em>Query? Query Loop? What the heck is all this?</em> If you are unfamiliar with those terms, you are not alone. Even on the developer end, the early implementation of the Query and its inner Query Loop block could be a little confusing. For the average user, it probably makes even less sense.</p>



<p>Gutenberg 10.9 takes one step toward <a href=\"https://github.com/WordPress/gutenberg/pull/32514\">clearing up this confusion</a> for end-users. The former Query Loop block is now named Post Template. This is a far more accurate description of what it does. It is the &ldquo;template&rdquo; that outputs individual posts. It contains all the things you see, such as the post content or excerpt, the featured image, tags, categories, and more. This template is, of course, customizable via the block editor.</p>



<p>While this is a step toward a less complex user experience, it is not quite where it needs to be yet. The Query block has been renamed to Query Loop. Therein lies the remaining issue. The terminology might still be confusing.</p>



<p>The goal is to expose a variation of this block named Posts List to users. It already exists, but the query-related terminology still appears when using it. There is an <a href=\"https://github.com/WordPress/gutenberg/issues/32268\">open ticket to address this</a>.</p>



<p>The primary win with this update is the overhauled text in the Query Loop block sidebar. &ldquo;The query block is a powerful and complex block,&rdquo; said lead Gutenberg developer Matias Ventura in a <a href=\"https://github.com/WordPress/gutenberg/pull/32694\">GitHub ticket</a>. &ldquo;It can be intimidated to users without proper guidance. We can use this block as an opportunity to explain some of the underlying concepts of the WordPress software in a more didactic manner.&rdquo;</p>



<p>The more advanced options, such as whether to inherit from the URL and which post types to include, now have longer descriptions. Each should guide the user through features that have long existed in the developer world.</p>



<p>If you are a theme author and have already been building with these two blocks, do not worry about everything breaking when updating. The Query block has simply been renamed to &ldquo;Query Loop&rdquo; in user-facing text. Under the hood, it is still the same. The former Query Loop block has literally been renamed to Post Template (<code>core/post-template</code> block name). It is backward compatible. However, you should update any past calls to the <code>wp:query-loop</code> block to <code>wp:post-template</code>.</p>



<h2>Expand and Collapse Nested List View Blocks</h2>



<img />List view with collapsed nested blocks.



<p class=\"has-drop-cap\">The development team introduced an <a href=\"https://github.com/WordPress/gutenberg/pull/32117\">expand/collapse feature</a> for the editor&rsquo;s list view. Once opening the panel, users should now see arrow icons next to each item with nested blocks. Closing one or more of them makes it easier to see all or many top-level blocks at once.</p>



<p>The downside is that the open/close state is lost once the list view is closed. If I had one request, it would be to store this data while editing the post. That would improve the user experience with longer documents, particularly when switching between navigating and editing.</p>



<p>This update, along with the persistent behavior of the list view in Gutenberg 10.7, has made for a much more well-rounded document navigation experience.</p>



<h2>Rich URL Previews</h2>



<img />



<p class=\"has-drop-cap\">The editor will now <a href=\"https://github.com/WordPress/gutenberg/pull/31464\">show a website preview</a> in the link editor popup. This feature only works for links in a Rich Text context, such as in the Paragraph, Heading, and List blocks. The preview also only appears after the link has been set and clicked on, not when initially typing it.</p>



<p>If available, the popup preview displays the site icon, title, image, and description.</p>



<p>&ldquo;In the near future however, we expect to extend this to provide previews of internal URLs and to roll out support to more areas of the software,&rdquo; wrote George Mamadashvili in the Gutenberg 10.9 announcement post.</p>



<p>Admittedly, I was not keen on the idea of adding this feature. It felt like unnecessary bloat when more pressing issues were lying on the table. However, in the past day, I have enjoyed the quick previews when double-checking links in posts.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 25 Jun 2021 02:34:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"WPTavern: Jetpack Launches New Mobile App\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118883\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"https://wptavern.com/jetpack-launches-new-mobile-app?utm_source=rss&utm_medium=rss&utm_campaign=jetpack-launches-new-mobile-app\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3798:\"<div><img /></div>



<p>Automattic has launched a new <a href=\"https://jetpack.com/2021/06/21/jetpack-mobile-app/\">mobile app for Jetpack</a>, available on iOS and Android. The app features an array of Jetpack-specific features, as well as those applicable to users on paid plans, along with core WordPress features. </p>



<p>Inside it looks nearly identical to the official WordPress mobile apps, but it is noticeably missing WordPress.com specific features like the Reader. The bottom menu links to &ldquo;My Site&rdquo; and &ldquo;Notifications.&rdquo; </p>



<p>Those who are on paid Jetpack plans will have access to features like backups, restores, and security scanning for use inside the app when on the go. It also includes the same Activity Log and Stats features found in the main WordPress app. In its current state, it doesn&rsquo;t look like the app offers anything more than what you are used to on the standard mobile apps unless you are a <a href=\"https://jetpack.com/features/comparison/\">paid Jetpack customer</a>. So far, the app doesn&rsquo;t include any upgrade paths for free users or to jump from plan to plan. If Automattic decides to add in-app purchases, it will have to <a href=\"https://wptavern.com/automattic-tangles-with-apple-over-lack-of-in-app-purchases-in-the-wordpress-for-ios-app\">share the revenue with the app stores</a>. Having a separate app from the official mobile apps gives the company the option to build in more direct paths for monetization in the future.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>



<div><img /></div>



<p>You may want to stick with the official WordPress apps if you manage both WordPress.com and Jetpack-enabled sites, to keep everything conveniently in the same place. If you decide to use both apps, you will want to remove your Jetpack sites from the main WordPress app so that you aren&rsquo;t getting double notifications from having the site accessible through both apps.</p>



<p>Automattic&rsquo;s integrated products remain controversial features of the official WordPress apps. It is a good move to separate self-hosted Jetpack sites from the clutter of having WordPress.com-specific features in the app, but it does little for improving the official app&rsquo;s experience for self-hosted users who are not using Jetpack. Clicking on Stats in the app still prompts users to install Jetpack when managing self-hosted sites. The Reader menu item is ever-present at the bottom of the page. These products take up screen real estate regardless of whether they are being used. </p>



<p>A toggle to turn off these features in the app&rsquo;s settings might be a good stop-gap measure towards disentanglement, but ultimately the official mobile apps should not promote any commercial interests. </p>



<p>If Automattic moved WordPress.com features into the Jetpack app, then anyone using the company&rsquo;s products could be directed to this app for managing their sites. The official WordPress app could then be kept free of any products that the user doesn&rsquo;t choose to install. If the vanilla state of the app is not enough, users can be prompted to add themes and plugins to enhance the WordPress experience.</p>



<p>The Jetpack app is aimed at people who have sites using Jetpack but don&rsquo;t need the WordPress.com features that are built into the official WordPress apps. It brings more value to those who are on paid plans and want access to those features on the go. More than 500 people have already downloaded the Android app. It will be interesting to see if Jetpack users will gravitate towards the new app or remain on the standard WordPress app for more centralized management of Jetpack and non-Jetpack enabled websites.  </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Jun 2021 17:59:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Clove: A Showcase of Block Patterns by Anariel Design\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=119011\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:169:\"https://wptavern.com/clove-a-showcase-of-block-patterns-by-anariel-design?utm_source=rss&utm_medium=rss&utm_campaign=clove-a-showcase-of-block-patterns-by-anariel-design\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5403:\"<img />Clove theme homepage.



<p class=\"has-drop-cap\">Earlier today, Ana Segota <a href=\"https://twitter.com/Ana_Segota/status/1407694456418152458\">tweeted</a> and <a href=\"https://www.anarieldesign.com/free-full-site-editing-theme-clove/\">announced</a> via the Anariel Design blog that her company had submitted its second block-based theme to WordPress.org. Clove is a more well-rounded follow-up to her first such theme, <a href=\"https://wptavern.com/anariel-design-launches-naledi-a-block-based-wordpress-theme\">Naledi</a>. It is currently under review for inclusion in the official directory, but anyone can give it a test run by snagging the ZIP file from <a href=\"https://themes.trac.wordpress.org/ticket/101349\">its ticket</a>. Or, just peruse the <a href=\"https://anarieldesign.com/themedemos/clove/\">live demo</a>.</p>



<p>This should officially be the 10th <a href=\"https://wordpress.org/themes/tags/full-site-editing/\">block-based theme</a> to go live in the WordPress.org theme directory (note that a couple by Automattic are not tagged). That is assuming all goes well during the review process.</p>



<p>It has been a long road thus far, but 10 themes with the Full Site Editing tag is a notable milestone. The <a href=\"https://wptavern.com/exploring-full-site-editing-with-the-q-wordpress-theme\">Q theme</a> by Ari Stathopoulos was the first to land in the directory back in October 2020. Now, eight months later, there is still room for other theme authors to become pioneers in the space. With almost no competition, who will design that first block theme that squeezes its way into the most popular list?</p>



<p>If &ldquo;practice makes perfect,&rdquo; Segota is now ahead of the curve by pushing her second theme to the directory. This makes her theme company only one of two with multiple block themes.</p>



<p>Clove is experimental, as all block themes are. It relies on the ever-shifting parts of the Gutenberg plugin, but it all comes together into a floral, nature-themed design. There are hints of inspiration from Twenty Twenty-One, but it feels more structured, less chaotic.</p>



<p>The design is less of a theme and more of a showcase of block patterns and styles. Even on the template level, it reuses those same elements across each of its seven templates, providing multiple entryways for users to tinker with its features.</p>



<p>Clove even includes pricing columns.  I seem to recall writing about how theme authors could <a href=\"https://wptavern.com/you-might-not-need-that-block\">implement them via patterns</a> just over a month ago. Maybe the Anariel Design team came to the same conclusion. Maybe they took my message and ran with it. I like to think the latter is true. Either way, the result is a beautiful, theme-specific pattern &mdash; the sort of artistry that is tough to achieve from a plugin.</p>



<img />Customizing the Pricing Columns pattern in the WordPress editor.



<p>I am less of the fan of the overlapping and uneven columns in some of the designs designs, preferring some of the more-structured patterns, such as Three Quotes Images:</p>



<img />Three-column pattern that showcases images along with quotes.



<p>Despite my general dislike of the uneven column style, my favorite piece of the entire theme is the Illustrations page template, which leans into that design method.</p>



<p>The page intro section is an announcement to the world, &ldquo;Hey, check out my work.&rdquo;</p>



<img />Illustrations template intro section.



<p>I also like the Illustrations page template&rsquo;s widgets-like area in the footer. It manages to stuff several blocks in without feeling too crowded. It even showcases a box for artists to highlight their next exhibition.</p>



<img />Illustrations page template footer &ldquo;widget&rdquo; area.



<p>The Clove theme also registers 10 block styles for users to choose from. Most of them add different types of borders or frames to various elements. Plus, there is the fun-but-kind-of-an-oddball blob &ldquo;Shape&rdquo; for images.</p>



<ul><li class=\"blocks-gallery-item\"><img />Latest Posts &ndash; Dividers</li><li class=\"blocks-gallery-item\"><img />Image &ndash; Framed</li><li class=\"blocks-gallery-item\"><img />Image &ndash; Shape</li></ul>



<p>Segota was one of several people to submit custom designs to the upcoming block pattern directory. There is some noticeable crossover between her current theme work and submissions, such as the <a href=\"https://github.com/WordPress/pattern-directory/issues/149\">Playful Gallery</a> pattern that did not quite make the cut. Others, like her <a href=\"https://wordpress.org/patterns/pattern/recipe/\">Recipe design</a>, did. There is still an <a href=\"https://wptavern.com/open-invitation-to-contribute-to-the-wordpress-block-pattern-directory\">open invitation for people to contribute</a>.</p>



<p>I am always like a kid in a toy store when a new block theme comes along, reaching out to grab the latest gadget. I want to see more experiments like Clove. Keep them coming, theme authors.</p>



<p><strong>Side note:</strong> For people interested in the background-clipped text design used in Clove&rsquo;s site logo, I <a href=\"https://github.com/WordPress/gutenberg/issues/32787\">opened a ticket</a> to take us one step closer to doing it in the editor. Currently, users must create an off-site image and upload it.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Jun 2021 01:23:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WordPress Foundation: Answering FAQs on WordPress Trademarks and their usage\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://wordpressfoundation.org/?p=189036\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://wordpressfoundation.org/2021/answering-faqs-on-wordpress-trademarks-and-their-usage/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6388:\"<p class=\"has-drop-cap\">The WordPress Foundation owns and <a href=\"https://wordpressfoundation.org/trademark-policy/\">manages trademarks</a> for the WordPress and WordCamp names and <a href=\"http://wordpress.org/about/logos/\">logos</a>. Over the years, many people have approached us with questions on WordPress trademarks and how to use them. This blog post aims to address some of the most common questions and clarify the usage of WordPress trademarks.</p>



<h3>Can I use “WordPress” in my name?</h3>



<p>Strictly speaking, you cannot use “WordPress” in your website name or your product name. As mentioned in the <a href=\"https://wordpressfoundation.org/trademark-policy/\">WordPress Foundation trademarks page</a>:  </p>



<blockquote class=\"wp-block-quote\"><p><em>Permission from the WordPress Foundation is required to use the WordPress or WordCamp name or logo as part of any project, product, service, domain name, or company name.</em></p></blockquote>



<p>The purpose of trademark law is to keep others from using or misusing a trademarked name or logo. But it cannot stop them from picking it up. Sometimes, people use “WordPress” in their name, title, URL, or username when “WordPress” really does not belong there. However, such uses of the trademark violate the WordPress trademark nevertheless, and cannot be allowed.</p>



<h3>What is the actual trademark Policy?</h3>



<p>You can find the entire written Trademark policy on the <a href=\"https://wordpressfoundation.org/trademark-policy/\">Trademarks policy page</a> of this website. In short, the purpose of this policy is to make it easy for anyone to use the WordPress or WordCamp name or logo for community efforts that spread and improve WordPress. It also aims to make it difficult for anyone to use the WordPress or WordCamp name or logo to trick or confuse people looking for official WordPress or WordCamp resources. When you are in doubt, ask yourself this question: <em>“Is this an “official” WordPress event or resource?” </em>If the answer is “no,” then you should leave the trademarked name “WordPress” or “WordCamp” out of it.</p>



<h3>Does this mean I cannot build something for WordPress?</h3>



<p><strong>NO. </strong>The trademark policy <strong>does not</strong> restrict people from building anything for WordPress. WordPress, both the software and the community surrounding it, is open source. It takes all kinds of contributors to create, build, support, maintain, educate, and energize WordPress. But it does mean if you are creating something within the WordPress space that is not officially part of the WordPress project, you should not use the name “WordPress” to name it. However, you can use an alternative name like “WP” instead of “WordPress” for your products.&nbsp;</p>



<h3>I was unaware of the Trademark policy and already created something using “WordPress” in the name or the URL. What do I do now?</h3>



<p>If you happen to be in that position and you want to figure out how to fix things, please feel free to reach out to <a href=\"mailto:trademarks@wordpressfoundation.org\">trademarks@wordpressfoundation.org</a> (or send us a message through the <a href=\"https://wordpressfoundation.org/trademark-policy/\">contact form</a> on this site), and someone will help you bring your site, event, or product into compliance with the WP Trademark.&nbsp;</p>



<h3>Does the trademark policy apply to WordPress swag?&nbsp;</h3>



<p>Yes. Using the WordPress logo in products or any sort of swag is not permitted. Without express permission from WordPress Foundation, you cannot sell WordPress goods or co-brand your goods to make them seem affiliated with WordPress.</p>



<p>However, WordPress swag (shirts, stickers, bags, hand sanitizer, stuffed animals, sweatshirts, mugs, cups, pencils… to name a few) &#8211; given out at a WordCamp is okay. Branded WordPress swag from sponsors at a WordCamp is also allowed. This is because the swag is being given out for free (not for profit) at an official WordPress event, and has been approved. You can also find approved WordPress swag in the <a href=\"https://mercantile.wordpress.org/\">official WordPress swag store</a>.</p>



<h3>Reading all this, I realize someone I know is not in compliance with the Trademark. What should I do?</h3>



<p>The first thing is to remember that this person could be unaware they are not complying with the trademark. We want to assume good intent whenever possible. You can talk to them about it if you feel comfortable or even just share <a href=\"https://wordpressfoundation.org/trademark-policy/\">the trademark policy</a> with them. Alternatively, you can submit information to the <a href=\"https://wordpressfoundation.org/contact/\">Trademarks contact form</a> on the site or send an email to trademarks@wordpressfoundation.org and let someone there do the work of assuming good intent and reaching out to them.</p>



<h3>I have already reported this site/thing/person, and nothing has been done!</h3>



<p>The process of resolving trademark issues takes a while, so we have assigned more bandwidth to speed up the process.  If you have reported something in the past, know that it is being worked on in the coming months. If you are worried that it got lost, you are welcome to send it in again. </p>



<h3>Is there anything I can do to help?</h3>



<p>The biggest help anyone in WordPress can give is to respect the Trademark themselves. I know that it seems like passive work for many, and you may be looking to do something actively. Being an active and respectful part of a community is a big help, though.</p>



<p><em>This post is based on </em><a href=\"https://make.wordpress.org/community/2021/03/30/tuesday-trainings-can-i-use-wordpress-in-my-product-name/\"><em>Part 1</em></a><em> and </em><a href=\"https://make.wordpress.org/community/2021/04/06/tuesday-trainings-can-i-use-wordpress-in-my-product-name-part-2-of-2/\"><em>Part 2</em></a><em> of the “Can I use “WordPress” in my product name?” </em><a href=\"https://make.wordpress.org/community/tag/tuesdaytrainings/\"><em>Tuesday Training</em></a><em> from </em><a href=\"https://profiles.wordpress.org/camikaos\"><em>@camikaos</em></a><em> in the </em><a href=\"https://make.wordpress.org/community/\"><em>Make WordPress Communities</em></a><em> blog.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Jun 2021 09:08:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Hari Shanker\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.8 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10843\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5564:\"<p>WordPress 5.8 Beta 3 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 3 in three ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the&nbsp;<code>Bleeding edge</code>&nbsp;channel and the&nbsp;<code>Beta/RC Only</code> stream).</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta3.zip\">zip</a>).</li><li>Using WP-CLI to test: <code>wp core update --version=5.8-beta3</code></li></ul>



<p>The current target for the final release is July 20, 2021. That’s just <strong>four weeks away</strong>, so we need your help to make the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-2/\">Beta 2</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=06%2F16%2F2021..06%2F23%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">38</a> bugs have been fixed. Here is a summary of some of the included changes:</p>



<ul><li>Block Editor: Move caching to endpoint for unique responses. (<a href=\"https://core.trac.wordpress.org/ticket/53435\">#53435</a>)</li><li>Bundled Themes: Improve display of blocks in widget areas. (<a href=\"https://core.trac.wordpress.org/ticket/53422\">#53422</a>)</li><li>Coding Standards: Bring some consistency to HTML formatting in <code>wp-admin/comment.php</code>. (<a href=\"https://core.trac.wordpress.org/ticket/52627\">#52627</a>)</li><li>Editor: Include Cover block in the list of block types registered using metadata files. (<a href=\"https://core.trac.wordpress.org/ticket/53440\">#53440</a>)</li><li>Editor: Include Cover block in the list of block types registered using metadata files. (<a href=\"https://core.trac.wordpress.org/ticket/53440\">#53440</a>)</li><li>Media: Add new functions to return the previous/next attachment links. (<a href=\"https://core.trac.wordpress.org/ticket/45708\">#45708</a>)</li><li>Media: Improve upload page media item layout on smaller screens. (<a href=\"https://core.trac.wordpress.org/ticket/51754\">#51754</a>)</li><li>Media: Update total attachment count when media added or removed. (<a href=\"https://core.trac.wordpress.org/ticket/53171\">#53171</a>)</li><li>REST API: Decode single and double quote entities in widget names and descriptions. (<a href=\"https://core.trac.wordpress.org/ticket/53407\">#53407</a>)</li><li>Twenty Nineteen: Update margins on full- and wide-aligned blocks in the editor. (<a href=\"https://core.trac.wordpress.org/ticket/53428\">#53428</a>)</li><li>Widgets: Add editor styles to the widgets block editor. (<a href=\"https://core.trac.wordpress.org/ticket/53344\">#53344</a>)</li></ul>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=..06%2F23%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">254 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&status=reopened&changetime=..06%2F23%2F2021&type=enhancement&type=feature+request&milestone=5.8&group=component&col=id&col=summary&col=type&col=status&col=milestone&col=changetime&col=owner&col=priority&col=keywords&order=changetime\">91 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\"https://profiles.wordpress.org/jeffpaul/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>jeffpaul</a> <a href=\"https://profiles.wordpress.org/desrosj/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>desrosj</a> <a href=\"https://profiles.wordpress.org/hellofromtonya/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>hellofromtonya</a> <a href=\"https://profiles.wordpress.org/pbiron/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>pbiron</a> for reviews and final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Esperanza first.<br />Want to know the next jazzer?<br />Then please test beta.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Jun 2021 02:36:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: WordPress Theme Lock-In, Silos, and the Block System\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118923\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:165:\"https://wptavern.com/wordpress-theme-lock-in-silos-and-the-block-system?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-theme-lock-in-silos-and-the-block-system\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6343:\"<p class=\"has-drop-cap\">For many years, I was a hardcore advocate of separating any non-design functionality from themes into their own plugins. I wrote extensively on the issue. Whether it was shortcodes, custom post types, user metadata, and any number of things related to a user&rsquo;s content/data, I drew a deep line in the sand. <em>This belongs in a plugin.</em></p>



<p>If you have never heard of the &ldquo;theme lock-in effect,&rdquo; that&rsquo;s OK. For many, it is a non-issue. Places like the WordPress.org theme directory have, for the most part, drew a similar line in the sand.</p>



<p>The goal has always been to avoid trapping a user into perpetual use of a particular theme. It is not an ideal user experience when some crucial data is no longer available when switching designs. And, all users eventually want to change that up from time to time. Getting stuck with <code>[shortcode-soup]</code> tags littered throughout a site is never fun. Neither is losing admin access to dozens, hundreds, or even thousands of pages from a custom post type that suddenly disappears.</p>



<p>The WordPress theme development community has avoided this problem &mdash; some more so than others &mdash; by bundling crucial content-related features separately in plugins.</p>



<p>Those theme authors who bypassed theme lock-in via plugins have mostly done so in their own silos. For example, instead of integrating with an existing portfolio plugin, they would just create their own. <em>The only themes that support that plugin?</em> Theirs. Ultimately, users were still trapped.</p>



<p>I cannot lay the entire weight of this issue on the shoulders of theme authors. Portfolio plugins are a dime a dozen. Supporting WooCommerce for an eCommerce solution or bbPress for forums are easy choices. But, when there is no clear industry front-runner, an in-house solution is just as good as most others.</p>



<p>However, the block system is already complicating matters. When a theme supports features like font sizes, colors, and gradients, it essentially locks users in. Switch to another with a different configuration, and every font size, color, and gradient the user chose to use is gone.</p>



<p>Imagine inserting a Paragraph block and choosing that sky blue from your theme as the block&rsquo;s background. Now, imagine doing this a few hundred times only to have it disappear a couple of years down the road when you want to switch designs.</p>



<p>I won&rsquo;t dive into the technical details of how this works under the hood. It is just the way the system was designed. Some problems <a href=\"https://github.com/WordPress/gutenberg/issues/7553\">could have been mitigated early on</a>, but that ship sailed two and a half years ago with the launch of WordPress 5.0. There are also ways this might be solved in the future with technical workarounds.</p>



<p>Last week, a reader named Nick <a href=\"https://wptavern.com/getting-to-know-the-upcoming-wordpress-5-8-template-editor#comment-382930\">brought up this issue</a> in regards to block patterns. The theme in question used custom CSS classes to achieve a specific design.</p>



<blockquote class=\"wp-block-quote\"><p>Because Gutenberg lacks all the features mentioned above, the theme uses some custom CSS classes, and these classes are coded in the theme&rsquo;s style sheet. The problem with this is that now that you have used these patterns, YOU ARE LOCKED IN to this theme. Because the moment you change themes, the new theme will not have these custom classes defined, the patterns will be broken. This is THE SAME reason why shortcodes were outlawed many years ago from inside the themes &mdash; and yet when it comes to patterns, this is somehow allowed?</p></blockquote>



<p><strong>Note:</strong> Shortcodes were disallowed in the WordPress theme directory because the actual post content was broken on theme switch. It was unrelated to a broken design.</p>



<p>I already hear what some of you are thinking. <em>This is not the same as &ldquo;content&rdquo; lock-in.</em> No, it is not. Not exactly. However, because the block system intertwines content and design, it sort of is. I doubt the average user appreciates the distinction when they end up in scenarios with white text on a white background, as shown in the following screenshots:</p>



<ul><li class=\"blocks-gallery-item\"><img />Blue background with one theme.</li><li class=\"blocks-gallery-item\"><img />Blue background gone with second theme.</li></ul>



<p>That is a <em>very</em> real scenario. I see it almost daily as I test out different themes.</p>



<p>And, this is just the beginning. As WordPress&rsquo;s design system grows and themers can configure more pieces, users will become more locked into their existing theme. Or, they may be locked into one developer&rsquo;s or one shop&rsquo;s way of doing things.</p>



<p>I do not necessarily see this as a <em>Bad Thing</em>. We have always had these little silos in the WordPress ecosystem, and they have mostly worked out.</p>



<p>In a sense, little has changed.</p>



<p>Users often stick with the same theme companies for one reason or another. And, those same themers tend to build on top of homegrown libraries or frameworks, reusing the same systems &mdash; at least the best ones do. This usually means that users can freely switch between themes made by the same people without losing anything.</p>



<p>The old-school purity test of not mixing content and design is gone.</p>



<p>This is a chance for solo developers and shops to strengthen their brand. If this is the system that WordPress is providing, build strong products on top of it. Build naming schemes that allow users to switch between your themes. Create loyal customers who will want to stick with you for years.</p>



<p>If users are essentially locked into one shop&rsquo;s theme products, that sounds like a lucrative opportunity to build solutions and healthy user communities around individual brands.</p>



<p>I also envision a future where users will need to switch themes far less often. After the site editor and global styles features become available, users will have more direct control over their design. Once they have settled on a solid theme, they may never need to change it as long as it stays relatively up to date.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 23 Jun 2021 01:04:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: WooCommerce Selects Paystack as Preferred Payments Partner in Africa\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118666\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://wptavern.com/woocommerce-selects-paystack-as-preferred-payments-partner-in-africa?utm_source=rss&utm_medium=rss&utm_campaign=woocommerce-selects-paystack-as-preferred-payments-partner-in-africa\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3656:\"<p>WooCommerce has named Paystack its preferred payments partner for&nbsp;WooCommerce in Africa. More than 20,000 merchants are using the free  <a href=\"https://wordpress.org/plugins/woo-paystack/\">Paystack WooCommerce Payment Gateway</a> plugin but searching for and downloading the plugin separately is no longer required. Store owners can now easily select Paystack as a payment method when inside the WooCommerce dashboard.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Paystack has a recently updated tutorial for <a href=\"https://support.paystack.com/hc/en-us/articles/360009881280-How-to-set-up-Paystack-on-WooCommerce\">how to set up the gateway in WooCommerce</a>. As an alternative to the recommended method, merchants can opt to <a href=\"https://wordpress.org/plugins/woo-paystack/\">install the free plugin</a> instead.</p>



<p>Paystack is the most widely used payment gateway in Africa, accounting for more than half of all online transactions in Nigeria. More than 60,000 stores use the gateway. In October 2020, it was <a href=\"https://wptavern.com/stripe-acquires-paystack-for-200m\">acquired by Stripe</a> for more than $200M. The gateway can be used by businesses in Nigeria and Ghana and last month it <a href=\"https://paystack.com/blog/company-news/sa-launch\">added support for South Africa</a>, after a six-month long pilot program. </p>



<p>&ldquo;Paystack is leading the charge in bringing a world-class payments experience to African merchants,&rdquo; WooCommerce Director of Business Development Mechiel Couvaras said. &ldquo;Their product offering, user experience, and expansion plans within Africa were some of the most important factors in considering the partnership. Receiving funding from&nbsp; Stripe and Visa was also a strong indicator of their potential.&rdquo;</p>



<p>Paystack, like all of WooCommerce&rsquo;s other payment partners, has a financial arrangement with the e-commerce platform where it pays a percentage of transactions processed. Couvaras said the Paystack partnership is directly with Paystack and separate from WooCommerce&rsquo;s Stripe partnership.</p>



<p>&ldquo;eCommerce is still very nascent in most African countries, however, <a rel=\"noreferrer noopener\" href=\"https://trends.builtwith.com/shop/WooCommerce-Checkout/Nigeria\" target=\"_blank\">Nigeria</a> and <a rel=\"noreferrer noopener\" href=\"https://trends.builtwith.com/shop/WooCommerce-Checkout/South-Africa\" target=\"_blank\">South Africa</a> are amongst our fastest growing countries globally,&rdquo; Couvaras said. When Stripe acquired Paystack, the company noted that African online commerce is growing 21% year-over-year, 75% faster than the global average. WooCommerce is well-positioned to capture some of that growth with Paystack pre-installed as a preferred payment partner.</p>



<p>The e-commerce platform is also keeping tabs on other emerging markets, as global market adoption has grown to <a href=\"https://w3techs.com/technologies/details/cm-woocommerce\">8.2% of the Alexa top 10 million websites</a>. Over the past year WooCommerce launched partnerships with Indian payment companies <a rel=\"noreferrer noopener\" href=\"https://woocommerce.com/products/razorpay-for-woocommerce/\" target=\"_blank\">Razorpay</a> and <a rel=\"noreferrer noopener\" href=\"https://woocommerce.com/products/payu-india/\" target=\"_blank\">PayU India</a>, as well as <a rel=\"noreferrer noopener\" href=\"https://woocommerce.com/products/mercado-pago-checkout\" target=\"_blank\">Mercado Pago</a>, a Latin American payments company focused on supporting local payment methods across Mexico, Brazil, Argentina, Colombia, Chile, Peru and Uruguay.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Jun 2021 20:52:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: A Throwback to the Past: Refreshing Old Twenty* WordPress Themes With Block Patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118898\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:229:\"https://wptavern.com/a-throwback-to-the-past-refreshing-old-twenty-wordpress-themes-with-block-patterns?utm_source=rss&utm_medium=rss&utm_campaign=a-throwback-to-the-past-refreshing-old-twenty-wordpress-themes-with-block-patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5915:\"<p class=\"has-drop-cap\">What <a href=\"https://wptavern.com/past-twenty-wordpress-themes-to-get-new-block-patterns\">began as a project in August 2020</a> has now become a reality. All past Twenty* default WordPress themes now have their own unique block patterns. In recent weeks, <a href=\"https://make.wordpress.org/core/2021/06/21/bundled-themes-changes-in-wordpress-5-8/\">Twenty Ten through Twenty Fifteen received updates</a>.</p>



<p>Designer Mel Choyce-Dwan kick-started tickets for all previous 10 default themes before the WordPress 5.5 release, the first version to support patterns. Twenty Twenty, Twenty Nineteen, Twenty Seventeen, and Twenty Sixteen each made the cut for that update. However, the remaining default themes were left to languish, at least for a few months and WordPress updates.</p>



<p>Jumping back over a decade to update past themes might seem extreme, but all of the default themes are still some of the most popular from the directory. Granted, they had the benefit of being installed directly in WordPress. Still, the current number of active installations means they are worth a small refresh:</p>



<ul><li>Twenty Fifteen: 100,000+</li><li>Twenty Fourteen: 100,000+</li><li>Twenty Thirteen: 70,000+</li><li>Twenty Twelve: 100,000+</li><li>Twenty Eleven: 100,000+</li><li>Twenty Ten: 100,000+</li></ul>



<p>Despite having the lowest installation total, Twenty Thirteen has some of the best pattern designs. The Informational Section and Decorative Gallery patterns stand out the most, but all fit well with the overall theme design.</p>



<ul><li class=\"blocks-gallery-item\"><img />Informational Section</li><li class=\"blocks-gallery-item\"><img />Decorative Gallery</li></ul>



<p>Twenty Thirteen is also the only remaining default theme that supports wide and full alignments. Its one-column layout affords it more flexibility, and the old design feels fresh again with its new pattern choices. Perhaps they can revive the theme&rsquo;s lagging numbers relative to the other defaults.</p>



<p>The <a href=\"https://core.trac.wordpress.org/ticket/51104\">initial pattern designs</a> for the theme included a suite of layouts for post formats, one of the features Twenty Thirteen leaned on. Something similar to the first gallery design landed, but the others were left out.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Patterns designed to match post formats.



<p>Post formats never garnered widespread support past their launch, and the core development team all but abandoned them, never building atop the feature. However, all of the format-specific patterns might be welcome for those users still running the theme. They would have been a nostalgic nod to the old WordPress, a throwback to yesteryear. If nothing else, maybe they can serve as inspiration for those of us still clinging to that tiny sliver of hope that post formats will make a roaring comeback.</p>



<p>These theme-bundled designs highlight how the <a href=\"https://wptavern.com/open-invitation-to-contribute-to-the-wordpress-block-pattern-directory\">upcoming pattern directory</a> is not meant to be the only destination for snagging the best layout sections to drop into the block editor. Often, the best choices will be specific to the theme. Much of the flavor of custom design is lost when building for a general audience. What looks good with Twenty Twenty-One may look terrible in another and vice versa. Maybe that will change as block design tools become more robust and how they are used becomes standardized, but for now, at least, the most artistic patterns are those that designers include with their themes.</p>



<p>Aside from Twenty Thirteen, Twenty Ten&rsquo;s new patterns stood out the most. The theme was the first of the new era of yearly themes, and its classic blog design has weathered the years well &mdash; just ignore the 12-pixel sidebar font size.</p>



<img />Twenty Ten&rsquo;s new patterns.



<p>The three patterns are at home in the theme. The Introduction pattern, which showcases the Image, Heading, and Paragraph blocks, is simple, but it relies on Twenty Ten&rsquo;s typography for an elegant article intro. The Quote and Alternating image layouts do not try to do too much, simply highlighting the theme&rsquo;s design.</p>



<p>Landing squarely in my favorite-but-most-disappointing category was Twenty Fourteen. The About pattern&rsquo;s image and text looked elegant and roomy in the editor, but the front-end view painted a different picture. Because the theme lacks wide-alignment support, the photo was scrunched up. The gallery-supported Summary pattern has a lot of potential as a full-width pattern, but it falls short in the theme&rsquo;s 474-pixel wide content area.</p>



<ul><li class=\"blocks-gallery-item\"><img />About Pattern</li><li class=\"blocks-gallery-item\"><img />Summary Pattern</li></ul>



<p>There is really no reason why Twenty Fourteen could not support wide and full alignments. It has free space.</p>



<p>At least the timeline-esque List pattern is pretty sweet in both the editor and front-end views. I may borrow that for my own projects.</p>



<img />List pattern included with Twenty Fourteen.



<p>I was not particularly excited over the other patterns, but I am happy to see a little love thrown toward the 600,000 or so users with these themes still active. I am sure many will find something they can use on their own sites.</p>



<p>The themes are aging; the wrinkles and weaknesses of their designs are showing. With the site editor looming ahead, it might be time to consider retiring them. That is assuming no one wants to take the reigns and update them for a modern era. Otherwise, they will continue falling behind, remaining a relic of classic WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Jun 2021 23:14:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"WPTavern: Google Launches Search Console Insights, a User-Friendly Content Performance Overview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118774\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"https://wptavern.com/google-launches-search-console-insights-a-user-friendly-content-performance-overview?utm_source=rss&utm_medium=rss&utm_campaign=google-launches-search-console-insights-a-user-friendly-content-performance-overview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2428:\"<p>Google Analytics is powerful if you know exactly what kind of metrics you want to investigate, it but can be overwhelming if you just need a simple overview of your traffic and referrals. <a href=\"https://search.google.com/search-console/insights/\">Search Console Insights</a> is a new tool from the <a href=\"https://blog.google/web-creators\">Google Web Creators</a> team that is aimed at making content performance easier to understand at a glance. It combines data from Search Console and Google Analytics for a user-friendly overview of important metrics for content creators.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Search Console Insights can help users quickly ascertain which pieces are their best performing content, how new pieces are performing, and how people are discovering the site. Clicking on the little academic cap icon offers more information about understanding the data and tips for improving content engagement and performance.</p>



<p>The first section shows a site&rsquo;s content performance trend for the past 28 days using page views and page view duration. The next card displays a carousel of new content with page views, average page view duration, and badges for content that has high average duration compared to other content on the site.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Other cards include the most popular content within the past 28 days, top traffic channels, top Google Search queries, referring links from other websites, and social media.</p>



<p>The performance cards are not configurable but they give you a starting point if you want to dig deeper into Google Analytics. It would be helpful if each graph was linked to more data where you could adjust the date range.</p>



<p>Search Console Insights doesn&rsquo;t include all the features unless you are using Google Analytics and associate it with your site&rsquo;s Search Console property. Users can access the tool&rsquo;s overview page by visiting the <a href=\"https://search.google.com/search-console/insights\">link</a> directly. In the near future, Search Console Insights will be available in the iOS and Android Google apps when you tap your profile picture. The tool is <a href=\"https://blog.google/web-creators/improve-your-content-search-console-insights/\">now in beta</a> but Google plans to roll the experience out gradually to all Search Console users in the coming days.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Jun 2021 18:43:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WordPress.org blog: WP Briefing: Episode 11: WordCamp Europe 2021 in Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10837\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wordpress.org/news/2021/06/episode-11-wordcamp-europe-2021-in-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10494:\"<p>In this episode, Josepha Haden Chomphosy does a mini deep dive into WordCamp Europe 2021, specifically the conversation between the project’s co-founder, Matt Mullenweg, and Brian Krogsgard formerly of PostStatus. Tune in to hear her take and for this episode’s small list of big things.</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<p>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></p>



<p>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></p>



<p>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></p>



<p>Song: Fearless First by Kevin MacLeod</p>



<h2>References </h2>



<p><a href=\"https://wordpress.org/news/2021/06/gutenberg-highlights/\">Gutenberg Highlights&nbsp;</a></p>



<p><a href=\"https://www.youtube.com/watch?v=o-IvKy3322k&t=12428s\">Matt Mullenweg in conversation with Brian Krogsgard&nbsp;</a></p>



<p><a href=\"https://make.wordpress.org/core/5-8/\">5.8 Development Cycle</a></p>



<p><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></p>



<p><a href=\"https://europe.wordcamp.org/2021/a-recap-on-wceu-2021/\">A recap on WCEU 2021</a></p>



<h2>Transcript</h2>



<span id=\"more-10837\"></span>



<p><strong>Josepha Haden Chomphosy 00:10</strong></p>



<p>Hello, everyone, and welcome to the WordPress Briefing, the podcast where you can catch quick explanations of the ideas behind the WordPress open source project, some insights into the community that supports it, and get a small list of big things coming up in the next two weeks. I&#8217;m your host, Josepha Haden Chomphosy. Here we go!</p>



<p><strong>Josepha Haden Chomphosy 00:40</strong></p>



<p>A couple of weeks ago, we hosted WordCamp Europe and had the double pleasure of a demo that showed us a bit about the future of WordPress and an interview that looked back while also looking a bit forward. If you haven&#8217;t seen the demo, it was beautiful. And I&#8217;ve included a link to it in the show notes. And if you haven&#8217;t heard the interview, there were a few specific moments that I&#8217;d like to take the time to delve into a little more. Brian Krogsgard, in his conversation with Matt Mullenweg, brought up three really interesting points. I mean, he brought up a lot of interesting points, but there were three that I would particularly like to look into today. The first was about balance. The second was about cohesion. And the third was about those we leave behind.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 01:24</strong></p>



<p>So first is this question of balance. Brian brought this up in the context of the overall economic health of the WordPress ecosystem. And in that particular moment, he talked about companies that are coming together, companies that are merging. And in Matt&#8217;s answer, the part that I found the most interesting was when he said, &#8220;the point at which there is the most commercial opportunity is also the point at which there is the most opportunity for short-termism. He went on to talk about the importance of long-term thinking and collective thinking about what makes us, and us here means probably the WordPress project, more vibrant and vital in 10 or 20 or 30 years. One of the things that he specifically called out in that answer was the responsibility of larger companies in the ecosystem. For instance, like Automattic, to commit fully to giving back, there are many ways now that companies can give back to WordPress so that we all replenish the Commons. They can pay for volunteer contributors&#8217; time; they can create and sponsor entire teams through the Five for the Future program. They can contribute time through our outreach program. And they can even contribute to WordPress&#8217;s ability to own our own voice by engaging their audience&#8217;s awareness of what&#8217;s next in WordPress, or whatever. And I know this balance, this particular balance of paid contributors or sponsored contributors, compared to our volunteer contributors or self-sponsored contributors; I know that this balance is one that people keep an eagle eye on. I am consistently on a tight rope to appropriately balanced those voices. But as with so many things where balance is key, keeping an eye on the middle or the long-distance can really help us get it right.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 03:23</strong></p>



<p>The second question was one of cohesion and specifically cohesion over the competition. Brian asked how, if people feel disadvantaged, you can foster a feeling of cohesion rather than competition? And Matt&#8217;s first answer was that competition is great. Specifically, he said that competition is great as long as you consider where your collaboration fits into the mission. And he also spent some time exploring how competitors in the ecosystem can still work from a community-first mindset. I personally cannot agree enough about some of the benefits of collaboration alongside your competitors. I remind sponsored contributors from time to time, and I think it&#8217;s true for any contributor that you are an employee of your company first and a contributor to WordPress second. However, once you step into contribution time, your main concern is the users of WordPress, or new contributors, or the health of the WordPress ecosystem as a whole or the WordPress project. So you get all this subject matter expertise from competitive forces, collaborating in a very us versus the problem way. And when you do that, you&#8217;re always going to find a great solution. It may not be as fast as you want it to build things out in the open in public. And so sometimes we get it wrong and have to come back and fix it but still, given time, we&#8217;re going to come out with the best solution because we have so many skilled people working on this.&nbsp;&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 05:01</strong></p>



<p>And then the third question that I wanted to really touch on is the question of those we leave behind. Brian asked Matt if he thought mid-sized agencies and mid-sized consultants were being squeezed out with the block editor. Matt&#8217;s high-level answer was no, and I tend to agree with him. It&#8217;s not all mid-sized anything any more than it&#8217;s all small-sized anything. His answer continued to look at what stands to change for users with the block editor and who really can stand to benefit. It made me think back to my WordPress 5.0 listening tour. We launched WordPress 5.0, which was, in case anyone forgets, the first release with the block editor in it. I took a six-month-long tour to anywhere that WordPressers were so I could hear their main worries, what Brian is saying in there, and what Matt is saying to really came up all the time in those conversations. And basically, it was that this update takes all the power away from people who are building websites. And in these conversations, and Matt and Brian&#8217;s conversation, it was really focused on our freelancers and consultants. But at the same time, all of them heard that this update gives power back to all of the people who could build websites.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 06:28</strong></p>



<p>I could not shake the feeling at the time. And honestly, I can&#8217;t shake it now that no high-end consultants, or freelancers, or any other developer or site creator sit around just longing for maintenance work. After six months of talking to people, I didn&#8217;t hear anyone say, &#8220;you know, I just love making the same author card over and over and over.&#8221; Or, &#8220;updated the footer every week, this month. And that&#8217;s why I got into this business.&#8221; And more than the feeling that there just wasn&#8217;t anyone who just loved maintenance, I got a feeling that there were real problems that needed to be solved for these clients and that they wanted to solve them. And that they also would gladly trade updating footers for the much more interesting work of creating modern and stylish business hubs based on WordPress for the clients who trust them so much. All of that, I guess, is to say that, yes, the block editor does give power back to our clients again, but not at the expense of those who have to build the sites in the first place. I think it stands to restore everyone&#8217;s sense of agency more than we truly realize. So that&#8217;s my deep dive on WordCamp Europe; I included links to the demo and the talk below, just in case you haven&#8217;t seen them yet. And you want to get a little bit of insight into the full context of the conversations that I just did a bit of a deep dive into.&nbsp;</p>



<p><strong>Josepha Haden Chomphosy 08:15</strong></p>



<p>And now it&#8217;s time for our smallest of big things. All right, I have three things for you today. Number one, tomorrow, we package WordPress 5.8 beta three. If you&#8217;ve never had a chance to stop by the core channel in slack for the past packaging process, I really encourage you to stop by; we call them release parties. It&#8217;s a bunch of people who stand around and help get it done. So you can also see how it gets done. And if you&#8217;re feeling brave, you can even try your hand at testing out one of the packages as soon as it&#8217;s ready. The second thing is that a week from tomorrow, we reach our first release candidate milestone. So if you have meant to submit any bugs or patches or if you&#8217;ve been procrastinating on documentation, or dev notes, right now is the time so that we can have a chance to get everything into the release by the time we reach the release candidate milestone on the 29th. And the third thing is that we are currently right in the middle of WordCamp Japan. That is a great opportunity to meet some contributors and maybe even get started with contributions yourself. So stop by if you haven&#8217;t had a chance to check it out already. I will leave a link in the show notes. And that, my friends, is your small list of big things. </p>



<p>Thank you for tuning in today for the WordPress Briefing. I&#8217;m your host, Josepha Haden Chomphosy, and I&#8217;ll see you again in a couple of weeks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Jun 2021 12:33:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"Gutenberg Times: Block-based Template Editor is coming to WordPress 5.8 and a new Widget Editor – Weekend Edition #174\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=18214\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"https://gutenbergtimes.com/block-based-template-editor-is-coming-to-wordpress-5-8-and-a-new-widget-editor-weekend-edition-174/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14624:\"<p>Howdy, </p>



<p>Lots happening in the larger WordPress space! More aquisitions and a new service for WordPress plugin business, flippantly named <a href=\"https://flipwp.co/\">FlipWP</a>. </p>



<p><a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-2/\">WordPress 5.8 Beta 2</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v10.9.0-rc.1\">Gutenberg 10.9 RC</a> released and the first dev notes dropped for the upcoming release. More on that below. </p>



<p>Don&#8217;t miss next week&#8217;s <strong>Live Q &amp; A on June 24, 2021, at 11am EDT / 15:00 UTC</strong> on theme.json for Theme Authors with our panelists Daisy Olson, Tammie Lister and Jeff Ong. Learn and discuss <a href=\"https://us02web.zoom.us/webinar/register/4216223029678/WN_gyOVb1h4S4iO_UZi1GMQaA\">How to get started with building themes for Full-site editing.</a></p>





<p>What are you working on?  Creativity is mushrooming around the WordPress ecosystem and I want to learn from you! Hit reply and let me know! I loved your notes in my inbox! Thank you. </p>



<p>Yours, ?<br />Birgit </p>





<hr class=\"wp-block-separator\" />



<h2>WordPress 5.8 DevNotes and more</h2>



<p><strong>Grzegorz Ziolkowski</strong> posted the article <strong><a href=\"https://make.wordpress.org/core/2021/06/16/block-editor-api-changes-to-support-multiple-admin-screens-in-wp-5-8/\">Block Editor API Changes to Support Multiple Admin Screens</a>.</strong> &#8220;WordPress 5.8 is the first&nbsp;core&nbsp;release where the post editor is no longer the only&nbsp;admin&nbsp;screen that uses the&nbsp;block&nbsp;editor. The updated widgets editor screen will also support blocks.&#8221;, he wrote. It&#8217;s quite technical and developers will appreciate it as it opens the doors to use the bock editor on other admin screen, for instance for plugin dashboards and features. It makes my long time wish possible:  replace the &#8220;Quick Draft&#8221; widget with an instance of the block editor and have writers start writing immediately after login, instead of having to open yet another screen. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong>Riad Benguella</strong> introduces us to the <a href=\"https://make.wordpress.org/core/2021/06/16/introducing-the-template-editor-in-wordpress-5-8/\"><strong>Template Editor coming to WordPress</strong></a> in its 5.8 release. It comes with a series of new blocks to accommodate Site-wide information, like Site Title or Site Logo as well as post parts for the Query Block, like Post Title, Post Excerpt, Feature Image. In total, 13 Blocks that replace some template parts in conventional themes.  Some blocks will be made <a href=\"https://github.com/WordPress/gutenberg/issues/28744\">available also for classic Themes </a>to accommodate <a href=\"https://github.com/WordPress/gutenberg/issues/29024\">hybrid themes</a> and to support the gradual adoption of block-based themes. </p>



<p><strong>Justin Tadlock</strong> wrote <a href=\"https://wptavern.com/getting-to-know-the-upcoming-wordpress-5-8-template-editor\">about it on the WPTavern</a>, too. </p>




<p><strong>&nbsp;<a href=\"https://make.wordpress.org/core/handbook/references/keeping-up-with-gutenberg-index/\" target=\"_blank\" rel=\"noreferrer noopener\">&#8220;Keeping up with Gutenberg &#8211; Index 2021&#8221;</a>&nbsp;</strong><br />A chronological list of the WordPress Make Blog posts from various teams involved in Gutenberg development: Design, Theme Review Team, Core Editor, Core JS, Core CSS, Test and Meta team from Jan. 2021 on. Updated by yours truly.  <a href=\"https://make.wordpress.org/core/handbook/references/keeping-up-with-gutenberg-index/keeping-up-with-gutenberg-index-2020/\">The index 2020 is here</a></p>




<h2>For Site owners and Content Creators</h2>



<p><strong><a href=\"https://twitter.com/HariShanker\">Hari Shanker</a></strong> from the community team published <a href=\"https://make.wordpress.org/community/2021/06/18/meetup-group-resources-talking-points-for-wordpress-5-8/\"><strong>Talking points for WordPress 5.8</strong></a> of Meetup organizer, that also helps agency owners and freelancers to quickly get an overview of what is coming in the new version. Hari clusters the upcoming changes per WordPress stakeholders. You&#8217;ll find a section for Publishers and users, and another one for site builders and developers. <strong>If you want to read just one article, this would be it. </strong>?</p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong><a href=\"https://twitter.com/chrislema\">Chris Lema</a></strong> makes a strong case for  <a href=\"https://chrislema.com/embracing-gutenberg-completely/\"><strong>Embracing Gutenberg Completely</strong></a>. Out of necessity, he decided to rebuild his site with Gutenberg blocks. All site metrics tools suggested reducing the DOM size of his Landing pages build with 3rd party page builders. With this switch, Chris realized, what he needs and doesn&#8217;t need for a highly performing website. His five observations put a few things in perspective for him as a daily writer, he came to appreciate the tools and blocks that come with the block editor. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p>The team at <strong>PublishPress</strong> posted a short tutorial on <strong><a href=\"https://publishpress.com/blog/gutenberg/nested-blocks-gutenberg-editor/\">How to Use Nested Blocks in the Gutenberg Editor</a>,</strong> as it&#8217;s still a little confusing for content creators to navigate, especially Column blocks. The persistent list view coming to WordPress 5.8 will help with this, though. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong><a href=\"https://twitter.com/javier\">Javier Acre</a></strong> from the WordPress design team published a <a href=\"https://make.wordpress.org/design/2021/06/15/a-walk-around-the-table-block/\"><strong>Walk through of possible enhancements for the Table Block</strong></a>. He showcases update to the placeholder state, multicell selection, the sidebar, the toolbar and icon improvements. You&#8217;ll see mock-ups for each. It&#8217;s quite exciting to see, as we probably can all agree that the Table block needs so TLC, ? You can leave your thoughts and ideas in the comments of the post. </p>



<img />Mockup of Toolbor for the Table block 



<h2>Theme builders</h2>



<p><strong>Dave Smith</strong> has notes on <a href=\"https://aheadcreative.co.uk/articles/testing-the-gutenberg-widgets-editor-for-wordpress-5-8\"><strong>how to test the new Widget Editor that will come with WordPress 5.8</strong></a>. He followed <a href=\"https://make.wordpress.org/core/2021/05/12/help-test-the-widgets-editor-for-wordpress-5-8/\">Andrei Draganescu call for testing</a> and logged his experience. To test for backwards compatibility for your existing widgets, you can first create some with the new widget editor disabled using the <a href=\"https://wordpress.org/plugins/classic-widgets/\">Classic Widget plugin,</a> and then deactivate the plugins and try to manage and edit the widgets with the block-based editor. You have only a month to make sure your sites won&#8217;t run into trouble. WordPress 5.8 will be released on July 20th, 2021. </p>



<div class=\"wp-block-group has-primary-color has-light-background-background-color has-text-color has-background\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong>on <strong>June 24, 2021, at 11am EDT / 15:00 UTC</strong></p>



<a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a>



<p><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Theme.json for Theme Authors or building themes for full-site editing in WordPress.</a></strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olsen, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>



<p><br /><a href=\"https://twitter.com/one_maggie\"><strong>Maggie Cabrera</strong></a> posted the <strong><a href=\"https://make.wordpress.org/themes/2021/06/18/gutenberg-themes-week-of-june-18-2021/\">Gutenberg + Themes: Week of June 18, 2021,</a> </strong>roundup of relevant discussions, issue and PRs for Theme builders. She covered Full-Site Editing, Global Styles and block-based Themes. Chime on on the discussion and test the new releases. If you are a theme developer trying to catch up with what&#8217;s happening with Gutenberg, the Overview / Tracking issues section should get you started. You&#8217;ll find links to documentation and tutorials as well. </p>




<p><a href=\"https://gutenbergtimes.com/podcast/changelog-45-wordpress-5-8-upcoming-live-qa-and-gutenberg-10-7-and-10-8/\"><strong>Episode #45</strong> is now available</a> with transcript. <br />Next recording June 25th, 2021</p>



<p> <strong>Subscribe to the&nbsp;<a href=\"https://gutenbergtimes.com/podcast/\">Gutenberg Changelog</a>&nbsp;podcast </strong><br />?️&nbsp;<a href=\"https://open.spotify.com/show/620NwVKQJGdTupy36zYxvg?mc_cid=4b6c9f88fe\">Spotify</a>&nbsp;|&nbsp;<a href=\"https://podcasts.google.com/feed/aHR0cHM6Ly9ndXRlbmJlcmd0aW1lcy5jb20vZmVlZC9wb2RjYXN0\">Google</a>&nbsp;|&nbsp;<a href=\"https://podcasts.apple.com/us/podcast/gutenberg-changelog/id1469294475\">iTunes</a>&nbsp;|&nbsp;<a href=\"https://pca.st/podcast/f8445ec0-7508-0137-f267-1d245fc5f9cf\">PocketCasts</a>&nbsp;|&nbsp;<a href=\"https://www.stitcher.com/show/gutenberg-changelog\">Stitcher</a>&nbsp;|<br />?️&nbsp;<a href=\"https://www.podbean.com/podcast-detail/chi7j-9904a/Gutenberg-Changelog-Podcast\">Pod Bean</a>&nbsp;|&nbsp;<a href=\"https://castbox.fm/channel/Gutenberg-Changelog-id2173375\">CastBox</a>&nbsp;|&nbsp;<a href=\"https://www.podchaser.com/podcasts/gutenberg-changelog-878239/\">Podchaser</a>&nbsp;|&nbsp;<a href=\"https://gutenbergtimes.com/feed/podcast\">RSS Feed</a>&nbsp;</p>



<img />




<h2>Plugin Developers</h2>



<p><strong>Dave Smith</strong> published a tutorial on <a href=\"https://aheadcreative.co.uk/articles/mocking-wordpress-api-fetch-in-gutenberg-unit-tests/\"><strong>Mocking @wordpress/api-fetch in Gutenberg unit tests</strong></a>. During development you don&#8217;t want to hit an external API everytime you run a unit test, these instructions show you how to mock data coming from an API call in your block or site. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><a href=\"https://wordpress.org/plugins/genesis-custom-blocks/\">Genesis Custom Blocks</a>, (former Block Lab plugin) are a nifty tool to create blocks without going through the pain of learning modern JavaScript. You use the UI to create Field Groups and then add the PHP display code to your theme template. But what if you want to separate the newly create blocks from the theme? Then you could install it on multiple sites, and it would survive a site owners decision to switch themes without loosing content. <strong><a href=\"https://twitter.com/rob_stino\">Rob Stinson</a></strong> has a two-part tutorial for you on <a href=\"https://studiopress.blog/how-to-package-up-your-custom-blocks-in-a-plugin-part-1/\"><strong>How to package up your custom blocks in a plugin</strong></a>. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong>Jeffery Carandang</strong>, a Gutenberg adopter of the first hour, <a href=\"https://jeffreycarandang.com/extendify-is-taking-over-the-editorskit-plugin-and-add-ons-shareablock-and-other-tools/\">found a new home for his Gutenberg entities</a>: <strong>Extendify. </strong> Jeffery has been pushing the envelope on what is possible with Gutenberg since it first came out in 2017. <a href=\"https://wordpress.org/plugins/coblocks/\"><strong>CoBlocks</strong></a>, co-authored with Rich Tabor and later sold to GoDaddy, was a favorite block plugin for additional blocks. <strong>EditorsKit</strong> extended blocks with additional tools. We mentioned his <a href=\"https://shareablock.com/\">Share a Block</a> directory on multiple episodes of the podcast. After starting at 10up, he didn&#8217;t find much time anymore for his love projects, especially the very useful <a href=\"https://wordpress.org/plugins/block-options/\">EditorsKit plugin</a> hasn&#8217;t seen updates for the last nine months. It now found a home at Extendify.  <br />See also: </p>



<ul><li>Arthor Grabowski: <a href=\"https://extendify.com/extendify-is-adopting-the-editorskit-plugin/\">Extendify is Adopting the EditorsKit plugin</a></li><li>Justin Tadlock: <a href=\"https://wptavern.com/extendify-adopts-editorskit-increasing-its-block-plugin-collection\">Extendify Adopts EditorsKit, Increasing Its Block Plugin Collection</a></li></ul>




<p><strong><a href=\"https://gutenbergtimes.com/need-a-zip-from-master/\">Need a plugin .zip from Gutenberg&#8217;s main (trunk) branch?</a></strong><br />Gutenberg Times provides daily build for testing and review. <br />Have you been using it? Hit reply and let me know.</p>



<p><img alt=\"GitHub all releases\" src=\"https://img.shields.io/github/downloads/bph/gutenberg/total?style=for-the-badge\" /></p>



<p></p>





<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-text-align-center\"><strong>Don&#8217;t want to miss the next Weekend Edition? </strong></p>



<form class=\"wp-block-newsletterglue-form ngl-form ngl-portrait\" action=\"https://gutenbergtimes.com/feed/\" method=\"post\"><div class=\"ngl-form-container\"><div class=\"ngl-form-field\"><label class=\"ngl-form-label\" for=\"ngl_email\">Type in your Email address to subscribe.</label><div class=\"ngl-form-input\"><input type=\"email\" class=\"ngl-form-input-text\" name=\"ngl_email\" id=\"ngl_email\" /></div></div><button class=\"ngl-form-button\">Subscribe</button><p class=\"ngl-form-text\">We hate spam, too and won&#8217;t give your email address to anyone except Mailchimp to send out our Weekend Edition</p></div><div class=\"ngl-message-overlay\"><div class=\"ngl-message-svg-wrap\"></div><div class=\"ngl-message-overlay-text\">Thanks for subscribing.</div></div><input type=\"hidden\" name=\"ngl_list_id\" id=\"ngl_list_id\" value=\"26f81bd8ae\" /><input type=\"hidden\" name=\"ngl_double_optin\" id=\"ngl_double_optin\" value=\"yes\" /></form>



<hr class=\"wp-block-separator is-style-wide\" />




<p>Featured Image: Miami at Night by Birgit Pauli-Haack</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Jun 2021 18:11:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Birgit Pauli-Haack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Getting To Know the Upcoming WordPress 5.8 Template Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118777\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:181:\"https://wptavern.com/getting-to-know-the-upcoming-wordpress-5-8-template-editor?utm_source=rss&utm_medium=rss&utm_campaign=getting-to-know-the-upcoming-wordpress-5-8-template-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10320:\"<p class=\"has-drop-cap\">WordPress 5.8 is slated for <a href=\"https://make.wordpress.org/core/5-8/\">release on July 20</a>. In just over a month, many users will get their first taste of one of my favorite new features: template-editing mode.</p>



<p>The template editor is a new tool that allows end-users to create custom templates without ever leaving the post-editing screen. It exists as a stepping stone toward the eventual site editor, a feature that will hand over complete design control to those who want it.</p>



<p>The downside to the new feature in WordPress 5.8 is that users will not have access to their theme&rsquo;s header, footer, sidebar, or other template parts. It is a blank slate in which they must put on their design caps to create the entire page.</p>



<p><em>With these limitations in place, what is the point of the template editor launching with WordPress 5.8?</em></p>



<p>Landing pages.</p>



<p>A blank slate is not always a bad thing. There is a reason all the best themes include page templates named Blank, Empty, Canvas, Open, or something similar. Sometimes users want control over the entirety of the page&rsquo;s output. And WordPress 5.8 is bringing that capability to every WordPress user.</p>



<p>I have been editing templates for months now, but always in the context of a block theme. I have built both a <a href=\"https://wptavern.com/fse-outreach-7-building-a-portfolio-in-the-upcoming-template-editing-mode\">photography portfolio</a> and <a href=\"https://wptavern.com/fse-outreach-round-6-building-a-wordcamp-landing-page-via-the-template-editor\">WordCamp landing page</a> as part of the FSE Outreach Program. Despite some hiccups, it has been a worthwhile journey being involved as the feature has come to fruition. However, most of my testing was on top of the <a href=\"https://wordpress.org/themes/tt1-blocks/\">TT1 Blocks theme</a>.</p>



<p>It was time to put it to a real-world test with themes that are actually in wide use.</p>



<h2>Will It Work With My Theme?</h2>



<p class=\"has-drop-cap\">The question many users will have on their minds will be: will this new template editor work with my theme? The answer is that it depends. Generally, yes, it will work to some degree. However, because older designs were not created with the template editor in mind, not all experiences will be the same.</p>



<p>I wanted to really put this theory of working with every theme to the test. So, I loaded up Twenty Fifteen, one of my favorite default themes from the past decade.</p>



<p>Perhaps I jumped too far back.</p>



<img />Twenty Fifteen has a two-color background meant for sidebar and content.



<p>The block editor did not exist back when Twenty Fifteen was built. Its use of a box-shadow technique on the page background meant the entire page had two colored columns running down it. The design team had to use some hacky methods for equal-height sidebar and content backgrounds. <em>Ahhh&hellip;the good old days before developers had access to CSS flex-box and grid.</em></p>



<p>It is these sorts of problems that could limit some older themes. In the case of Twenty Fifteen, I could hide the background with a Group or Cover block over the top of it.</p>



<p>Users will likely get better results when using something more modern, at least a theme built during the block era. Even something as simple as wide-alignment support will change the WYSIWYG nature of the template editor. If a theme does not support the feature, the front end will not match the editor.</p>



<p>I jumped ahead a few years. Twenty Nineteen was the first default WordPress theme to support blocks. It is old but not ancient in internet years.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Editor vs. front end of Twenty Nineteen.



<p>There are some differences between the editor and front-end views. The Cover block padding is off, the vertical spacing does not match, the search input&rsquo;s font size is different, and the search button&rsquo;s border radius is round on the front end. However, it is nearly a three-year-old theme now. It held up better than expected in this simple test.</p>



<p>Jumping ahead a couple of years, I activated Twenty Twenty-One, WordPress&rsquo;s most recent default theme.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Editor vs. front end of Twenty Twenty-One.



<p>The editor is a pretty close approximation of what you see on the front end. The most noticeable differences are the inconsistent padding for the Cover block and the light gray border for the search input field in the editor view.</p>



<p>It was time to put the template editor to the &ldquo;real&rdquo; test. I activated the latest version of Eksell, one of the <a href=\"https://wptavern.com/compatibility-is-not-enough-the-eksell-wordpress-theme-creates-art-with-blocks\">most well-rounded block themes</a> in existence.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul> Editor vs. front end of Eksell.



<p>Obviously, the theme outputs a black section on the left. That is intended for the theme&rsquo;s sidebar/menu flyout. However, because the user has no access to the template part that outputs that element, it may be impossible for some to create custom templates with this theme. I am sure that Anders Nor&eacute;n, the developer, will address this problem.</p>



<p>Similar, unknown issues will arise with the many thousands of themes in the wild. It does not mean a theme is necessarily bad. It just means it was not built with the template editor in mind. Users may need to throttle back their hopes a bit until they have thoroughly tested template-editing mode with their active theme.</p>



<p>Oh, and that ugly whitespace that shows the content background at the top of the editor? You will see that with literally every theme. I am clueless as to why the development team thought that it would make for a good default. Nearly every web design I have looked at over the years zeroes out the page&rsquo;s <code>&lt;body&gt;</code> element padding.</p>



<p>For those theme authors who are reading, you will need to deal with this. If you have already been building for the block editor, you are likely a pro at handling such quirks.</p>



<p>If we look at a custom theme I have been building, you can see no alignment issues between the editor and front end.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>  Editor vs. front end of custom block theme.



<p>The difference for my theme is that I am building when the template editor is already a part of the Gutenberg plugin. The others were all created earlier. It is not fair to compare them. However, users should know that older themes might not work well. They may need to wait for updates or try out a fresh design before taking advantage of template editing.</p>



<p>I also chose Twenty Nineteen, Twenty Twenty-One, and Eksell because they were designed by professionals in our industry and were released in the last few years. They each hold up well but have a few issues that would be trivial to fix.</p>



<p>All of this is to say that results may vary &mdash; wildly.</p>



<h2>The Ideal Way To Use the Template Editor</h2>



<p class=\"has-drop-cap\">My fear with the template editor is that users will begin mixing their content directly into the editor. It is an issue I brought up during round #7 of the FSE Outreach Program. Ultimately, it is a question about the boundary between content and template.</p>



<p>Traditionally, theme authors would build custom templates for their end-users to apply to their pages. Unless those users knew how to make direct code changes, they only selected the template and edited their own content via the editor. It was always clear where content editing ended and template editing began.</p>



<p>The new mode muddies the waters a bit. Because users have direct access to change the template from within the post/page editor itself, I have no doubt that many will create the entire page&rsquo;s content from within the template editor.</p>



<p>Even I made the mistake of putting what would typically be content in my example templates above. This was purely for illustration.</p>



<p>There is nothing wrong with this if it the user&rsquo;s intention. However, templates are generally meant for controlling the layout of the page. Things like the header, footer, and content wrapping element belong within it, while the content itself is stored separately. Templates are also meant to be reused. If you apply the same template to multiple pages, any changes made to that template will update every page.</p>



<p>My recommended starting point is to simply add the Post Content block to the template. You can do so from the block inserter or by pasting in this code snippet:</p>



<pre class=\"wp-block-code\"><code>&lt;!-- wp:post-content {\"layout\":{\"inherit\":true}} /--&gt;</code></pre>



<p>If you just want a blank/empty template, which is what the editor is good at right now, this is all you need. You can move back to the page editor and unleash your creativity.</p>



<p>Here is the start of a novelist landing page I built from this blank template:</p>



<img />



<p>The content of the page was added via the post editor rather than in template-editing mode. This will allow me to create multiple pages using the same open canvas.</p>



<p>If you want to add other layout elements, you can tack them on too. Try mixing and matching the Site Title, Site Tagline, and Navigation blocks as a header. Drop in a Columns block with other blocks to create a &ldquo;widget area&rdquo; in the footer.</p>



<p>The power of the template editor is coming with block themes. Eventually, designers will be able to pre-build these templates, and users will customize them. They will also have access to a more robust suite of blocks, such as loading up template parts. However, we have to wait until at least WordPress 5.9 later this year before they become available, and that is not set in stone yet.</p>



<p>Until then, we have a sort-of-OK-but-kind-of-amazing landing page creator.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 19 Jun 2021 03:08:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: MapLibre Project Gains Momentum with MapLibre GL Native Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118711\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:191:\"https://wptavern.com/maplibre-project-gains-momentum-with-maplibre-gl-native-release?utm_source=rss&utm_medium=rss&utm_campaign=maplibre-project-gains-momentum-with-maplibre-gl-native-release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2774:\"<p>The <a href=\"https://github.com/maplibre/maplibre-gl-js\">MapLibre</a> project is picking up speed with the release of <a href=\"https://www.maptiler.com/news/2021/06/maplibre-gl-native-open-source-mobile-sdk-for-android-and-ios/\">MapLibre GL Native</a>, an open source mobile SDK for Android and iOS. As anticipated, MapTiler&rsquo;s fork of Mapbox&rsquo;s mobile map SDKs are coming under the MapLibre umbrella. This free library enables developers to write native applications that can display vector maps on mobile devices, with advanced functionality like custom map styles and integrating specific business data.</p>



<p>The project was formed by Mapbox&rsquo;s open source contributor community after the company announced that&nbsp;<a href=\"https://wptavern.com/mapbox-gl-js-is-no-longer-open-source\">Mapbox GL JS version 2.0 would be released under a proprietary license</a>.&nbsp;MapLibre GL founders include a diverse group of companies who are contributing to this healthy, community-led fork, including MapTiler, Elastic, StadiaMaps, Microsoft, Ceres Imaging, WhereGroup, Jawg, Stamen Design, and more.</p>



<p>MapLibre GL Native is developed and maintained as an independent mobile SDK, led by the MapTiler team in cooperation with Amazon, Facebook, Microsoft, and the MapLibre community. MapTiler forked Mapbox&rsquo;s last version released under the OSS license in December 2020, and ensured that developers can migrate their apps with just a few lines of code. The release post identifies a few critical changes in the MapLibre SDK:</p>



<ul><li>Tracking of end-users (telemetry) has been removed</li><li>OSS license: community ownership ensures it stays open-source forever</li><li>Updated distribution model: the library is now distributed via the Maven Central repository for Android and as a Swift package for iOS</li><li>Optional usage of authorization: access token requirement depended on the map provider and its policy</li></ul>



<p>WordPress core doesn&rsquo;t include a Map block but WordPress.com and Jetpack both use Mapbox GL JS 1.13.0. This is the last open source version before Mapbox updated to its proprietary license. I created a <a href=\"https://github.com/Automattic/jetpack/issues/20127\">ticket</a> to put it on the Jetpack team&rsquo;s radar, and it looks like they may consider migrating to MapLibre in a future release. <a href=\"https://wordpress.org/plugins/search/mapbox/\">Plugin authors using Mapbox</a> will also be at a crossroads when it comes time to update beyond version 1.13.0. MapLibre is the strongest alternative to Mapbox&rsquo;s proprietary 2.x update. Migration instructions are available in the <a href=\"https://github.com/maplibre/maplibre-gl-js#migrating-from-mapbox-gl\">MapLibre GL readme</a> file.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Jun 2021 21:19:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Extendify Adopts EditorsKit, Increasing Its Block Plugin Collection\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118627\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:197:\"https://wptavern.com/extendify-adopts-editorskit-increasing-its-block-plugin-collection?utm_source=rss&utm_medium=rss&utm_campaign=extendify-adopts-editorskit-increasing-its-block-plugin-collection\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6709:\"<p class=\"has-drop-cap\">Extendify has been scooping up some successful block-related plugins in recent months. It acquired the Redux Framework in November 2020 and followed it up with a <a href=\"https://wptavern.com/extendify-acquires-editor-plus-introduces-commercial-templates-in-its-plan-to-improve-block-editing\">purchase of Editor Plus</a> and Gutenberg Hub in December. Its latest pickup? <a href=\"https://wordpress.org/plugins/block-options/\">EditorsKit</a>.</p>



<p>This <a href=\"https://extendify.com/extendify-is-adopting-the-editorskit-plugin/\">ownership change</a> was an adoption rather than an acquisition. The company is compensating Jeffrey Carandang, EditorsKit&rsquo;s creator, for helping during the transition.</p>



<p>&ldquo;The main motivation was to ensure that EditorsKit has a good home,&rdquo; said Extendify co-founder Chris Lubkert. &ldquo;Jeffrey had taken a full-time role with 10up, and the plugin hasn&rsquo;t seen any updates in 9 months. So we are both excited about Extendify building on what Jeffrey has built and continuing to serve the user base.&rdquo;</p>



<p><a href=\"https://editorskit.com/\">EditorsKit</a> is a playground of extensions on top of the existing blocks. From visibility logic to text formatting to extra block options, it has a little bit of everything. Carandang has often launched features long before something similar has landed in WordPress. It has grown to over 20,000 active installs since he first submitted it to the plugin directory.</p>



<p>Taking on a new role with 10up as a web engineer left him little time to devote to the plugin. &ldquo;My time was occupied by my full-time work and adjusting through my shifts, personal stuff, and with what&rsquo;s happening in the world due to lockdowns; and the covid virus,&rdquo; he wrote in his own <a href=\"https://jeffreycarandang.com/extendify-is-taking-over-the-editorskit-plugin-and-add-ons-shareablock-and-other-tools/\">farewell post</a>. &ldquo;I hate to admit it but I think I&rsquo;ve neglected my role in the EditorsKit plugin/community that I&rsquo;ve built for the past couple of years. With this, my sincere apology to the plugin users and the whole community.&rdquo;</p>



<h2>Changes to EditorsKit</h2>



<p class=\"has-drop-cap\">When a plugin changes owners, users sometimes must brace themselves for changes. Right now, EditorsKit is the same plugin it has always been. However, the Extendify team has introduced some additions.</p>



<p>The first is a part of what will eventually be a commercial aspect of the plugin: the Extendify Library. The team added this feature to both the Redux and Editor Plus plugins earlier this year. EditorsKit users will see a new &ldquo;Library&rdquo; button at the top of the editor. Once they click it, it opens an overlay for importing patterns and templates from Extendify&rsquo;s collection.</p>



<img />Popup library for importing Extendify patterns and templates.



<p>The amount of imports allowed is limited to three without signing up. &ldquo;EditorsKit users have access to the same library of patterns and templates and can import three patterns and/or templates,&rdquo; said Lubkert. &ldquo;Anyone who signs up for the beta program will then receive unlimited imports during the beta period. We expect this to continue for a few more weeks.&rdquo;</p>



<p>Essentially, the commercial aspect of EditorsKit, Editor Plus, and Redux will be a shared library from the Extendify team. Users of any one of the plugins can continue using their preferred plugin with the option of importing patterns and templates. Lubkert said they still have no plans of rolling all of the plugins into one &ldquo;super plugin,&rdquo; keeping them each as a separate project.</p>



<p>&ldquo;It makes sense for us to invest our energy into a single library and creating the best experience possible for our users,&rdquo; he said.</p>



<p>The second change the team has implemented is making the <a href=\"https://editorskit.com/wordpress-gutenberg-editor-typography-and-google-fonts-add-on/\">EditorsKit Typography add-on</a> a free download. The plugin allows users to select from a list of hand-picked Google Fonts and use them anywhere. It also has a customizable set of default font combinations.</p>



<p>It makes sense to drop the commercial aspect of this add-on. WordPress is already starting to provide theme authors with the tools for typography options at the block level. EditorsKit Typography may be the better of the two right now, but the average user will not need it as the core platform continues to improve.</p>



<h2>ShareABlock and Other Projects</h2>



<p class=\"has-drop-cap\">The handover includes Carandang&rsquo;s related sites. <a href=\"https://shareablock.com/\">ShareABlock</a>, <a href=\"https://copyglyphs.com/\">CopyGlphys</a>, and <a href=\"https://copygradients.com/\">CopyGradients</a> are all tools for helping WordPress users build on top of the block system. The Extendify team plans on keeping them alive.</p>



<p>Carandang <a href=\"https://wptavern.com/creator-of-editorskit-launches-community-block-sharing-site\">launched ShareABlock</a> in December 2019. Essentially, it was a block patterns directory. Only, block patterns were merely an idea in the bowels of the Gutenberg GitHub repository at the time. The upcoming <a href=\"https://wordpress.org/patterns/\">pattern directory</a>, expected to <em>officially</em> open next month, was not even a blip on most people&rsquo;s radar.</p>



<img />ShareABlock homepage with downloadable &ldquo;patterns.&rdquo;



<p>ShareABlock has had time to mature. Its designs are more modern than the current offering from the pattern directory. The downside is the reliance on EditorsKit to import them via a JSON file instead of copy-paste block HTML code.</p>



<p>With a few tweaks, it could be a serious contender as an alternative directory. If the WordPress development team follows through with a ticket I opened for <a href=\"https://github.com/WordPress/gutenberg/issues/32696\">allowing third-party vendors</a> to hook into the system, it would be easy to do.</p>



<p>&ldquo;In general, we don&rsquo;t see ourselves competing with the pattern directory (or anything else in core Gutenberg),&rdquo; said Lubkert. &ldquo;We&rsquo;d like to solve unmet needs for the community and do so in a way that is complementary to core.&rdquo;</p>



<p>The team already has the patterns in place. Hooking in its existing library would be more of a value-add. The official directory is limited to what can be done with core block options. Extendify would have the wiggle room for adding designs built with its more robust EditorsKit and Editor Plus toolsets.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 18 Jun 2021 00:43:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Automattic Launches Mayland Blocks, Its Second FSE Theme on WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118429\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:209:\"https://wptavern.com/automattic-launches-mayland-blocks-its-second-fse-theme-on-wordpress-org?utm_source=rss&utm_medium=rss&utm_campaign=automattic-launches-mayland-blocks-its-second-fse-theme-on-wordpress-org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5502:\"<p class=\"has-drop-cap\">Automattic released its second block theme to the WordPress theme directory last week. <a href=\"https://wordpress.org/themes/mayland-blocks/\">Mayland Blocks</a> is geared toward photographers and other users who want to showcase their projects. It is the child of <a href=\"https://wptavern.com/the-automattic-theme-team-announces-blockbase-its-new-block-parent-theme\">Blockbase</a>, a sort of starter/parent hybrid the company&rsquo;s Theme Team recently announced.</p>



<p>I had high hopes for Mayland Blocks going in. I have kept a loose eye on its <a href=\"https://github.com/Automattic/themes/tree/trunk/mayland-blocks\">GitHub repository</a> in the last couple of months. It was one of the first 100% block-built themes the team seemed to be working on.</p>



<p>While block themes are still experimental at this stage, I was admittedly disappointed. Maybe my expectations were too high. I was eager to be wowed when I should have gone into this review more level-headed. However, I am who I am, and that is someone who is genuinely excited each and every time a new block theme comes along. I am ready for the next big thing, but Mayland Blocks did not fit the bill.</p>



<p>As I began the process of testing the theme, the first order of business was to recreate the Masonry gallery as shown in the theme&rsquo;s screenshot:</p>



<img />Expected gallery layout from Mayland Blocks



<p>My first thought was that the default gallery output would <em>automagically</em> work. <em>It did not.</em> Then, I looked for a Gallery block style. <em>Nothing there.</em> I searched for a custom pattern. <em>Nothing there either.</em> In short, it was impossible to recreate the gallery shown in the theme&rsquo;s screenshot &mdash; one of the primary features that drew me to it.</p>



<p>Bummer. I was looking forward to seeing a Masonry-style gallery of images built on top of the block system.</p>



<img />Standard gallery output with Mayland Blocks.



<p>With a tiny bit of sleuthing and peeking under the hood of the <a href=\"https://maylandblocksdemo.wordpress.com/\">theme&rsquo;s demo</a> on WordPress.com, I saw that it was using the <a href=\"https://wordpress.org/plugins/coblocks/\">CoBlocks plugin</a> by GoDaddy. The thing that made the theme special had nothing to do with the theme.</p>



<p>After a quick install, I converted my existing gallery to the CoBlocks Masonry block. Success!</p>



<img />Masonry gallery output via CoBlocks.



<p>At that point, I began to wonder why I was even testing Mayland Blocks at all. Its claim to fame hinged on showcasing photography. The core Gallery block works well enough, and I can use CoBlocks with any theme. Most decent ones provide the sort of open-canvas template that is no different than Mayland&rsquo;s front page.</p>



<p>What would have made it a great theme would have been living up to its screenshot&rsquo;s promise. This was also a missed opportunity to showcase some alternate Gallery block styles and patterns. If we want more users to buy into this system, some of our best design and development teams need to take that one extra step.</p>



<p>For such a simple theme, one well-suited as a one-page design, this was the moment to lean into the photography angle.</p>



<p>Provide users a Polaroid picture frame option:</p>



<img />



<p>Add a &ldquo;no gutter&rdquo; block style:</p>



<img />



<p>Bundle a few patterns that combine the Gallery block with others. Give us a little flavor.</p>



<p>Mayland Blocks works well as a WordPress.com child theme because its suite of plugins is available to all users out of the box. For a publicly-released project on WordPress.org, it is a little disappointing that it was a straight port.</p>



<p>The child theme is essentially its parent with an open-canvas front page template and some trivial font and color changes. Surprisingly, it made it into the theme directory with so few alterations. Two days later, another child theme was <a href=\"https://themes.trac.wordpress.org/ticket/100381\">outright rejected</a> for just adding &ldquo;some minor changes which can be made directly from the parent theme.&rdquo; The inconsistent application of the guidelines by different reviewers has long been a thorny issue, especially when more subjective rules come into play.</p>



<p>However, block themes have more wiggle room at the moment. There are so few for users to test that it makes sense to let things slide.</p>



<p>One of the Themes Team&rsquo;s previous hard lines has been that bundled front page templates must respect the user&rsquo;s reading settings. This meant that if a user explicitly chose to show blog posts on their front page, the theme must display those posts.</p>



<p>Mayland Blocks is the first that I have seen get a pass on this, a hopeful sign of more leeway for directory-submitted themes in the future.</p>



<p>Block themes are a different beast. HTML files are not dynamic, and there is no way to put a PHP conditional check in a <code>front-page.html</code> file in the same way as themers once did in a <code>front-page.php</code> template. There is a technical workaround for this, but I do not think it is necessary. Block themes are changing the game, and the guidelines will need to follow.</p>



<p>I love seeing the contribution &mdash; any contribution, really &mdash; of another block theme to WordPress.org. However, I want to see more artistry on top of the Blockbase parent theme.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Jun 2021 00:43:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: Alex Denning and Iain Poulson Launch FlipWP, an Acquisitions Marketplace for WordPress Companies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118501\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:255:\"https://wptavern.com/alex-denning-and-iain-poulson-launch-flipwp-an-acquisitions-marketplace-for-wordpress-companies?utm_source=rss&utm_medium=rss&utm_campaign=alex-denning-and-iain-poulson-launch-flipwp-an-acquisitions-marketplace-for-wordpress-companies\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5525:\"<p>Alex Denning and Iain Poulson launched <a href=\"https://flipwp.co/\">FlipWP</a> today, a private marketplace  to facilitate acquisitions for WordPress companies. WP Engine&rsquo;s recent published research, which estimates the <a href=\"https://wpengine.com/wordpress-economy/\">WordPress economy at $596.7B</a>, has inspired confidence in the ecosystem. An increasing number of acquisitions announced over the past month is also reinforcing the need for a more centralized marketplace for these opportunities.</p>



<p>&ldquo;Iain and I started talking a lot more regularly a year ago, when he started Plugin Rank,&rdquo; Denning said. &ldquo;He was getting people asking him for acquisition opportunities, and with Ellipsis I was getting clients asking for help evaluating acquisitions and with sales. There was no go-to marketplace, so in March we started talking about working together on solving the problem.&rdquo;</p>



<p>Sellers can list on FlipWP privately for free and buyers handle their own sales, with no exclusivity obligation. The site doesn&rsquo;t charge for listings and it doesn&rsquo;t take commission from any sales. The $299 membership for buyers opened today, which offers access to FlipWP&rsquo;s email list of acquisition opportunities. </p>



<p>Listings include business data, such as ARR and monthly profit, the asking price, and commentary about the opportunity from FlipWP. Buyers can reach out directly to sellers with no middleman involved.</p>



<p>In the past, finding a buyer for a WordPress company required having a wide network, knowing the right people, or posting on various marketplaces like Flippa and MicroAcquire.</p>



<p>&ldquo;Every week I was hearing about another acquisition, getting an email from someone looking to buy a plugin business, or emails from developers asking the best way to sell,&rdquo; Poulson said. &ldquo;The need for a WordPress specific acquisition marketplace became more and more apparent.&rdquo;</p>



<h2>The Acceleration of Acquisitions in the WordPress Ecosystem</h2>



<p>There is a lot of buzz on Twitter lately, questioning whether an active acquisition market is a healthy development. Some have expressed concern about small, independent tools getting bought up by larger companies and worry that consolidation will lead to lack of competition. </p>



<p>Eric Karkovack wrote in a <a href=\"https://speckyboy.com/wordpress-plugin-acquisitions/?mc_cid=fbd013f171&mc_eid=ad602f9b49\">post</a> speculating on the future of plugin acquisitions, entertaining the possibility that &ldquo;a few big players simply set the rules for everyone else to follow:&rdquo;</p>



<blockquote class=\"wp-block-quote\"><p>Frankly, it&rsquo;s becoming a lot harder for solo entrepreneurs or small development shops to manage a popular plugin. Supporting a large userbase while also focusing on the future could become overwhelming.</p><p>Thus, it&rsquo;s not surprising to see that some of these products are being sold off to larger firms. We saw something similar happen with internet providers back in the early 2000s. The more mature the market, the harder it became for a small company to carry out its mission. Pretty soon, they were just about all bought up by corporate interests.</p><p>While that may not fully reflect the case here, it seems to at least be trending in that direction&hellip;</p><p>It will take some time. But there might come a day when a typical business website runs plugins from perhaps only a few big development houses.</p></blockquote>



<p>Not everyone shares this same bleak outlook on the potential effects of consolidation. During Matt Mullenweg&rsquo;s Q&amp;A at WordCamp Europe, Brian Krogsgard asked what these acquisitions mean for the health of the WordPress economy. Mullenweg sees it as a positive development that should spur more creation:</p>



<blockquote class=\"wp-block-quote\"><p>It&rsquo;s a really exciting time because it feels so robust and healthy. The fact that these exits are happening then creates more incentives for something new to be created, either from the alumni of these companies or by people that know that they can get something to a certain point and sell it to one of these companies. It&rsquo;s actually not very different from Google and Yahoo and all of these companies that buy up lots of startups. Guess what, that created way more startups, some of which became Airbnb and Uber and challenged the tech giants. That&rsquo;s the beauty of how the ecosystem works.</p></blockquote>



<p>Poulson and Denning are also optimistic that FlipWP will open up more opportunities for business owners to get connected and accelerate the process for all parties involved.</p>



<p>&ldquo;The acquisition trend is indicative of WordPress maturing,&rdquo; Denning said. &ldquo;If WP Engine thinks the WordPress economy is <a href=\"https://wpengine.com/wordpress-economy/\">worth $597 billion dollars</a> and the biggest public companies in WordPress are worth ~$20bn, we&rsquo;re about $577bn short. A lot of that number will be made up through the small businesses we see getting sold, and until now they&rsquo;ve not had a way of selling other than &lsquo;post it on Slack.&rsquo; If that study is right, then the one-most-weeks rate of acquisitions might actually be significantly too low, and those businesses are being undervalued, too. We can make it much easier for buyers to find quality WordPress listings, and we can make it much easier for sellers to get the best price.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jun 2021 21:29:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: #4 – Dan Maby on the Importance of the WordPress Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wptavern.com/?post_type=podcast&p=118113\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:183:\"https://wptavern.com/podcast/4-dan-maby-on-the-importance-of-the-wordpress-community?utm_source=rss&utm_medium=rss&utm_campaign=4-dan-maby-on-the-importance-of-the-wordpress-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:58344:\"<h2>About this episode.</h2>



<p>On the podcast today we have Dan Maby.</p>



<p>Dan has been a user of WordPress for many years. As an agency owner he&rsquo;s used it to build client websites, but, as is so often the case, he came for the software and got caught up in the community.</p>



<p>Starting out by attending some local WordPress meetups, he engaged with his fellow WordPressers and enjoying the events he was attending. Attendance turned into organising and over time Dan became the lead of four WordPress Meetups spread all over the UK.</p>



<p>Meetups led to an interest in WordCamps, where he again stepped up to take on leadership roles at WordCamp London.</p>



<p>In the podcast today we talk about the importance of the WordPress community, not just to him as an individual, but to the future of the project as a whole. After all, it&rsquo;s software created by people, and the health of that community will have a direct impact upon the contributions they make.</p>



<p>We recorded this podcast at a time unlike any other. In person events have had to stop; the WordCamps and Meetups have all gone virtual. Perhaps there&rsquo;s light at the end of that tunnel, but it&rsquo;s a perfect time to look back and see how the community has adapted to these new circumstances.</p>



<p>We get into whether hybrid WordPress events should be the new norm, what lessons the community can learn from the past year, and what Dan and his colleagues have done to stay connected and part of a vibrant community. They&rsquo;ve built a platform to enable events and plan on releasing it as a WordPress plugin soon.</p>



<p>We also discuss an event which Dan has been a key player in organising &ndash; <a href=\"https://www.wordfest.live/\">WordFest Live</a>, a 24-hour online event with a focus upon learning and positive mental health.&nbsp;</p>



<p>It&rsquo;s a lovely episode with a member of the community who has been giving back for many, many years.</p>



<h2>Useful links.</h2>



<p><a href=\"https://www.wordfest.live/\">WordFest Live</a></p>



<p><a href=\"https://www.bigorangeheart.org/\">Big Orange Heart</a></p>



<p><a href=\"https://www.meetup.com/topics/wordpress/\">WordPress Meetups</a></p>



<p><a href=\"https://central.wordcamp.org/\">WordCamp Central</a></p>


Transcript<div><div class=\"chat-transcript\"><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:00:00]</div> <div class=\"chat-text\"><p>Welcome to the fourth edition of the Jukebox Podcast from WP Tavern. My name is Nathan Wrigley. Jukebox is a podcast for the WordPress community. Each month, we bring you someone who is part of that community to give you an insight into a topic or person who you might not be familiar with. If you enjoy the podcast, you can subscribe to future episodes by going to wptavern dot com forward slash feed forward slash podcast.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>If you&rsquo;ve got any feedback about the podcast, which could be a suggestion of a potential guest or a subject, then head over to wptavern dot com forward slash contact forward slash jukebox. There&rsquo;s a contact form there for you to complete, and we&rsquo;d certainly welcome your input. Thanks in advance. If you reach out.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>Okay, so on the podcast today, we have Dan Maby. Dan has been a user of WordPress for many years. As an agency owner, he&rsquo;s used it to build client websites, but as is often the case, he came for the software and got caught up in the community. Starting out by attending some local WordPress meetups, he engaged with his fellow WordPressers and enjoyed the events he was attending. Attendance turned into organizing, and over time, Dan became the lead for four WordPress meetups spread all over the UK. Meetups led to an interest in WordCamps, where he again stepped up to take on leadership roles at WordCamp London. In the podcast today, we talk about the importance of the WordPress community, not just to him as an individual, but to the future of the project as a whole. After all it&rsquo;s software created by people, and the health of that community will have a direct impact upon the contributions they make. We recorded this podcast at a time unlike any other. In-person events have had to stop the; WordCamps and meet-ups have all gone virtual. Perhaps there&rsquo;s a little light at the end of the tunnel, but it&rsquo;s a perfect time to look back and see how the community has adapted to these new circumstances.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>We get into whether hybrid WordPress events should be the new norm. What lessons the community can learn from the past year, and what Dan and his colleagues have done to stay connected and part of a vibrant community. They&rsquo;ve built a platform to enable events and plan on releasing it as a WordPress plugin soon.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>We also discuss an event which Dan has been a key player in organizing, WordFest Live. It&rsquo;s a 24 hour online event with a focus upon learning and positive mental health. It&rsquo;s a lovely episode with a member of the community who has been giving back for many, many years.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>If any of the points raised here, resonate with you, be sure to head over and find the post at wptavern dot com forward slash podcast, and leave a comment there.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>And so without further delay, I bring you Dan Maby.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>Am joined on the podcast today by Dan Maby. Hello, Dan.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:03:46]</div> <div class=\"chat-text\"><p>Good. Speak to you.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:03:46]</div> <div class=\"chat-text\"><p>Yeah, it&rsquo;s really nice to have you on the podcast today. Dan and I have a long history of chatting with each other, so this may end up being quite informal at times, but nevertheless, we&rsquo;re going to talk today about the WordPress community and events in general.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"> <div class=\"chat-text\"><p>To paint some context into that, I wonder Dan, if you wouldn&rsquo;t mind spending just a couple of moments, introducing yourself and perhaps explain your history. Not just with WordPress, the software, but also your history with WordPress as a community.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:04:17]</div> <div class=\"chat-text\"><p>Yeah, absolutely. I guess my journey started 15 years ago with WordPress. Funnily enough, we had obviously the 18th birthday quite recently of WordPress, and I was looking back at my history, trying to figure out what had been doing with it. And I realized that I&rsquo;d started with version 1.5, which at the time was really quite a major introduction. Lots of features in that 1.5 update that we still recognize today in the platform. And it&rsquo;s been, an interesting journey with WordPress and the community. One that I&rsquo;ve absolutely loved over that 15 year journey. But really the journey for me with the community started, I think it was around 2012. I was looking for a way to connect with people that were working with and were interested using WordPress. I was working in London at the time in the UK, looked at a meetup. I came across, there was a WordPress meetup that was being run by Keith Devon at the time, the WordPress London meetup. So I went, I headed over to the meetup, came from my day job at the time, which means I was suited and booted. Wandered into this, a room with a bunch of WordPress developers and users. And felt entirely out of place in that in that first meeting. I was the only person there in a suit. Everybody else was nice and casual, but the welcome that I received in that meetup was second to none. It was really an incredible experience, a first experience of the, the wider WordPress community.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"> <div class=\"chat-text\"><p>And it was actually at that event that Keith had asked if anybody was looking to get involved and support in the delivery of the event and that having been there literally for my first time, stuck my hand up, and that&rsquo;s really where it all started. And very quickly moved into a situation where Keith decided to step away from the event to focus on other things, focus on his agency, et cetera. I&rsquo;ve been running the event ever since. And the WordPress London meetup has been a key aspect to everything that I&rsquo;ve been doing within the community. It&rsquo;s been a real pleasure to be able to be a custodian of a that event.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:06:16]</div> <div class=\"chat-text\"><p>You have a lot more strings to your bow than just the WordPress London meetup. Do you want to tell us a little bit more about some of the other things that you&rsquo;re, well, were involved in? We&rsquo;ll get onto that a little bit later, about the way that things have had to cease, but tell us apart from the WordPress London meetup, tell us about the other things that you were doing on a monthly basis.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:06:37]</div> <div class=\"chat-text\"><p>Sure, so, for me the community was really the important bit, the people within the community. I really grew to develop a, a passion for the people that we were connecting with. And from that point from the running of the WPLDN event, I realized that actually there were other areas that were lacking in meetups across the UK. There were plenty of people running, plenty of meetups, and I was really enjoying being part of that kind of organizers community, if you like a meetup organizers community. But as I said, I noticed that there were areas that were lacking events, even in my local area, as well as further a field, I actually got to the point where I was organizing and leading four meetups a month across the UK, which saw me traveling quite substantial miles on a monthly basis, just to enable these communities to grow and develop.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"> <div class=\"chat-text\"><p>And it was a real pleasure to be able to work with local communities. I always encouraged community members within the local area to come on board as co-hosts and enable them to take the lead and to sow the seed and then move on and help that community thrive. And it was going fantastically well. You know we had, as I say, we have four meetups running across the UK, and then suddenly, obviously we&rsquo;re thrown into the situation where we couldn&rsquo;t physically come together in person.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:07:56]</div> <div class=\"chat-text\"><p>Before we move on to that, perhaps we could paint a little picture about the importance of WordPress in your life, because it strikes me that many people, they may use WordPress as a piece of software. And that&rsquo;s the end of it. They have really no understanding that there is a community which can support you in your WordPress knowledge, but also it can be much more than that. And I think it&rsquo;s fair to say that in your case, many of the people that you&rsquo;ve met through WordPress have become actual friends who you actually socialize with. Enjoy their company and stray into non WordPress things as well. So I&rsquo;m just wondering if you could tell us how it has helped you, but perhaps get into the stuff that&rsquo;s not to do with WordPress. Have you met people that you&rsquo;ve really jelled with and found camaraderie with.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:08:41]</div> <div class=\"chat-text\"><p>I think this is the the beauty of the WordPress community. It&rsquo;s so much more than just the technology. I found it to be quite a unique community as well, in that the way people are open, the way people will communicate and discuss and talk about topics, which, by all rights where we attended an event together, we&rsquo;re essentially often competing with one another. I run an agency which focuses on design and development services, and I will go and speak with many other people that also run agencies. And essentially we are competitors, but that level of competition doesn&rsquo;t really surface too much in the WordPress community. It&rsquo;s predominantly a community that&rsquo;s very supportive and people are very open to discussing issues. Myself, I was seeking out connection, I wanted to be around like-minded individuals because I was in a situation where I was very isolated. I was looking for people to connect with that had an understanding of what I was experiencing. And that&rsquo;s really what the community has been about for me. It has been about this idea of having similar experiences, having, understanding of the challenges that we can face if we&rsquo;re working alone. And my company has run with distributed team members, so I don&rsquo;t have a central office with a team that all works together. We work in our home offices. You miss out on that ability to be able to have those conversations that you would have, potentially in-person. That for me was where I was seeking out the community, and as I did that, I realized that this community really was very open to discussing many issues and very open to sharing experiences and knowledge, which was unique for me at the time. And as you say, that&rsquo;s then led on to building of relationships and those relationships have gone further afield outside your outside of specifically WordPress related. Very happily, I&rsquo;ve got some wonderful friends across the community now, and they are friends and the people that I will hopefully have the pleasure of knowing for the rest of my life. Nathan, I count you in amongst that I can remember a conversation you and I had in a car park post a meetup many years ago and, it&rsquo;s been wonderful to watch the journey that you as an individual have gone on through your experiences of WordPress and podcasting, et cetera, and the many branches and tendrils that we have within the community. It&rsquo;s a very rich experience. I would say being part of the WordPress community.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:11:04]</div> <div class=\"chat-text\"><p>Yeah, I would completely agree. And for those people who perhaps listening to this podcast, obviously this audio will go on in perpetuity, it may be that they&rsquo;re listening to this and the world has become more normal. Shall we say? Perhaps we&rsquo;re allowed to meet up in person again. If that were the case, what would be your best advice for digging into that community? What would your best search be? What would be the best way to go about finding where your local events are taking place?</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:11:32]</div> <div class=\"chat-text\"><p>First off is look for meetups. There are thousands of meetups across the globe that are run by local communities, and I really would encourage anybody if you haven&rsquo;t previously. Take a look head over to you know, there are various sites, whether it&rsquo;s meetup dot com, Eventbrite, et cetera, all those kinds of events websites. Do a search for your local area for WordPress meetup event. Sign yourself up and head over. My personal experience and something that I&rsquo;ve spoken about many times historically is simply getting involved in these events. We have this wonderful ecosystem of WordCamps across the WordPress space. And these WordCamps are, you&rsquo;re basically taking a meetup onto a grander scale, again, encouraging local communities to try and run those WordCamps and larger events, but that can sometimes feel quite daunting, just simply turning up to an event. So if you can get yourself embedded in some way, and volunteering is by far and away, the simplest and best way to do that. Every single one of these meetups and WordCamps are run by teams of volunteers. So signing up as a volunteer, simply putting your hand up and saying, yes, I&rsquo;ll get involved in some way. It gives you a purpose within the event. So you&rsquo;re not simply having to be there and trying to figure out where you fit within it. You&rsquo;re there and you have a role. And this was certainly my experience of getting into the WordCamps space. I&rsquo;ve volunteered. I can remember experience at WordCamp Europe, or I was doing some meeting and greeting as people were arriving, and it just opened up so many interesting and wonderful conversations with people that I still have very interesting, wonderful conversations with today. And it&rsquo;s just that embedding yourself in it and enabling yourself to be part of that community. First step I&rsquo;d say, check meetup, look for an event. Sign yourself up, head over there. And if there&rsquo;s any way that you can get involved, do. Most meetup organizers are so grateful for anybody putting their hand up and say, yeah, look, I&rsquo;ll get involved or stepping forward and saying look, do you need any help with this at all? And that help can vary in so many ways. As a meetup organizer, there&rsquo;s an awful lot often goes on behind the scenes that maybe attendees aren&rsquo;t always aware of that really go into delivering these events.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:13:45]</div> <div class=\"chat-text\"><p>What is the difference between a meetup and a WordCamp? Probably, if you&rsquo;ve attended, either of those you&rsquo;ll know the difference, but if you&rsquo;re new to this whole WordPress community thing, it might be good to paint a bit of clear blue sky between those two different things.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:14:01]</div> <div class=\"chat-text\"><p>So if I use London as an example. Our WordPress London meetup, when we were in person delivering these events, we were seeing the, of an average of a hundred people in attendance every month. So this would run every once a month in our local environment. So the focus for both WordCamps and meetups really are about encouraging local organizers to run them. So our meetup, we feature between two and three speakers on a night. It&rsquo;s usually around two, two and a half hours long. And then post that within, have a bit of a social gathering. Where we continue doing a bit of networking, et cetera. The meetup is a really a trimmed down version, should we say? Or that&rsquo;s probably negative, a negative way of putting it to be honest. The WordCamp is an enlarged version of meetup. Probably the best way of putting it and WordCamps are essentially that. We&rsquo;re taking the concept of a meetup, but on a much, much grander scale. And they don&rsquo;t have to be enormous. I&rsquo;ve attended some you know, a hundred attendee WordCamps and they&rsquo;ve been absolutely spectacular, really personal. And I really enjoy the kind of smaller hundred, hundred and fifty attendee WordCamps, but equally we also have some much, much larger ones. So again, if I look at WordCamp London, the last event we ran we had around 650, I believe was 650 attendees at that event. If we then look at the regional WordCamps. So the likes of WordCamp US, WordCamp Europe or WordCamp Asia. Yeah, WordCamp Europe. I believe there&rsquo;s three and a half thousand attendees at the last event, the last in-person event. So they&rsquo;re often spread across multiple days as well, but not always often there&rsquo;s a, a single day WordCamp as well, but the one telling difference between a WordCamp and a meetup is the WordCamps often have what we call a contributor day associated with them as well, which is a day focused entirely on contributing to WordPress in some way, shape or form. And there are so many ways to contribute. We&rsquo;re not just simply talking about writing code and contributing in that way. There&rsquo;s documentation, there&rsquo;s marketing, there&rsquo;s the multi-lingual there&rsquo;s many ways to get involved. So I really, again, would encourage anybody that&rsquo;s thinking about attending a WordCamp, once we are back to a situation where we are safe to be able to return to in-person events. And obviously some of the virtual events I really would encourage joining the, contributor day in any way that you can.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:16:15]</div> <div class=\"chat-text\"><p>So with all of these events going on, obviously we&rsquo;ve got a thriving piece of software, which is turning out to be widely used over 40% of the web. We have the statistic now using WordPress. So the software is one side, but obviously we&rsquo;ve also, as you&rsquo;ve just painted a picture that we&rsquo;ve got this thriving community as well. An awful lot of the project perhaps was going on, at these community events, a lot of things were being organized, so contributor days, possibly different teams meeting up at various times at these events. And then sometime last year, the world paused and is still in a state of pause. I&rsquo;m wondering if you have any thoughts on whether the project as a whole has been stifled. I know that we&rsquo;ve gone online and we&rsquo;ll come onto that in a moment, but I&rsquo;m just wondering if you&rsquo;ve got any thoughts about the impact that the world pausing and not being able to meet up in person. If the project itself has been stymied by that.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:17:14]</div> <div class=\"chat-text\"><p>I think this is a really interesting discussion. I can sit on both sides of the fence here. I think there is definitely an element of fatigue within the community at this stage. And I think that fatigue is being born out of the fact that potentially we are not having those in-person connections, the wonderful conversations that can be born out of the hallway track, you know it&rsquo;s spectacular, what can happen, and by hallway track, you&rsquo;re simply wandering around the event itself and not necessarily being in a session, but there&rsquo;s, the people are mingling around and the conversations that can be born out of those chance meetings, really are spectacular. Many times I&rsquo;ve run into individuals in the hallway, or we&rsquo;ve just started the conversation and then somebody else has jumped in, somebody else has jumped in and before we know it, there&rsquo;s, there&rsquo;s a really interesting round table conversation going on about the future of the project. Because as an open-source project, we all have the potential to influence them the potential to participate in the project in some way, shape or form. I think in this virtual environment that we&rsquo;re currently in, on a personal level, I believe that we&rsquo;ve lost some of that. We&rsquo;ve lost that ability in many ways. And it&rsquo;s created this fatigue where we&rsquo;re not necessarily having the opportunity to have those discussions and those new ideas, those new thoughts, or those alternative ways of looking at a problem. I think the project has possibly suffered for that, in some respects, I think is partly why WordPress as the software has been so successful is because of WordPress the community has had that really strong in-person connection and that really strong coming together as a community. Having said that equally, there are many benefits to the concept of the virtual environment that we&rsquo;re in. But yes. I certainly think there are some challenges that we have come up against and we&rsquo;ve tried to work towards resolving to some degree as a community in this virtual environment.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:19:07]</div> <div class=\"chat-text\"><p>We&rsquo;re in a strange dichotomy in that we were probably better prepared than almost any industry to move everything online at the drop of a hat, because the WordPress community is online. We understand how to put websites together and turn those websites into virtual events and all of that kind of stuff. Conversely, and perhaps somewhat unexpectedly. We were also a community, that needed to be offline in order to push the project forward. And so in some sense, we were not prepared for that. Two sides of one coin, very well prepared from the technological point of view. But perhaps we didn&rsquo;t really understand that these in-person events, the interactions, the little coincidental meetings that might&rsquo;ve happened, that pushed things forward. The fact that the contributor days, they were a great way of pushing the project forward. All of these little things that required us to be in-person well, they just evaporated and we weren&rsquo;t really prepared for that and that&rsquo;s kinda my take on it. It feels like from the tech point of view, everything&rsquo;s a-okay. We can manage that side really well, but the unexpected consequences from the community going away have become slightly more obvious. And I feel it&rsquo;s not really in any way, catastrophic, it&rsquo;s just little paper cuts. Things haven&rsquo;t perhaps worked as fluidly, perhaps interactions haven&rsquo;t been made, perhaps people have become fatigued, logging onto their computer and so on. And of course, there&rsquo;s the fact that there&rsquo;s a great deal of excitement around turning up to one of these events and whether that&rsquo;s a meetup and you just show up for the evening or you go somewhere further afield. You might need to get in the car or get on a train or get on a plane and you may have booked a hotel and your almost seeing it as a little bit of a vacation, something a little bit outside of the normal experience, all of that side has gone. And so there&rsquo;s less be excited about. And perhaps as you described it fatigue, I&rsquo;m describing it more as a lack of excitement, perhaps that has had a bit of an impact.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:21:10]</div> <div class=\"chat-text\"><p>I think you&rsquo;re absolutely right. There&rsquo;s an excitement when you&rsquo;re coming together in personnel, there&rsquo;s excitement. You don&rsquo;t always know what to expect. You don&rsquo;t always know what&rsquo;s going to come in those conversations. You may have a good idea, but the ability to come together in person and really thrive off that energy of one another, it really can be quite special, but equally there are many people that don&rsquo;t thrive off of that there are many people that really struggle with the idea of being in large groups of people, there&rsquo;s absolutely pros and cons to all of this. And it&rsquo;s something that we were in our events, in the in-person events, we were trying to be aware of, be mindful of that experience for people. Some people, as I say will thrive off that environment of being around lots of people, but those that need their own space sometimes. The idea of delivering quiet rooms at in-person events is really important because some people do just need that time away from the crowd to be able to re-energize themselves, by being by themselves. This idea of enabling all walks of life, all the variations of people that build up our community to be able to participate. And I think this is really where we&rsquo;ve got a huge positive in the virtual environment at the moment we&rsquo;ve brought down so many barriers. For a far greater, far more diverse mix of individuals, whether we&rsquo;re talking about speakers or attendees, we&rsquo;ve got some wonderful opportunities right now in the virtual environment. We&rsquo;re not having to consider visas. We&rsquo;re not having to consider travel expenses. The limitation that we&rsquo;re running on right now in terms of attendance of an event is the bandwidth to be able to connect to that event. We were looking at the positive side of this. There are some really good things I think we need to be very mindful of as we move forward. As we move into, as we start to move into a situation where we, if we&rsquo;re in a safe environment, to be able to return to the in-person events, we also need to be mindful of how do we continue to encourage that very open and very inclusive model that the virtual environment has created.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:23:16]</div> <div class=\"chat-text\"><p>Do you see in the future, and we&rsquo;ll talk more in a moment about specifically what it is that you and your events have done to move online over the last year or so, but just for now, do you see in the future then a model where, let&rsquo;s say that we all go back and the world returns to how it was in 2018. Everybody&rsquo;s allowed to get on planes and trains and everybody can move freely once more. Do you think that we have reached a point where hybrid events and by that I mean, many people will come and be present in the room, but also perhaps we need to provide the internet access so the people from further afield who don&rsquo;t wish to attend, or perhaps they&rsquo;re literally on the other side of the world and they only want to see two or three of the variety of sessions that are on offer that week. It&rsquo;s really not worth them getting on a plane for that, but they could log in and watch them online. So do you feel that there&rsquo;s a hybrid or will we just consign the online events to the realms of history?</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:24:12]</div> <div class=\"chat-text\"><p>So I&rsquo;m very hopeful that as a community, we will adopt the hybrid model. However, having said that, I also appreciate that we need to also figure out what this hybrid model looks like. As a meetup organizer, again, the WordPress London meets up. We were taking quite a considerable amounts of kit into the event to deliver the events. And by kit I&rsquo;m talking about cameras, microphones, tripods, sound equipment, all sorts of stuff, which isn&rsquo;t that common in the meetup space. And as a meet-up organizer, you don&rsquo;t need to be thinking about, or how do I get low cameras, et cetera. But what it meant for us is we were pre pandemic we were already in an environment where we were live streaming the sessions. We were accepting questions coming in from the virtual audience that were consuming the content live whilst the in-person community were also consuming that content. That put us in a very strong model as we move forward, which I can get into in a moment. But the issue that I see is, are we going to try and force the experience where we&rsquo;ve got the in-person and the virtual, combined together at the same time, are we actually going to create a situation where we create the worst of both worlds? So the in-person deteriorates because there&rsquo;s a need for more equipment, there&rsquo;s a need for more organizing and there&rsquo;s need for just a very different experience where you&rsquo;ve got a lot more things needing to happen from an organizer&rsquo;s perspective. And then have you then got the virtual side, is their experience going to deteriorate because the organizers are having to focus on the in person. It&rsquo;s an awful lot to deliver, as an organizer: an event. But to then take that event and say now I need to do at the same time, a hybrid of in-person and live, particularly on the meetup side, I think it&rsquo;s something we&rsquo;re going to have to be very careful of and figure out how do we do that? Are we better to have, I don&rsquo;t know, for example, an in-person event and a virtual event, twice a month. Again, I&rsquo;m not advocating for this for every single meetup because I appreciate every meetup is run by volunteers. It&rsquo;s about the capacity for those organizers. I think when we start to look at WordCamps, it gets a little more interesting because obviously WordCamps do have a slightly larger team often, and there is often some funding supported through sponsorship, et cetera, to enable that. But again, we&rsquo;ve got to look at how do we make sure that the experience is optimal for both the in-person and the virtual. And I&rsquo;m not sure I have the, certainly I don&rsquo;t have the answers to that at this stage, but it&rsquo;s certainly something we&rsquo;ve been having a lot of discussion around internally. And the platform that we&rsquo;ve developed for our virtual events at the moment is something that we&rsquo;re looking to roll into our hybrid model. But again, that we don&rsquo;t have the answers at this stage.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:26:57]</div> <div class=\"chat-text\"><p>I&rsquo;m also conscious that perhaps if everything becomes available online, it may persuade people who are almost going to attend live to not attend live. It may dwindle the audience that turn up to the live event, if you know what I mean, which would be a kind of an unexpected consequence, but those people who were flip-flopping and maybe I&rsquo;ll go, maybe I won&rsquo;t, oh, I&rsquo;ll just watch it on the screen, which is fine. But obviously you don&rsquo;t want to get to the point where the in-person event is attended by just a couple of people, because everybody else is just tuning in online because the sort of sense and the purpose of that event and the camaraderie, all the good stuff that you want to happen, in-person disappears.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:27:38]</div> <div class=\"chat-text\"><p>So this was something that we discussed, a number of times pre pandemic, when we made the decision to start live streaming, the WPLDN events, and we have that exact concern and it&rsquo;s a genuine concern. Are you going to deteriorate the experience by somebody has the option to just simply watch it online? It never happened. Our numbers, stayed consistent and we saw a numbers of in-person stay consistent and we saw our numbers online, grow and grow. And that really demonstrates to us that people want that in person connection, as you just said, there&rsquo;s so much more to the event than simply consuming the the section that&rsquo;s being delivered. So it is those conversations are happening in hallway tracks. It&rsquo;s the, all the other elements to the event that you often can&rsquo;t gain from a virtual environment.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:28:24]</div> <div class=\"chat-text\"><p>Okay. So let&rsquo;s move the conversation a little bit. It was staying on more or less the exact same topic, but I&rsquo;m curious to know what it is technically that you have done since March last year in the UK, March was the moment where everything ground to a halt, and we were unable to see each other. So I just wondered if you could run us through what challenges you faced, how you&rsquo;ve overcome them. And I know that you spent a lot of time trying to build a platform and shape a platform, to make this work in your situation. Perhaps explaining that might encourage other people who would like to take their events online, to reach out to you and see if you can lend them a hand.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:29:00]</div> <div class=\"chat-text\"><p>Sure. Absolutely. Just to give a bit of context before I get into this, the WPLDN events, along with several other events that we deliver, now come under the umbrella of Big Orange Heart, which is a registered nonprofit with a mission to support, promote positive mental health within remote working communities. So a big focus for us is about continuing ways to help reduce social isolation and the delivery of events do that. Now the reason I&rsquo;m saying that is because there&rsquo;s a team of volunteers within Big Orange Heart, that have donated time into helping us deliver them. So what I wouldn&rsquo;t want to portray is yeah I&rsquo;m sitting here on my own and it built this platform that enabled the community to continue to do its thing. It&rsquo;s taken a small village of people to continue to do this. And I appreciate not every meetup has that ability to be able to tap into that. But what we did, we actually back, as I said, previously, we were already live streaming. So we had a pretty good idea of, the, kind of the technical aspects of live streaming content and very fortunate, we&rsquo;ve got a fantastic team on WPLDN, specifically Leo Mindel, Paul Smart and Diane Wallace and myself come together. Leo comes in with some fantastic technical knowledge to help support the live streaming side of it. And we took the decision back in February, so prior to the government making any announcement here in the UK, we took the decision that was going to be our last event until we had more information in relation to the pandemic. Little did we know that would obviously continue on as it is right now, but we took what we were doing in terms of our live streaming; so we did our final in-person event in February. We jumped straight into trying to do a virtual event in our next event in March. So we delivered one event a month through WPLDN. The first thing we did in March was jumped straight into Zoom and said, yep, let&rsquo;s get everybody in. Within minutes, we recognize that Zoom was entirely the wrong platform for us to deliver an event on. It&rsquo;s a great platform, for the purpose of meetings one-to-one or one to many meetings, but it really isn&rsquo;t a good platform for any kind of event. Because if in an event you want the ability for people to freely move around. And we&rsquo;ve seen many events that have used Zoom, used multiple Zoom rooms to enable the attendees to jump into different conversations. The problem with that is you don&rsquo;t know what you&rsquo;re jumping into. We often refer to it as Zoom roulette because you&rsquo;ll be jumping into a Zoom call and you don&rsquo;t know who&rsquo;s in that Zoom call. You don&rsquo;t know what you&rsquo;re jumping into, and it adds a huge cognitive load to the attendees of an event, because not only are they having to figure out where the different Zoom links are, they&rsquo;re also then having to figure out once they&rsquo;ve got in who it is that they&rsquo;re communicating with in that conversation, which it just simply didn&rsquo;t work for us. So we very quickly started to work on a solution that would enable us to have that ability to have freedom of movement within a virtual environment. Now, this led us on to looking, we&rsquo;re huge open-source advocates. And we wanted to continue to deliver, we wanted to build something that would tie in and fit with that ethos of the open source projects that we support. So we quickly discovered Jitsi as source video conferencing solution. Ran into many challenges along the way, in terms of building out the platform. But what we ultimately ended up with was a platform that enabled us to use our existing registration process. So all of our attendees are on meetup. So we wanted for people to be able to obviously log in with their meetup credentials. So register for an event on meetup, if they&rsquo;ve registered, be able to then access the event online. So we built a WordPress site, built a custom app that wrapped around a Jitsi instance, which then enabled us to have this concept of tables within the platform. So attendees would register for the event, jump in. We would be able to stream content into that platform as well as then have this idea of tables where people could freely move around and see exactly who&rsquo;s on what table before they were jumping in. We delivered that I believe that was around May time of that year. So two months following the decision to go to virtual and we continue to iterate and evolve that platform from that point on, which has been, it&rsquo;s been a phenomenal experience, the development of this solution. I just wanted to give a shout out to Louis Cowles, who has been doing an incredible job. Taking what I had originally put together, which was this app wrapped around Jitsi and he has turned it into something far more spectacular, which we are now, almost at the stage of being able to deliver as a WordPress plugin. So if anybody has attended any of the Big Orange Heart events or any of the events, the Big Orange Heart supports, have experienced the platform, which includes WordFest. The whole platform that we have developed there will soon be available as a WordPress plugin as well, which we&rsquo;re really excited about.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:33:56]</div> <div class=\"chat-text\"><p>I have to say from my part, it is now feeling incredibly mature and the fact that it will soon be a WordPress plugin is remarkable. Will that be something that anybody can access and therefore use at their own meetups? Presumably there&rsquo;s some sort of burden of setting up things outside of WordPress. Maybe there&rsquo;s other containers with the Jitsi software that needs to be done, or does it all get rolled into just the plugin and you&rsquo;re good to go.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:34:22]</div> <div class=\"chat-text\"><p>So there&rsquo;s still work that we&rsquo;re working through, how to enable that within the community. Really, what we&rsquo;re trying to do here is build something that is enabling communities to have the experience that we&rsquo;ve had with WPLDN, and also, we&rsquo;re not just simply talking in this current particular space where we&rsquo;ve got the, just virtual again, referring back to the hybrid model. As a platform would work particularly well for the hybrid model, but yes, there are definitely additional technical elements to it, which we will obviously be looking at how we can mitigate that technical challenge that comes with it. There are hosted versions of Jitsi, which you can simply plug into it as it is right now. So again, we&rsquo;ll be able to share more information as we move forward with that. We&rsquo;re really, it&rsquo;s about enabling the community to be able to continue to have that very broad reach. Even as we, as we move back into the in-person.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:35:11]</div> <div class=\"chat-text\"><p>You being you, you weren&rsquo;t content to rest on your laurels and carry on just doing the WPLDN event. You&rsquo;ve obviously got this platform and you decided at some point last year, that you wanted to manage and organize an event which spanned the entire globe. And so WordFest was born. I don&rsquo;t know if WordFest was born, basically out of the fact the world was on pause or whether you&rsquo;d have plans for this prior to that. But perhaps you could spend a few minutes just outlining what WordFest is and by good coincidence, there is actually a WordFest, if you&rsquo;re listening to this podcast episode, soon after it was released, there is actually a WordFest event coming up really soon. So perhaps tell us why you started it and then get onto what&rsquo;s going on in the next few weeks.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:35:59]</div> <div class=\"chat-text\"><p>Sure. So as a charity, we always intended to have some form of larger in-person event. Events have been something that&rsquo;s had a real passion for a very long time. The ethos of bringing people together, helping reduce social isolation of lone workers is something that really fits well with everything that we&rsquo;re doing in terms of Big Orange Heart. So we wanted to enable people to come together. That had always been on the cards from the very early stages of Big Orange Heart. Of course, when we got thrown into this situation with the pandemic, as I say, we moved into the virtual environment for our monthly events, that platform that I&rsquo;ve been discussing, we actually opened up to other communities. So we&rsquo;ve enabled other communities to be able to run their events through our platform, without any charge to them. We just simply wants to be able to create a solution for those communities to continue to come together when they couldn&rsquo;t deliver them in person. What that actually meant was that we, in the first 12 months that we were delivering events through our live dot Big Orange Heart dot org site, we&rsquo;d had over 12,000 attendees come through that platform, which has meant that we&rsquo;d obviously had a huge amount of feedback and we&rsquo;d been able to iterate very quickly across that solution to get to a point where we actually decided that we want to deliver a larger scale event. It&rsquo;s always been on the cards. Why not do that as a virtual conference or virtual festival? That&rsquo;s really where the concept of WordFest was born. And I want to, again, when we give a huge shout out to Brian Richards, particularly of WordSesh. WordSesh has been around, you know, as a virtual WordPress focused virtual event for many years, I can remember way back in the early days of the first WordSesh, the first few WordSesh&rsquo;s, which were 24 hour events and had a lot of fun attending those. And I remember attending my first one and actually attending for the full 24 hours. So this wasn&rsquo;t something that was new in our space. We were very aware that there was a desire for it, but we wanted to wrap together the two elements of what we do. Our hearts really are in WordPress, but our focus is really around wellbeing and mental health, positive mental health. So this concept of WordFest was about bringing those elements together. So if you attend WordFest, you will find content that focuses on both WordPress and our individual wellbeing as remote workers. It really was about this concept of a global celebration of our community. We talked about different ways of delivering it. We talked about do we do over multiple days because we appreciate time zones, how do we, how do we factor in a way of enabling anybody that wants to attend to be able to attend? But we didn&rsquo;t want to just say here&rsquo;s a set time on this day, here&rsquo;s six hours that would deliver it or, over a period of days, we&rsquo;ll do, it was a real challenge. So we, we kept coming back to this 24 hour concept because it would end up, if somebody wants to attend over that one day, there was some point in the day that hopefully they would be able to join us. And it has mushroomed. It&rsquo;s grown and grown. We set out to deliver the first one back in January, this year, 2021, we set a target of 2000 attendees to the event we had just over two and a half thousand attend. So it was, we completely smashed all our expectations in terms of people attending the event. But also we completely smashed our expectations in terms of the number of sessions that we were delivering. We initially set out a wanting to deliver 24 sessions over the 24 hours. That turned into 36 sessions actually ended up being 48 sessions through the first event. I&rsquo;m really happy. I&rsquo;m not sure it&rsquo;s the right word, but I&rsquo;m really happy to say that this time around we&rsquo;ve actually got 66 sessions that are going to be delivered in the 24 hours. It&rsquo;s been a phenomenal experience, delivering this as again, as a wonderful team of volunteers, sitting behind this people like Michelle, Cate, Hauwa, Paul, just wonderful people that are really enabling us to be able to continue to grow this event into a much larger scale event than it ever was initially. So the next WordFest live is taking place on the 23rd of July. So we&rsquo;ll be featuring 66 sessions over a 24 hour period. And it is, I think one of the most wonderful things I took away from the last WordFest was, as an organizer, having organized many in-person events, there&rsquo;s always a connection with your co-organizers. Certainly if you&rsquo;re running a larger event, such as a WordCamp, for example, you build up this rapport and you build up this relationship that on the day of delivering the event often it&rsquo;s, it&rsquo;s, it&rsquo;s tiring. There are, yeah, there are moments of challenges, but there are just wonderful moments as well. But you experience all of those things together as a team. What I took away from WordFest live, which was a genuine surprise to me was we managed to create that same experience. We managed to create that same shared experience as we were delivering the event. I&rsquo;ll never forget sitting here, I think I was in about hour 36 of because I&rsquo;d been up some time before the event and I was sitting there and just the silence that was actually happening as a bunch of organizers, we all knew how, what we were experiencing in that moment. And it was just a real special time. We use various tools to deliver it. And one of the key secret ingredients for us as organizers was Discord. So having an open audio Discord channel for us to be able to just simply be able to speak to one another as we needed in that moment, it worked incredibly well for us.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:41:40]</div> <div class=\"chat-text\"><p>So the event, just tell us one last time. What are the dates and where do we go if we wish to sign up and perhaps importantly, tell us how much does it cost?</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:41:53]</div> <div class=\"chat-text\"><p>I&rsquo;m laughing because it costs you absolutely nothing. WordFest Live is a free event, the next event is taking place on the 23rd of July where we&rsquo;ll be starting at midnight UTC. So time zones are always fun in an event like this. So we base it around UTC. So midnight UTC on the 23rd of July running for 24 hours. So that&rsquo;s the Friday 23rd. You can join us at any point over that 24 hour period, we will be running across six continents. Our time zone starts off in the Australia, Australian time zones. We&rsquo;ll move on to Asia, Africa, Europe, south America, and ending up in North America. And then we&rsquo;ve got Antarctica. You can chill out in our community tent all day long. So over that period, we would love to see you join us. As I say, registration is entirely free. There is an optional $10 donation that you can make when registering, all funds go directly into Big Orange Heart, which was the say is a registered nonprofit. There is also an option there to sign up as a micro sponsor. Should you choose to. Micro sponsorship is charged at $250. And for that, we will obviously get some exposure of your company. And it&rsquo;s really a more a reflection of what it actually costs for us to put this together, in terms of the attendees tickets.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:43:13]</div> <div class=\"chat-text\"><p>This podcast episode, you could probably sum it up with one word and that word would probably be community. If I was to show up to WordFest live and I had ambitions to socialize with other people. That kind of thing is possible? It&rsquo;s not just about show up to the event, watch the speakers and then wait for the next speaker to start. You&rsquo;ve provided opportunities to socialize. So maybe as a final thing, just explain how that works. What&rsquo;s the provision for meeting up with other people and breaking out into different groups and so on.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:43:42]</div> <div class=\"chat-text\"><p>So this was as equally important as finding fantastic speakers. We also needed to make sure that the ability for people to be able to connect, the community, to be able to come together has been a focus for us. So this is where the custom solution that we&rsquo;ve been developing comes into play. So if you are attending WordFest, you can obviously consume, we&rsquo;ve got two tracks running over the 24 hour period. So at any point you have a choice of at least two sessions to choose from. I say at least because there&rsquo;s also some evergreen content that will be available for you to consume through the events as well. And then you can head over to our community tent which we are nicknaming Antarctica this time round, where you can connect with the sponsors. So you will see all the sponsors tables, you can jump in and have conversations, discuss with them for whatever reason you need to to connect with the sponsors, highly encourage you to do that. But in the same space, you can also spin up your own community table. And this is, we try to liken it to a sponsors hall at an in-person event. You might wander into the sponsors hall. You&rsquo;ll have conversations with the sponsors, but equally you might have conversations with your peers, friends, colleagues, in and around the community. So we&rsquo;ve really tried to, as best we can in the virtual environment, replicates that hallway track experience where you&rsquo;re not bound to specific calls, you&rsquo;re not bound to specific tables. You have freedom of movement within that platform to connect with those that you want to connect with. Equally, you also have your own profile within the platform and your own profile then has your own meeting room. So should you want to break out and have you a slightly more private conversation discussion away from the community tent, then again, you have that facility. So it&rsquo;s really about trying to enable people to come together and have the conversations that are so important.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:45:29]</div> <div class=\"chat-text\"><p>Thank you so much, Dan, for putting an event like this on, I know that as you&rsquo;ve said, it&rsquo;s not just you, there&rsquo;s a great large community of people in the background as well. So thank you to them equally and during the last 18 months or so, thanks for being there and making sure that the communities can keep meeting and you&rsquo;ve endeavored to to keep all of that going. And I fear that unless it was for people like you who&rsquo;ve really gone the extra mile, perhaps things wouldn&rsquo;t be quite so bright going forward. From the bottom of my heart. Thank you very much, Dan, for coming on the podcast and for everything that you do.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-2\"><div class=\"chat-author chat-author-danmaby vcard\"><cite class=\"fn\">Dan Maby</cite> [00:46:01]</div> <div class=\"chat-text\"><p>Oh I&rsquo;m deeply appreciate. I thank you. Thank you very much, and likewise. Thank you for all that you do across the community. I appreciate it. I&rsquo;ll see, you spent a lot of time chatting with people like me sharing some wonderful stories.</p>
</div></div><div class=\"chat-stanza chat-row chat-speaker-1\"><div class=\"chat-author chat-author-nathanwrigley vcard\"><cite class=\"fn\">Nathan Wrigley</cite> [00:46:11]</div> <div class=\"chat-text\"><p>Thank you so much.</p>
</div></div></div></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jun 2021 14:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Nathan Wrigley\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"HeroPress: Changing The World, Changing Me\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3902\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"https://heropress.com/essays/changing-the-world-changing-me/#utm_source=rss&utm_medium=rss&utm_campaign=changing-the-world-changing-me\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8049:\"<img width=\"1024\" height=\"512\" src=\"https://heropress.com/wp-content/uploads/2021/06/061421-min.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: WordPress has fundamentally changed who I am. I don’t say that lightly.\" /><p>WordPress was created when I was 10 years old. I try to imagine myself at 10 and the only images I can conjure up are ones of anxiety. My world both felt so small and was so small yet what I felt seemed so big. I don’t look back fondly on those years. I was a ball of competitive anxiety who was just coming out of being made fun of for years for my speech impediments and finally starting to figure out who I might be. My 10 year old self didn’t like change and didn’t know how to cope. My 10 year old self had no concept of what was being created during these strange years and I’m filled with gratitude thinking about those who were paving the way before I could even conceptualize what a website was.</p>
<p>WordPress has fundamentally changed who I am. I don’t say that lightly. I have an urge to jump into a monologue of, “How do I love thee? Let me count the ways” when I think about WordPress.</p>
<h3>Finding My Creativity</h3>
<p>The most profound change started in awakening a sense of creativity and belief in myself. I work hard at things but my earlier black and white point of view often limited any amount of creativity I might have had. I’ll never forget in college working for <a href=\"http://web.unc.edu/\">web.unc.edu</a>, UNC Chapel Hill’s WordPress multisite installation, and discovering that I could create as many sites as I wanted. The ease of use and the unlimited possibilities led me to create site after site. This still happens now with <a href=\"https://letslifechat.com/\">https://letslifechat.com/</a> born this year out of my desire to share my love of questions and deeply connecting with others, especially during a year of profound disconnection. Along the way at UNC, I got to work with brilliant and kind coworkers who believed in me to the point of encouraging me to apply to Automattic after I had to graduate a year early.</p>
<blockquote><p>Knowing they believed in me helped me apply and the case of redbull they sent me for my trial helped me get the job!</p></blockquote>
<p>I never saw myself as creative since creativity was defined for so many years as being art focused (poetry, painting, etc) and I have absolutely no artistic abilities. Being able to make an idea come to life online has changed how I view myself – I now see myself as creative and capable. This shift in how I view myself led me to create initiatives like <a href=\"https://accelerate.lgbt/\">accelerate.lgbt</a> and <a href=\"https://mentoreverywhere.com/\">Mentor Everywhere</a> at Automattic in my free time. I never realized that my handwriting and drawing abilities could be terrible yet, at the same time, my creativity could be powerful. The results of my creative actions have solidified a sense of belief in myself that is deeply profound. It’s something I fall back on during tough days of self doubt and tough problems.</p>
<h3>Finding The World</h3>
<p>Because of WordPress’ global and distributed nature, I have been afforded the opportunity to travel to far away lands and to be there for meaningful moments with dear loved ones. Being a “nomad” is something I never thought I’d be. Being connected to people all over the world felt unfathomable and still feels like more of a dream than a reality. It’s challenged every aspect of who I am and I am better for it. Combined with the ability to see the world, I get to work with folks from all over the world every single day thanks to WordPress. This has given me the honor of having a global mindset that I carry with me no matter where I go. I feel I have traveled enough for many lifetimes over. Once you begin thinking at that scale, whether due to a global mindset or due to the percentage of the web powered by WordPress, you can’t go back. Something in you changes for the better.</p>
<h3>Finding Who I Am</h3>
<p>I think often of LGBTQ+ people of years past and how many likely never would have had the chance at a life that I have. This rings particularly true during Pride Month. On top of everything else, WordPress has given me a platform and a job where I can be my truest self whether that’s sharing my mental health struggles, talking about my evolving thoughts <a href=\"https://surrogacy-stories.com/\">on being born through surrogacy</a>, or imagining a different way of existing <a href=\"https://nomad.blog/2020/01/16/little-homes/\">with many little homes rather than one</a>. With WordPress, I can share my words and I can be heard. I can fiercely be myself and be amplified rather than silenced. I can join community meetings and proudly share a rainbow emoji as I say hi. WordPress has emboldened me and has given me so many opportunities to use my newfound creativity to lead in various spaces.</p>
<p>None of the above gets to the root of why I LOVE what I do and love what WordPress is to me. Beyond any personal change, WordPress has allowed me to help others and to increase my own impact on this world. Whether it was working with department sites during my time at UNC or helping a local non profit set up a brand new website to bring theirs out of the 90s, I am thrilled to have a job and a passion that centers on helping others succeed.</p>
<blockquote><p>It’s such a privilege to work with folks during different stages of their sites – it’s always so personal and so sacred.</p></blockquote>
<p>I can vividly remember the first time this gripped me. I was helping a professor at UNC set up a site and when we finally published it, he couldn’t believe it was “live”. He kept asking me whether other researchers, students, professors, etc. could find him. As I began to explain how everything worked, he was nearly brought to tears.</p>
<p>“I can’t believe my life’s work can be found by anyone in the world.”</p>
<p>I was just a freshman at this point and didn’t quite understand what I had stumbled upon with WordPress. I couldn’t have imagined that this would be my life. I had a friend a few years ago say to me, “You are the last person I ever expected to work in technology.” I grew quiet and nodded solemnly, “Me too”. This great adventure and great chance is truly due to those who helped me patiently over the years. It’s also due to those who enabled WordPress to be what it is today and what it will be tomorrow. I don’t take this for granted.</p>
<h3>Finding My Joy</h3>
<p>There’s a concept I am stuck on these days. It’s centered on this quote:</p>
<blockquote><p>“The true meaning of life is to plant trees, under whose shade you do not expect to sit.” – Nelson Henderson</p></blockquote>
<p>When I was 10, so many were working so immensely hard to create the shade in which I currently sit. This gorgeous, remarkable, world expanding shade that I can’t believe I ever found and that I hardly have the words to describe. I send a tearful “thank you” from my soul into the ether for all of you out there who made this precious life of mine possible.</p>
<p><a href=\"https://nomad.blog/2021/04/17/one-year-in-devrel/\">Just over a year ago</a>, I switched into a Developer Relations Wrangler position at Automattic as a full time contributor to the WordPress project and my hope now is that I can pay forward what has been given to me through planting trees of my own. To have the chance to give back to something that has given me so much is something I wake up everyday thankful for, even on the tough days. Even better, I now get to play a role in encouraging, supporting, and believing in other people as a core part of my job in the same way so many have done for me.</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/changing-the-world-changing-me/\">Changing The World, Changing Me</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jun 2021 12:00:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Anne McCarthy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: Automattic Acquires Day One Journaling App\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118457\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"https://wptavern.com/automattic-acquires-day-one-journaling-app?utm_source=rss&utm_medium=rss&utm_campaign=automattic-acquires-day-one-journaling-app\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7839:\"<img />



<p>Automattic has <a href=\"https://wordpress.com/blog/2021/06/14/day-one-the-journaling-app-joins-automattic/\">acquired Day One</a>, a journaling app available on iPhone, Android, iPad, Mac, and Apple Watch. The app makes it easy to create journal entries on the go, offers end-to-end encryption for privacy on its paid tier, and has offline capabilities. While most users compose private entries, Automattic&rsquo;s acquisition announcement promises integrations for publishing to the web:</p>



<p><em>That doesn&rsquo;t mean that everything you journal has to stay private, though. When you want to share specific entries &ndash; or even entire journals with the world &ndash; you can expect seamless integrations with both WordPress.com and Tumblr to do just that. On the flip side of that, importing your favorite content from WordPress.com and Tumblr into Day One is on the near-term roadmap.&nbsp;</em></p>



<p>In a <a href=\"https://ma.tt/2021/06/day-one-at-automattic/\">post</a> on his personal blog, Automattic CEO Matt Mullenweg said he has been a user of Day One since 2016 and spoke highly of the app&rsquo;s infrastructure: </p>



<p><em>Day One not only nails the experience of a local blog (or journal as they call it) in an app, but also has (built) a great technical infrastructure &mdash;&nbsp;<s>i</s>t works fantastic (when) offline and has a&nbsp;<a href=\"https://help.dayoneapp.com/en/articles/840428-end-to-end-encryption-faq\">fully encrypted sync</a>&nbsp;mechanism, so the data that&rsquo;s in the cloud is secured in a way that even someone with access to their database couldn&rsquo;t decode your entries, it&rsquo;s only decrypted on your local device. Combining encryption and sync in a truly secure way is tricky, but they&rsquo;ve done it.</em></p>



<p>A journaling app is a surprising acquisition for Automattic, which has traditionally gravitated towards snapping up publishing-related companies and tools. WordPress is capable of powering nearly every kind of public-facing website, but private publishing has never been its strong suit. Though many have used WordPress in a sort of &ldquo;private&rdquo; mode for journaling, or set up local installations, the software is not streamlined for this particular use case. Day One expertly handles this niche that has remained relatively untouched in the WordPress ecosystem.</p>



<p>In explaining the acquisition, Mullenweg also touched on his &ldquo;vision of making Automattic the Berkshire Hathaway of the internet,&rdquo; a notion <a href=\"https://awilkinson.medium.com/the-berkshire-hathaway-of-the-internet-391a8ee83db\">shared by Tiny Capital</a> and often applied to Alphabet and its diverse holdings. One distinction is that Automattic&rsquo;s acquisitions tend to complement one another technologically, often introducing the potential for improvements that can be shared with other products through open source software.</p>



<h2>Day One Community Remains Trepidatious About the Acquisition</h2>



<p>Why did Automattic buy the company? Day One customers are curious, as some of them perceive Automattic to be another &ldquo;corporate giant&rdquo; gobbling up a scrappy startup, ready to squeeze every possible drop of revenue out of the app&rsquo;s loyal customers. </p>



<p>Many long-time Day One users have never heard of Automattic and they are understandably leery of seeing their beloved app change hands. Perusing the comments on the <a href=\"https://twitter.com/dayoneapp/status/1404544058693931012\">Twitter announcement</a> and in the app&rsquo;s <a href=\"https://www.facebook.com/groups/DayOneCommunity/\">community on Facebook</a>, the news has precipitated a stream of cancellations and exports as users explore alternatives. Numerous customers were disheartened by one particular ambiguous statement in Day One&rsquo;s <a href=\"https://dayoneapp.com/blog/day-one-at-automattic\">announcement</a>, which left the door open for future changes to the privacy of the app:</p>



<blockquote class=\"wp-block-quote\"><p>Rest assured there are no current plans to change the privacy of Day One; safely protecting memories and creating a 100% personal space is the foundation upon which this company was built.</p></blockquote>



<p>The statement has since been updated to be more reassuring to users, although it still doesn&rsquo;t explicitly promise no changes. It does contain a hint at why Automattic was interested in acquiring the app:</p>



<blockquote class=\"wp-block-quote\"><p>Rest assured that Day One&rsquo;s commitment to protecting your privacy remains unchanged. Safely protecting memories and creating a 100% personal space is the foundation upon which this company was built. (In fact, our technical capabilities around privacy are a large part of what Automattic finds valuable in our company).</p></blockquote>



<p>I have never seen a more engaged community with such a strong reaction following an acquisition. Many are deeply invested, having poured years of their lives and private memories into Day One.</p>



<p>&ldquo;Oh, great. I find a journaling app I really like and have 10 years of entries invested, and they get gobbled up by a bigger fish,&rdquo; one user <a href=\"https://www.facebook.com/groups/DayOneCommunity/permalink/4349118571799031/?comment_id=4349151848462370&__cft__%5B0%5D=AZWO-PD5BkU0Im_Ul_AnDXTjKt3zxfrG01C6D63pV2eE2wbMb18YOS1sjNEx5BHzE2F84C27ZAvdZAOoAdu1EjSqPBnqFUe5AcJs8NJAPLWbPEmjajQAbHdqHjXz5wIpAqeciIm_ogE6bnV_nSoBeZfBpT1jOCDH5o3i9P1MwCzUCUuB4f273tuokE2AbPstgPY&__tn__=R%5D-R\">commented</a> in the app&rsquo;s Facebook community. &ldquo;What will become of our beloved app? Will the safety, security, and integrity of our data be assured? Time to back up all of my data local.&rdquo;</p>



<p>Users have <a href=\"https://www.facebook.com/groups/DayOneCommunity/permalink/4349118571799031/?comment_id=4350115481699340&__cft__%5B0%5D=AZWO-PD5BkU0Im_Ul_AnDXTjKt3zxfrG01C6D63pV2eE2wbMb18YOS1sjNEx5BHzE2F84C27ZAvdZAOoAdu1EjSqPBnqFUe5AcJs8NJAPLWbPEmjajQAbHdqHjXz5wIpAqeciIm_ogE6bnV_nSoBeZfBpT1jOCDH5o3i9P1MwCzUCUuB4f273tuokE2AbPstgPY&__tn__=R%5D-R\">concerns</a> about Day One&rsquo;s updated privacy policy&nbsp;and whether the company might share data with affiliates. Many embraced the app because it was free of any ties with social media platforms. They have sewn themselves into this app in the most vulnerable way, and they are worried about how their private data will be handled in the future. Automattic may have a long road ahead in easing customers&rsquo; concerns so that they don&rsquo;t feel the pressure to export and look for alternatives.</p>



<p>As someone who considered using Day One years ago, I think I would be more likely to use it now, knowing that Automattic is usually in it for the long haul. I passed on Day On at the time because apps come and go and it&rsquo;s not always easy to predict which ones have the right business model to stay afloat. One of my worst recurring nightmares is that I accidentally throw away my paper journals or that my house burns down with my journals inside. Putting trust in a company to keep your electronic data safe and private is an intensely personal decision.</p>



<p>Knowing that a larger company with more resources is behind Day One, along with leadership that bears a genuine appreciation for its underlying tech, it seems like a safer pick for a journaling app that will be around for the next ten years. The company&rsquo;s founder and CEO Paul Mayne will continue to lead his same team at Automattic and is convinced that the move will be beneficial for &ldquo;the preservation and longevity&rdquo; of the app. Given how passionate Day One&rsquo;s user base is about protecting the app&rsquo;s future, I&rsquo;m eager to see how Automattic handles the challenge of winning their confidence.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Jun 2021 05:30:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: Ask the Bartender: Is It OK To Provide WordPress Admin Credentials to Plugin Support Staff?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118497\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:243:\"https://wptavern.com/ask-the-bartender-is-it-ok-to-provide-wordpress-admin-credentials-to-plugin-support-staff?utm_source=rss&utm_medium=rss&utm_campaign=ask-the-bartender-is-it-ok-to-provide-wordpress-admin-credentials-to-plugin-support-staff\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8410:\"<p class=\"has-drop-cap\"><em>No. Nada. Nah. Nope. That&rsquo;s a negative. Under no circumstances. My mama didn&rsquo;t raise no fool. Heck naw. Not on your life.</em> And, the other thousands of ways to tell anyone asking for site credentials to bugger off, even plugin support staff of a &ldquo;trusted&rdquo; WordPress development company.</p>



<p>That is my way of saying that I do not trust anyone. Neither should you. However, there are cases where it is necessary to provide admin permissions to a plugin&rsquo;s support staff.</p>



<p>Today&rsquo;s installment of the <a href=\"https://wptavern.com/tag/ask-the-bartender\">Ask the Bartender</a> series comes courtesy of a reader named Niko. Because the entire text is over 1,000 words, I will simply link to the <a href=\"https://wptavern.com/wp-content/uploads/2021/06/is-it-ok-to-provide-plugin-support-credentials.txt\">transcript via a .txt file</a> for those who want to read it in full. Here in the post, I will stick to the vital bits. Or at least the parts that I want to address.</p>



<p>One of Niko&rsquo;s Facebook group members kicked the discussion off.</p>



<blockquote class=\"wp-block-quote\"><p>&lsquo;Is it okay to send FTP details for a plugin developer to troubleshoot the issue we are having with WooCommerce. We have already provided WordPress Admin credentials.&rsquo;</p><p>This is pretty normal practice in the WordPress world, right? Plugin developers helping out on issues, and if they can&rsquo;t replicate an issue, they need the access so they can check if it is a plugin issue or a server issue and fix things?</p></blockquote>



<p>Over the years, I have seen this become more of a common practice. However, it is not a practice that I recommend from either the user or developer end. Any site owner should ask whether they trust the person to whom they are giving credentials. If the answer to that question is no, you have the answer to the first question.</p>



<p>In over a decade of running a theme and plugin shop, I never needed admin or FTP access to deal with a support question. It did not matter if it was a large and complex plugin or a small one. Because I was the sole person at the company, I also personally answered hundreds of thousands of support questions over the years. Still, not once did I log into a user&rsquo;s site to help them. That always seemed like a liability issue for me, but I also used such scenarios as teaching moments about trust and security.</p>



<p>Users sometimes provided credentials to me without me asking. Often they posted them in plain text in forums, email, or Slack (also, you should never do that). If on-site code needed changing, my users performed the task themselves or installed a bug-free version of the theme/plugin I handed over.</p>



<p>If they did not know how to perform a task via the admin, FTP, or otherwise, I took the time to teach them. Yes, that required more energy on both ends, but I believe we were the better for it. More than once, those moments led some users down the path of becoming developers themselves, or it was at least a tiny stepping stone for them. I remain friends with many of them today and am proud that they started with my little solo WordPress shop.</p>



<p>Some cases were rougher than others. Many times, I would replicate their setup (plugins, theme, etc.) on my machine. The majority of the time, this led me to the solution &mdash; <em>I was using <a href=\"https://developer.wordpress.org/reference/functions/_doing_it_wrong/\"><code>__doing_it_wrong()</code></a> long before WordPress introduced the idea.</em> In the long run, I was able to pass countless bug fixes upstream to other developers. I made a lot of developer friends this way too.</p>



<p>I have no doubts that the road I traveled was the longer of the two. There were times when I spent an hour, two, or even more addressing one user&rsquo;s needs. Popping into some of their WordPress admins would have been a quicker course.</p>



<p>However, my theme and plugin users never needed to worry about whether they trusted me enough to provide that level of access. Plus, I had no chance of accidentally breaking their site by making custom changes.</p>



<p>Are there times when a plugin&rsquo;s support staff <em>really</em> needs access? Probably.</p>



<p>The original question was regarding WooCommerce. It is one of the most technically advanced plugins in existence for WordPress. Replicating a user&rsquo;s setup off-site for it is trickier than most others. There may be <em><strong>rare</strong></em> times when you need to provide some access, but you should never trust anyone.</p>



<p>The second part of Niko&rsquo;s question revolves around the European Union&rsquo;s General Data Protection Regulation (GDPR) and user data. It is a vital part of dealing with those times when you decide to hand over the keys to your website.</p>



<blockquote class=\"wp-block-quote\"><p>Alright so here comes the issue after we think about GDPR. If this developer happens to be outside the EU, then you would need to anonymize customer data and make an NDA agreement with that exact dev or company that is behind the plugin so they can come around and fix things.</p></blockquote>



<p>I will preface this with the usual <em>I am not a lawyer</em>. However, protecting user data is always a legal and ethical priority on any site you run, regardless of what jurisdiction you fall under.</p>



<p>In those &mdash; again, rare &mdash; cases where you need to provide access to your WordPress admin, there are steps you could take to better protect your site and its data. Regardless of the trustworthiness of a developer or a support staff member, there is always one rule of thumb when dealing with website security: trust no one and trust nothing.</p>



<p>The first step should always be having a backup system in place. On the off chance that the support staff breaks something, you will want to revert the site back to its previous state.</p>



<p>Never provide complete admin-level access. I recommend installing and activating a role and capability management plugin. This will allow you to create a custom role for support help and limit the areas of the site they have access to. You would then create a user account for them with this role. Once they have completed their work, delete their account.</p>



<p>If you do not want them to see registered users or do anything with user data at all, make sure their user role does not have the following capabilities:</p>



<ul><li><code>create_users</code></li><li><code>delete_users</code></li><li><code>edit_users</code></li><li><code>list_users</code></li><li><code>promote_users</code></li><li><code>remove_users</code></li></ul>



<p>There are many other admin-level capabilities like <code>edit_files</code>, <code>edit_plugins</code>, and <code>edit_themes</code> that you should also avoid. Essentially, disallow most of the caps from the <a href=\"https://wordpress.org/support/article/roles-and-capabilities/#administrator\">Administrator list in the WordPress documentation</a>.</p>



<p>Most likely, plugin teams might need access to the <code>manage_options</code> capability and any that are custom to their plugin. Even those can be dangerous, but that backup you put in place should mitigate any potential issues.</p>



<p>As for an FTP password? I trust very few people with that level of access.</p>



<p>This reply probably sounds like I do not think any plugin shops or developers are trustworthy. Honestly, I do not know of any that have breached user trust using login or FTP credentials in this way. On the other hand, I have no way of knowing whether the staff member I am talking to plans to rage quit his job in the afternoon and is willing to burn everything down in the morning.</p>



<p>I have also seen a handful of cases where a developer dropped in to fix something but ended up breaking the site along the way. Backups were crucial in addressing those issues.</p>



<p>This post is not meant to make plugin developers or companies appear untrustworthy. Most are good people just trying to make an honest living. However, not trusting anything is website security 101. It is merely the baseline in which users should operate. If you go into any interaction with this mindset, it should help you make smarter decisions on a case-by-case basis.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Jun 2021 23:26:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.8 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10808\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5909:\"<p>WordPress 5.8 Beta 2 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it’s not recommended to run this version on a production site. Consider setting up a test site to play with it.</p>



<p>You can test the WordPress 5.8 Beta 2 in two ways:</p>



<ul><li>Install/activate the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (select the <code>Bleeding edge</code> channel and the <code>Beta/RC Only</code> stream)</li><li>Direct download the beta version here (<a href=\"https://wordpress.org/wordpress-5.8-beta2.zip\">zip</a>).</li></ul>



<p>The current target for the final release is July 20, 2021. That’s just <strong>five weeks away</strong>, so your help is vital to ensure that the final release is as good as it can be.</p>



<h2><strong>Some Highlights</strong></h2>



<p>Since <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\">Beta 1</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=06%2F09%2F2021..06%2F15%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">26</a> bugs have been fixed. Here is a summary of some of the included changes:</p>



<ul><li>Block Editor: Remove bundled block patterns and support the patterns directory. (<a href=\"https://core.trac.wordpress.org/ticket/53246\">#53246</a>)</li><li>Block Editor: Add a type property to allow Core to identify the source of the editor styles. (<a href=\"https://core.trac.wordpress.org/ticket/53175\">#53175</a>)</li><li>Build/Test Tools: Adds some tests for Quick Draft section in Dashboard. (<a href=\"https://core.trac.wordpress.org/ticket/52905\">#52905</a>)</li><li>Build/Test Tools: Replaced <code>@babel/polyfill</code> with <code>core-js/stable</code>. (<a href=\"https://core.trac.wordpress.org/ticket/52941\">#52941</a>)</li><li>Coding Standards: Further update the code for bulk menu items deletion to better follow WordPress coding standards. (<a href=\"https://core.trac.wordpress.org/ticket/21603\">#21603</a>)</li><li>External Libraries: Update Underscore to version 1.13.1. (<a href=\"https://core.trac.wordpress.org/ticket/45785\">#45785</a>)</li><li>General: A number of block editor, template mode and widget screen related fixes. (<a href=\"https://core.trac.wordpress.org/changeset/51149\">#51149</a>)</li><li>Login and Registration: Improve the unknown username error message. (<a href=\"https://core.trac.wordpress.org/ticket/52915\">#52915</a>)</li><li>Media: Restore AJAX response data shape in media library. (<a href=\"https://core.trac.wordpress.org/ticket/50105\">#50105</a>)</li><li>Site Health: Display a list of file formats supported by the GD library. (<a href=\"https://core.trac.wordpress.org/ticket/53022\">#53022</a>)</li><li><span>Twemoji: It&#8217;s the new one! (</span><a href=\"https://core.trac.wordpress.org/ticket/52852\">#52852</a>)</li></ul>



<h2><strong>How You Can Help</strong></h2>



<p>Watch the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a> in the coming weeks, which will break down these and other changes in greater detail.</p>



<p>So far, contributors have fixed <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=..06%2F15%2F2021&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">214 tickets in WordPress 5.8</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&status=reopened&changetime=..06%2F15%2F2021&type=enhancement&type=feature+request&milestone=5.8&group=component&col=id&col=summary&col=type&col=status&col=milestone&col=changetime&col=owner&col=priority&col=keywords&order=changetime\">87 new features and enhancements</a>, and more bug fixes are on the way.</p>



<p><strong>Do some testing!</strong></p>



<p><a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">Testing for bugs</a> is a vital part of polishing the release during the beta stage and a great way to contribute. <img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/2728.png\" alt=\"✨\" class=\"wp-smiley\" /></p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta</a> area in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible <a href=\"https://make.wordpress.org/core/reports/\">bug report</a>, file one on <a href=\"https://core.trac.wordpress.org/newticket\">WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p><em>Props to <a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a> for revision, <a href=\"https://profiles.wordpress.org/webcommsat/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>webcommsat</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>youknowriad</a>, <a href=\"https://profiles.wordpress.org/jorbin/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>jorbin</a>, <a href=\"https://profiles.wordpress.org/felipeelia/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>felipeelia</a> , and <a href=\"https://profiles.wordpress.org/jeffpaul/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>jeffpaul</a> for proofreading, and <a href=\"https://profiles.wordpress.org/cbringmann/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>cbringmann</a> for final edits!</em></p>



<hr class=\"wp-block-separator\" />



<p><em>Install won’t you please<br />WordPress 5-8 Beta 2?<br />We need your help: test!</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Jun 2021 18:34:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Jonathan Desrosiers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Toolbelt Tidies WordPress Plugin and Theme Admin Notifications\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118423\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/toolbelt-tidies-wordpress-plugin-and-theme-admin-notifications?utm_source=rss&utm_medium=rss&utm_campaign=toolbelt-tidies-wordpress-plugin-and-theme-admin-notifications\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5635:\"<p class=\"has-drop-cap\"><em>It&rsquo;s a tale as old as</em>, well, WordPress. Ben Gillbanks noticed a conversation where someone thought that admin notices were getting out of hand. Enter another developer&rsquo;s attempt to address this problem. With a few code additions to his <a href=\"https://wordpress.org/plugins/wp-toolbelt/\">Toolbelt plugin</a>, he had a working solution to stop the madness: <a href=\"https://www.binarymoon.co.uk/2021/06/take-control-of-wordpress-plugin-and-theme-notifications/\">the Tidy Notifications module</a>.</p>



<p>Despite the <a href=\"https://wptavern.com/is-wp-notify-the-silver-bullet-wordpress-needs-to-end-admin-notification-spam\">early promise</a> of the WP Notify project last year, it still feels like we are no closer to addressing the overuse of the current admin notice system in WordPress. In reality, it is not so much a system as a hook that developers can use for literally anything. It is the Wild West of the WordPress admin. No rules. No order. And no proper API for standardizing how notices work.</p>



<p><a href=\"https://github.com/WordPress/wp-notify\">WP Notify still exists on GitHub</a> and continues to move along at its own pace, but there is no guarantee that it will ever land in the core platform. Sometimes, the best thing a developer can do is solve the existing problem and hope that WordPress follows along down the road with a better solution.</p>



<p>I am already tidying admin notifications with Toolbelt on my development install. My primary use case is to hide the non-dismissible notice from the Gutenberg plugin that I have a Full Site Editing theme installed &mdash; <em>is there not a guideline against such notices?</em> I did not suddenly forget that I was using such a theme between the 999th and 1,000th time the reminder appeared on every admin screen of my installation.</p>



<img />Notifications expand when clicking on the bell icon in the toolbar.



<p>The Tidy Notifications system in Toolbelt neatly tucks all admin notices under a bell icon in the admin toolbar. It also displays the number of notifications.</p>



<p>It makes the WordPress admin so clutter-free that I do not know how I have lived without it before. I cannot imagine going back.</p>



<p>The only problem with Toolbelt&rsquo;s solution is that there is no way to distinguish between essential notices and those that should be tucked away. WordPress letting you know that your post was successfully updated is an important notice that should not be hidden. However, a plugin author drumming up five-star reviews, yeah, that should not be front and center.</p>



<p>Having two systems would be beneficial. The existing <code>admin_notices</code> hook in WordPress should be used for letting users know the outcome of their actions or actions that they should take. The post editor, which does not use page reloads or make the hook available, has replaced this with the snackbar popup system. These necessary notices have their place.</p>



<p>However, WordPress has no built-in system for non-essential notices. This leaves plugin and theme authors with two options: bundle an entirely custom notification apparatus with each extension or just use the <code>admin_notices</code> hook. The latter is the more efficient use of developer resources.</p>



<p>Of course, we have had this conversation before. Just shy of a year ago, I wrote a post titled <a href=\"https://wptavern.com/are-plugin-authors-to-blame-for-the-poor-admin-notices-experience\">Are Plugin Authors to Blame for the Poor Admin Notices Experience?</a> In the comments, WordPress project lead Matt Mullenweg <a href=\"https://wptavern.com/are-plugin-authors-to-blame-for-the-poor-admin-notices-experience#comment-335886\">posited that the solution</a> to unwanted notifications is not to build an inbox, comparing WordPress to cell phones. He said that app store guidelines were likely more impactful to user happiness. In general, I agree with that concept. Setting down a few directory UI and UX rules would not hurt.</p>



<p>Given the more recent <a href=\"https://wptavern.com/upcoming-changes-and-steps-for-an-overhauled-wordpress-theme-review-system\">push to loosen guidelines</a> for the theme directory, that does not seem to be in the cards. Admin notices were not one of the guardrails, the safety net of &ldquo;must-haves&rdquo; from the Themes Team.</p>



<p>The admin notice spam WordPress users see today most commonly comes from plugins and not themes. <em>Why?</em> It is not because theme authors care more about user happiness levels. It is because the theme review guidelines over the years have been strict. Anything too flamboyant gets the hammer.</p>



<p>The WordPress Themes Team even has a custom guideline-friendly, <a href=\"https://github.com/WPTT/admin-notices/\">drop-in class</a> that themers can use.</p>



<p>The plugin and theme directories have taken far different stances on admin notices, and it shows. When the Themes Team moves to minimal checks, there may not be anything to stop themers from competing for the most obnoxious admin notice award. <em>Game on, plugin authors.</em></p>



<p>&ldquo;Unwanted&rdquo; notifications may even be the wrong terminology. Often, they are &ldquo;unwanted right now.&rdquo; Sometimes, folks might want to read a message &mdash; just later. I am still holding out hope that we will have a notifications/messages inbox in WordPress one day. One that is entirely controlled by the user.</p>



<p>Until then, I may just stick with the Tidy Notifications module in Toolbelt. There are many other handy components in it too.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Jun 2021 22:54:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Wordfence Now Authorized as a CVE Numbering Authority\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118413\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:171:\"https://wptavern.com/wordfence-now-authorized-as-a-cve-numbering-authority?utm_source=rss&utm_medium=rss&utm_campaign=wordfence-now-authorized-as-a-cve-numbering-authority\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4968:\"<p>Wordfence has been <a href=\"https://www.wordfence.com/blog/2021/06/wordfence-is-now-a-cve-numbering-authority-cna/\">authorized</a> by the Common Vulnerabilities and Exposures (CVE&reg;) Program as a CNA (CVE Numbering Authority), which allows the company to directly assign CVE numbers for new vulnerabilities in WordPress core, plugins, and themes. The authority is granted by <a href=\"https://www.mitre.org/\">Mitre Corporation</a>, a federally-funded US non-profit that manages research and development centers. Wordfence anticipates that the ability to create CVE assignments will expedite its security research.</p>



<p>&ldquo;As the Wordfence Threat Intelligence team continues to produce groundbreaking WordPress security research, Wordfence can more efficiently assign CVE IDs prior to publicly disclosing any vulnerabilities that our team discovers,&rdquo; Wordfence threat analyst Chloe Chamberland said. &ldquo;This means that a CVE ID will be immediately assigned with every vulnerability we discover rather than waiting for an assignment from an external CNA.&rdquo;</p>



<p>Not having to wait on a CVE ID is a major advantage for the company, especially when working with enterprise installations where WordPress is used in combination with other software. It also helps security personnel prioritize and act based on the potential severity of threats. </p>



<p>&ldquo;Our efforts to become a CNA had these individuals, institutions, and enterprise personnel in mind, as well as WordPress&rsquo; reputation as a whole,&rdquo; Chamberland said. &ldquo;Now, those tasked with securing WordPress will be able to quickly reference the CVE ID from our blog posts when reporting vulnerabilities throughout their organization and handling security update prioritization. We also hope that by being a CNA, Wordfence will receive even more direct reports from security researchers.&rdquo;</p>



<p>Becoming a CNA simplifies a security company&rsquo;s process of submitting vulnerabilities. Wordfence is the second company to become one, operating within the scope of WordPress and related vulnerabilities. In January 2021, <a href=\"https://wptavern.com/wpscan-can-now-assign-cve-numbers-for-wordpress-core-plugin-and-theme-vulnerabilities\">WPScan was granted CVE Numbering Authority status</a>. Prior to becoming a CNA, assigning CVEs for every vulnerability in WPScan&rsquo;s database would have been too time consuming.</p>



<p>&ldquo;Becoming a CNA has allowed us to help security researchers to verify and triage their vulnerabilities,&rdquo; WPScan founder and CEO Ryan Dewhurst said. &ldquo;This has helped grow our WordPress vulnerability database and keep WordPress users secure. But it is just one source of vulnerabilities among many others that we use.&rdquo;</p>



<p>The process for Wordfence to become a CNA was surprisingly simple. Chamberland said the company filled out a registration form with a few questions. </p>



<p>&ldquo;Once we were approved and agreed upon a scope, you are required to watch a series of onboarding videos that explain the processes required of a CNA,&rdquo; she said. &ldquo;After that, we had an onboarding meeting to ensure our team was fully trained on CVE Program protocols. It took Wordfence about a month to get authorized as a CNA once they received our registration form.&rdquo;</p>



<p>Historically, the WordPress ecosystem has been a magnet for those looking to exploit vulnerabilities, due to its large footprint on the web. That trend is likely to continue. Chamberland believes there is room for multiple CNA&rsquo;s in the WordPress space.</p>



<p>&ldquo;We&rsquo;ve had a great working relationship with WPScan over the years, and we expect that this relationship will continue as we have a similar mission in helping secure the WordPress community,&rdquo; she said.</p>



<p>&ldquo;As WordPress grows, it becomes a larger and more attractive target for malicious actors. The more hands we have on deck, and the better we collaborate and adhere to industry standard security practices, the safer WordPress will be.&rdquo;</p>



<p>Attracting more researchers to report vulnerabilities is a major benefit to security companies that gain CNA status, since they are essentially in the business of selling vulnerability protection data. They give their paid customers early access to patches that are not yet available to the general public. Becoming a CNA has the potential to increase the value their businesses can provide. </p>



<p>&ldquo;With this growth in WordPress, we expect to see more security researchers in the WordPress space,&rdquo; Chamberland said.&nbsp;&ldquo;As such, we are bound to see an increase in CVE ID requests. Having multiple CNA&rsquo;s that can assign CVE IDs to WordPress core, plugins and themes make sense to improve the speed in which security researchers can obtain CVE IDs, and provides researchers with multiple sources for CVE IDs.&rdquo;<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Jun 2021 21:44:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Day One at Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=54355\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://ma.tt/2021/06/day-one-at-automattic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2932:\"<p>I&#8217;m not sure when I first came across the <a href=\"https://dayoneapp.com/\">critically acclaimed Day One product</a>, which is the best private blogging and journaling app out there, but I began seriously using it daily in 2016 when my father was in the ICU and <a href=\"https://ma.tt/2016/04/in-memoriam-chuck-mullenweg/\">later passed</a>. Having a private, safe place to write what I was going through kept me sane and helped me process everything.</p>



<p>Writing has always been a salve for me, and I&#8217;ve had local or private WordPress installations pretty much since 2003 to capture and archive writing that wasn&#8217;t fit for the public web.</p>



<p>Day One not only nails the experience of a local blog (or journal as they call it) in an app, but also has (built) a great technical infrastructure — it works fantastic (when) offline and has a <a href=\"https://help.dayoneapp.com/en/articles/840428-end-to-end-encryption-faq\">fully encrypted sync</a> mechanism, so the data that&#8217;s in the cloud is secured in a way that even someone with access to their database couldn&#8217;t decode your entries, it&#8217;s only decrypted on your local device. Combining encryption and sync in a truly secure way is tricky, but they&#8217;ve done it.</p>



<p>This is a long intro to say, as you can read from <a href=\"https://dayoneapp.com/blog/day-one-at-automattic\">Day One&#8217;s founder and CEO Paul Mayne</a>, <a href=\"https://wordpress.com/blog/2021/06/14/day-one-the-journaling-app-joins-automattic/\">from Eli at WordPress.com</a>, and <a href=\"https://staff.tumblr.com/post/653995690228400128/private-blogging-its-a-vibe-but-some-innermost\">on Tumblr</a>, that Paul and the team are joining the team at <a href=\"https://automattic.com/\">Automattic</a>. For many years I&#8217;ve talked to anyone who will listen about my vision of making Automattic the <a href=\"https://www.berkshirehathaway.com/\">Berkshire Hathaway</a> of the internet, and Paul&#8217;s decision to continue to grow his amazing business as part of Automattic is a great validation of the way we&#8217;ve been building our culture and long-term orientation in our business. Day One is a beloved product, and bringing it into the fold is a responsibility I take very seriously and comes from a deep respect for what&#8217;s been built and a belief that working together we can create something for users better than we could working apart.</p>



<p>Great software takes time, and the Day One team has been at it for <a href=\"https://dayoneapp.com/about/\">about a decade now</a>, I can&#8217;t wait to see what they accomplish in the coming decade and beyond. If you haven&#8217;t tried out Day One yet, please check it out in the <a href=\"https://apps.apple.com/us/app/day-one-2-journal-notes/id1044867788\">Apple</a> or <a href=\"https://play.google.com/store/apps/details?id=com.dayoneapp.dayone&hl=en\">Google&#8217;s</a> app store.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 14 Jun 2021 20:53:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: WordPress 5.8 Beta 1 Released: New Blocks, New Widgets Screen, and Pattern Directory on Deck\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118227\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:243:\"https://wptavern.com/wordpress-5-8-beta-1-released-new-blocks-new-widgets-screen-and-pattern-directory-on-deck?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-8-beta-1-released-new-blocks-new-widgets-screen-and-pattern-directory-on-deck\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7429:\"<p><a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\">WordPress 5.8 beta 1</a> is ready for testing. This upcoming release makes major strides towards solidifying WordPress&rsquo; site building capabilities, along with improvements to features users have enjoyed since the launch of the block editor. It is one of the most feature-packed releases in recent history and as such requires all hands on deck for testing. </p>



<p>New blocks in 5.8 include Page List, Site Title, Logo, Tagline, Query Loop, and Duotone. I decided to take each one for a spin this weekend on a test site, putting myself in the shoes of someone trying these blocks for the first time.</p>



<p>I was surprised to learn that the template editor will be available to sites using any WordPress theme, since all the previous FSE testing rounds have called on testers to use the latest version of the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://wordpress.org/themes/tt1-blocks/\" target=\"_blank\">TT1 Blocks Theme</a>. It will be interesting to see how users respond to this and if it works well with older themes. Users can now create and edit custom templates for pages and posts using blocks. </p>



<div class=\"wp-block-image\"><img /></div>



<p>The template editor includes the new List View panel that gives an overview of all the sections and blocks in the template.</p>



<div class=\"wp-block-image\"><img /></div>



<p>Most of the new blocks in 5.8 are intended to work within the context of the template editor, but they also work in the post editor.</p>



<p>The Page List block magically populates a list of all the pages on a site as soon as it is inserted. Unfortunately, there isn&rsquo;t a way to delete a single page from the list. If you try to delete a page the entire block disappears. This seems like a bug and is a frustrating experience in the context of the post editor. It may be more useful in terms of building navigation but this seems like a rough first pass.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The Query Loop block comes with some different designs for how the loop could be displayed. Once a basic layout is chosen for a starting point, users can further customize the blocks within the loop, including typography, color, length of excerpt, and more.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The Site Title, Tagline, and Logo blocks all seem to work as expected but I found previews to be unreliable for things like alignment and spacing. At this point in time, it seems like template editing will be better suited to users who are more adventurous and experimental when it comes to new features.</p>



<p>Duotone is a fun new core block that you can see in action below, demonstrated by WordPress documentation contributor Milana Cap. The block adds images effects that can be used in media blocks. Theme and plugin developers can also employ and customize the effects for their own particular use cases.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Oh. My. Gutenberg.<br /><br />Imagine images in duotone on your website &#129327; <br /><br />And now that you imagined it, you want it, right? Right?<br /><br />It\'s coming up in <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> 5.8 &#128525; stay tuned &#128522; <a href=\"https://t.co/t5JHBcTEOV\">pic.twitter.com/t5JHBcTEOV</a></p>&mdash; Milana Cap (@DjevaLoperka) <a href=\"https://twitter.com/DjevaLoperka/status/1402552814174457856?ref_src=twsrc%5Etfw\">June 9, 2021</a></blockquote>
</div>



<h2>Hello New Widgets Screen!</h2>



<p>WordPress users will be greeted with a new block-based widgets screen in 5.8. It allows you to use blocks in any widgetized area. It wasn&rsquo;t until I saw how this works that I realized how rigid our old widgets system was. Whatever functionality you were trying to insert had to be readily available as a widget or shortcode. Now any block from the vast world of blocks can be added to widgetized areas. </p>



<p>Justin Tadlock wrote a post about <a href=\"https://wptavern.com/classic-widgets-plugin-disables-wordpress-5-8s-upcoming-block-based-widgets-system\">how users can disable it with the Classic Widgets plugin</a>. Should you disable it? Not unless you are forced to because of using a theme that doesn&rsquo;t support it very well. Using blocks in widget areas is going to give you much more flexibility for what you can insert. You can even continue to use the old style widgets via the&nbsp;<a href=\"https://developer.wordpress.org/block-editor/how-to-guides/widgets/legacy-widget-block/\">Legacy Widget block</a>. Users may need a little time to adapt to the new interface but it&rsquo;s worth it to have access to the growing world of innovative blocks.</p>



<div class=\"wp-block-image\"><img /></div>



<h2>Pattern Directory Will Be Integrated with WordPress 5.8</h2>



<p>The new Pattern Directory will launch on WordPress.org along with the 5.8 release. Justin Tadlock recently <a href=\"https://wptavern.com/open-invitation-to-contribute-to-the-wordpress-block-pattern-directory\">amplified the Design Team&rsquo;s call for pattern contributions</a> that would be available to users right away. Several have already been <a href=\"https://github.com/WordPress/pattern-directory/issues\">submitted via GitHub issues</a> for the directory and the creativity here is energizing. In addition to introducing an exciting new avenue for designers to put their work out into the ecosystem, the Pattern Directory stands to become a valuable resource and inspiration to users who are designing their own websites.</p>



<img />A &ldquo;<a href=\"https://github.com/WordPress/pattern-directory/issues/178\">How It Works</a>&rdquo; pattern submitted by <a href=\"https://github.com/laxmariappan\">Lax Mariappan</a>



<p>At launch the directory will only contain patterns that use core blocks but using blocks from WordPress.org may also be a possibility in the future.</p>



<p>&ldquo;There have definitely been some discussion of allowing any blocks from the&nbsp;Block&nbsp;Directory to be used and that they would be auto-installed if someone inserted the pattern,&rdquo; Shaun Andrews <a href=\"https://make.wordpress.org/design/2021/06/08/initial-patterns-for-the-wordpress-org-patterns-directory/#comment-26330\">commented</a> in response to a theme studio inquiring about submitting their own patterns that use free blocks. &ldquo;I believe this is possible, and something we should do, but there simply hasn&rsquo;t been any work done to enable it yet.</p>



<p>&ldquo;We&rsquo;re focused on getting the first iteration of the Pattern Directory launched, and then we plan to continue improving things.&rdquo;</p>



<p>Pattern transformation is a new feature launching with the new directory, which allows users to convert a block or collection of blocks into different patterns. Patterns can also be recommended and selected during block setup, which should make product onboarding easier.</p>



<p>These are just a few features coming in WordPress 5.8 that need testing. Check out the <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\">5.8 beta 1 release post</a> for a more comprehensive list of all the improvements that are on deck. The official release is scheduled for <a href=\"https://make.wordpress.org/core/5-8/\">July 20, 2021</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 13 Jun 2021 02:07:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"Gutenberg Times: Over 50 Patterns in the  Pattern Directory, Learn Full-site editing, WordCamp Europe – Weekend Edition #173\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=18121\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"https://gutenbergtimes.com/over-50-patterns-in-the-pattern-directory-learn-full-site-editing-wordcamp-europe-weekend-edition-173/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19222:\"<p>Howdy, </p>



<p>After three and a half years, it was time to replace the WordPress theme on the Gutenberg Times. The trigger: I wrote about <a href=\"https://web.dev/measure/\">Core Web Vitals</a> for a different project and used the Gutenberg Times as a test project, using <a href=\"https://developers.google.com/web/tools/lighthouse\">Google&#8217;s Lighthouse</a> via an incognito browser window. The desktop version performed very well, all circles in the green range, but the mobile version really crawled over the Internet, ranking in the low 40ties. </p>



<p><a href=\"https://searchengineland.com/google-postpones-page-experience-update-rollout-347862\">Google announced</a> earlier this year that they start rolling out new page experience update in this month, and start using Web Vitals as another ranking factor for organic search results. I also noticed that GT had a very high number of visitors via the desktop, but not many on mobile, which I found odd. Now I know why. </p>



<p><a href=\"https://andersnoren.se/introducing-eksell/\">Anders Noren&#8217;s Eksell</a> is our new theme. I love the typography, the clean design. and its graphics. I just started exploring it. Nothing gets things done faster than working on the live site. ?</p>



<p>The content mostly converted well, except there are no widget areas, so I would need to add the widget via the Legacy widget block. It was hit-and-miss. This exercise turned out to be a great test for the new block-based Widget screen, which will come to a WordPress instance near you in the 5.8 release on July 20th, 2021. </p>



<p>From the discussions, I learned that the Gutenberg team is leaning towards an opt-out rather than an opt-in implementation. Testing sites with this week&#8217;s <a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\">WordPress 5.8 Beta 1</a>, is definitely recommended. If you don&#8217;t have time to test all the site you are working on, rest easy, there is a <a href=\"https://wordpress.org/plugins/classic-widgets/\">Classic Widget plugin</a> you can install to keep the old Widget screen.  </p>



<p>What else happened this week? <strong>WordCamp Europe! </strong>It was a great virtual conference. Kudos to the organizers, speakers, sponsors and attendees! If you missed it, you can watch the <a href=\"https://www.youtube.com/channel/UCaYQGYDpXpU4A17kxN-AgJQ\">recordings on YouTube.</a></p>



<p>The video with the <a href=\"https://wordpress.org/news/2021/06/gutenberg-highlights/\"><strong>Gutenberg Highlights</strong></a> is available for those of use who missed the Conversation with Matt Mullenweg. <strong>Matias Ventura</strong> wrote: &#8220;The video is wonderfully narrated by&nbsp;<strong>Beatriz Fialho</strong>, and it was a great opportunity to celebrate all the incredible work that contributors are doing around the globe to improve the editing and customization experience of WordPress&#8221;. I will <a href=\"https://gutenbergtimes.com/wordcamp-europe-2021-starts-monday/\">update my earlier WCEU post </a>with links to videos and resources over the course of next week. </p>



<p>As always, I am so glad you are here, reading the eNews every week. Thank you! </p>



<p>Yours, ?<br />Birgit</p>





<div class=\"wp-block-group has-primary-color has-light-background-background-color has-text-color has-background\"><div class=\"wp-block-group__inner-container\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong>on <strong>June 24, 2021, at 11am EDT / 15:00 UTC</strong></p>



<a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a>



<p><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Theme.json for Theme Authors or building themes for full-site editing in WordPress.</a></strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olson, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>WordPress 5.8 Release Cycle</h2>



<p><a href=\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\">WordPress 5.8 Beta 1</a> was release on Tuesday. You can use the official  <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">Beta Tester Plugin </a>to test this version. If you haven&#8217;t used it before, the Core Team share information and <a href=\"https://make.wordpress.org/core/handbook/testing/beta-testing/\">instructions in their handbook</a>.</p>



<p>You can read more about the <a href=\"https://make.wordpress.org/core/5-8/\">development cycle of WordPress 5.8 here</a>. Feature Freeze for this upcoming version was May 25. We are right now in the beta phase of the cycle. It will be used for testing and to fix bugs. That is to last until June 29, 2021, when the first Release Candidate will be released.  That&#8217;s also the deadline for Dev Notes and Field Guide. It also comes with a hard-string freeze. That&#8217;s the moment the Polyglots team starts with translations. </p>



<h3>Features and updates for WordPress 5.8</h3>



<p>Speaking of <strong>DevNotes</strong>, the Gutenberg team tracks their progress on the  DevNotes via <a href=\"https://github.com/WordPress/gutenberg/issues/32365\">this GitHub issue.</a>  You can get a head start on <a href=\"https://gist.github.com/gziolo/cbea77500316a243e445d509ced3c231\"><strong>&#8220;Block API Enhancements&#8221;</strong></a> by <strong>Grzegorz Ziolkowski</strong> or <strong><a href=\"https://github.com/WordPress/gutenberg/issues/32365#issuecomment-853726663\">&#8220;Contextual patterns for easier creation and block transformations&#8221;</a> </strong>by <strong>Nik Tsekouras</strong> before they are published on the Make Core blog. </p>



<p><strong>Anne McCarthy</strong> posted about other <strong>Block Editor Enhancements:</strong> </p>



<ul><li><a href=\"https://make.wordpress.org/core/2021/05/20/core-editor-improvement-contextual-patterns-for-easier-creation/\">Contextual patterns for easier creation</a>  and </li><li>How to <a href=\"https://make.wordpress.org/core/2021/06/09/core-editor-improvement-improve-your-workflow-with-list-view/\">improve your workflow with List View</a>, the former Block Navigator feature. </li></ul>



<p>On the WordPress News Blog, you found earlier: <a href=\"https://wordpress.org/news/2021/05/coloring-your-images-with-duotone-filters/\"><strong>Coloring Your Images With Duotone Filters</strong></a> by <strong>Alex Lende</strong>. Yes, I am in love with it, that&#8217;s why I mentioned it again. Gutenberg 10.7 also brought the methods to <strong>disable  duotone </strong>via the theme.json file. <a href=\"https://github.com/WordPress/gutenberg/pull/32002\">The details are in this Lende&#8217;s PR</a>. </p>



<p><strong>Adam Silverstein</strong> published <a href=\"https://make.wordpress.org/core/2021/06/07/wordpress-5-8-adds-webp-support/\">WordPress 5.8 adds WebP support</a> dev note. It&#8217;s not directly a block editor update but crucial for content creators and developers alike, especially in context of the Core Web Vitals when speed is becomes of the essence. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>Gutenberg Changelog</h2>



<p>It&#8217;s been two years since Mark Uraine and I started the <a href=\"https://gutenbergtimes.com/podcast\">Gutenberg Changelog</a> podcast, and he was my co-host for the first 40 episodes. Grzegorz Ziolkowski joined me as co-host with episode 41. In February 2021, we celebrated the first 10,000 downloads. Now four months later, we passed the 26,000 mark of downloads. For such a narrow niche show, these are mind-boggling numbers.  It is very humbling.  We are very grateful for our faithful listeners! Thank you all very much. </p>



<p><strong>Grzegorz Ziolkowski</strong> is back from vacation, and we recorded episode 45. We covered Gutenberg 10.7 and 10.8 releases, WordCamp Europe and WordPress 5.8.  It will be published later this weekend. The similar t-shirts? Mere coincidence! </p>



<img />



<h2>Gutenberg 10.8</h2>



<p><strong>Gutenberg 10.8</strong> was released this week. It had quite a few enhancements, and a ton of bug fixes and underlying code change for quality and tooling. <strong>Sandip Mondal</strong> work on his first release and published the release notes: <a href=\"https://make.wordpress.org/core/2021/06/10/whats-new-in-gutenberg-10-8-9-june/\"><strong>What’s new in Gutenberg 10.8? (9 June)</strong></a>. </p>



<p>Justin Tadlock has more details <strong><a href=\"https://wptavern.com/gutenberg-10-8-adds-new-typography-controls-and-block-previews\">Gutenberg 10.8 Adds New Typography Controls and Block Previews</a></strong></p>



<p>The enhancements for full-site editing and theme design controls are already for the next WordPress release (5.9) in December and require more testing before they are available for WordPress Core. </p>



<h2>Block Patterns</h2>



<p><strong>Kjell Reigstad</strong> posted an invitation for the WordPress community to submit Block Patterns to the official WordPress directory. In his post <a href=\"https://make.wordpress.org/design/2021/06/08/initial-patterns-for-the-wordpress-org-patterns-directory/\"><strong>Initial Patterns for the WordPress.org Patterns Directory</strong></a>, he explained the details of the submission process.  </p>



<p><strong>Justin Tadlock</strong>, a big fan of block patterns, wrote about the invitation on the <a href=\"https://wptavern.com/open-invitation-to-contribute-to-the-wordpress-block-pattern-directory\">WordPress Tavern </a>and showcased some of his creations. <strong>Ana Segota, </strong>co-founder of <a href=\"https://www.anarieldesign.com/\">Anariel Design</a> shared <a href=\"https://twitter.com/Ana_Segota/status/1402688373421187080\">her submissions via Twitter.</a> </p>



<p>You can <a href=\"https://github.com/WordPress/pattern-directory/issues?q=is%3Aissue+label%3A%22%5BType%5D+Pattern+Submission%22+is%3Aclosed\"><strong>review the list of submissions on GitHub</strong></a> and learn from the comments on by the design team. Brian Gardner, Tammie Lister, Mel Choyce, Kjell Reigstad and Beatriz Fialho also contributed patterns to the directory. </p>



<a href=\"https://wordpress.org/patterns\"><img /></a><a href=\"https://wordpress.org/patterns\">Block Patterns on WordPress.org</a> submitted by members of the design team and from the WordPress community. 



<p class=\"is-style-default\">In total, I counted 54 block patterns available to WordPress users. What a great start! </p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>Full Site Editing</h2>



<p>At WordCamp Europe 2021, the Panelist <strong>Danielle Zarcaro, Grzegorz Ziółkowski, Koen Van den Wijngaert and Milana Cap</strong> discussed Full Site editing and what it means for the broader WordPress community. <a href=\"https://gutenbergtimes.com/wordcamp-europe-full-site-editing-panel-discussion/\"><strong>We have the recording and the transcript for you</strong></a></p>



<hr class=\"wp-block-separator\" />



<p>We added the Blockbase Theme to the list of<a href=\"https://gutenbergtimes.com/themes-for-full-site-editing-and-getting-ready-for-wordpress-5-8-weekend-edition-172/#fsethemes\"> available FSE themes</a> last week. <strong>Kjell Reigstad</strong> published <a href=\"https://themeshaper.com/2021/06/07/using-blockbase-for-a-theme-experiment/\">Using Blockbase for a theme&nbsp;experiment</a> on the ThemeShaper blog and take you on a journey on creating a child theme of Blockbase. He wrote &#8220;Overall, I found that the benefit to using Blockbase was peace of mind. Compared to starting fresh or using&nbsp;<code>emptytheme</code>, Blockbase ensured that I had a fully functional block theme immediately.&#8221; Kjell also shared his code on GitHub.</p>



<hr class=\"wp-block-separator\" />



<p>The <strong>WPMarmite Team</strong> publish the results of their <a href=\"https://wpmarmite.com/en/fse-study/\"><strong>Full Site Editing Study: Will WordPress theme shops embrace this new paradigm?</strong></a> They studied the involvement in the current FSE development of 127 Theme shops.  </p>



<p>At first glance, these seemed to be a little premature, considering that only architecture for themes supporting FSE is coming to WordPress at the end of July. It certainly sets the base numbers to see what will happen until December. These are the numbers to watch changing in the next half year, and it will answer the original questions. </p>



<ul><li><strong>57%</strong>&nbsp;of theme shops&nbsp;<strong>feature their Gutenberg compatibility</strong>.</li><li>Only&nbsp;<strong>17%</strong>&nbsp;of theme shops&nbsp;<strong>offer custom Gutenberg blocks</strong>.</li><li><strong>3%</strong>&nbsp;of theme shops&nbsp;<strong>provide block patterns</strong>.</li></ul>



<p>The team also talked to 22 theme shops about their intentions regards full-site editing.  <a href=\"https://wpmarmite.com/en/fse-study/\">You need to read the article to learn more</a>.  </p>



<hr class=\"wp-block-separator\" />



<p><strong>Fränk Klein</strong> at WPDeveloper Courses, released his new course: <a href=\"https://wpdevelopment.courses/courses/building-block-based-themes/\"><strong>Building Block-Based Themes</strong></a>. If you want to learn how to build a real-life example theme and all the ins and outs for a theme using the full-site editing capabilities and theme.json.  </p>



<p>On Fullsiteediting.com, <strong>Carolina Nymark</strong> has been offering her <a href=\"https://fullsiteediting.com/courses/full-site-editing-for-theme-developers/\">Full Site editing course</a> for free, but that might change soon. </p>



<p><strong>Joe Casabona</strong> at <a href=\"https://creatorcourses.com/\">CreatorCourses </a>is also working on an update of his Gutenberg Theme course. </p>



<p>My take-away from the acquisitions of Atomic Blocks, Co Blocks etc. is that early adopters found it quite worth their while to deal with the ever-moving goal posts while developing along site Gutenberg developers.  The future is yours! </p>



<hr class=\"wp-block-separator\" />



<h2 id=\"events\">Upcoming WordPress Events</h2>



<p><strong>June 6, 2021</strong> <strong>7:00 pm EDT / 23:00 UTC</strong><br /><strong><a href=\"https://www.meetup.com/Philadelphia-WordPress-Meetup-Group/events/278507419/\">WordPress Meetup Philadelphia</a></strong><br />Full Site Editing Review and Test-a-thon</p>



<p><strong>June 7 &#8211; 9th, 2021</strong><br /><strong><a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a></strong><br />A virtual event and contributor day. <a href=\"https://europe.wordcamp.org/2021/call-for-sponsors/\">Call for sponsors is open.</a></p>



<p><strong>?</strong>  Gutenberg Times is a media partner of WordCamp Europe 2021 </p>



<p><strong>June 10th, 2021</strong><br /><strong><a href=\"https://www.meetup.com/SF-WordPress-Users/events/278491308\">WordPress &#8220;Mega Meetup&#8221;: Plugins That Keep Websites Running</a></strong></p>



<p><strong>June 20 &#8211; 26, 2021</strong><br /><strong><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></strong><br /><em>The schedule has been posted. Most sessions will be in Japanese, with exceptions, I think&#8230; </em></p>



<p><strong>June 24, 2021 </strong><br /><strong><a href=\"https://attend.wpengine.com/summit-us-2021/\">WPEngine Summit 2021</a></strong><br /><em>The digital breakthrough conference</em> <a href=\"https://events.wpengine.com/event/fd217870-fc78-46d2-8c5e-96c85e6e371c/websitePage:645d57e4-75eb-4769-b2c0-f201a0bfc6ce?environment=P2&tm=nSwmA1-ZyLXwe2wM80Vzve3wDjKBWeqKrHbJFivPV4o&locale=en-US\">released their schedule</a>. Personally, I am very much looking forward to the Keynote talk with <strong>Reshma Saujani</strong>, founder of Girls Who Code and Marshall Plan for Moms at 12:55 EDT / 16:55 UTC.  I also hope to see talks with Rob Stinson, Carrie Dils and Chris Wiegman. There are also deep dive talks listed into Headless WordPress. Enterprise WordPress is definitely heading down that route. </p>



<p><strong>June 24 &#8211; 26, 2021</strong><br /><strong><a href=\"https://cochabamba.wordcamp.org/2021/\">WordCamp Cochabama</a></strong> (Colombia) </p>



<p><strong>July 17 + 18th, 2021</strong><br /><strong><a href=\"https://santaclarita.wordcamp.org/2021/\">WordCamp Santa Clarita</a></strong><br />Calls for speakers ends TODAY! </p>



<p><strong>July 23, 2021</strong><br /><a href=\"https://www.wordfest.live/\"><strong>WordFest Live </strong></a>&#8211; <em>The&nbsp;</em>festival of WordPress</p>



<p>A<strong>ugust 6 + 7, 2021</strong><br /><a href=\"https://nicaragua.wordcamp.org/2021/\"><strong>WordCamp Nicaragua</strong></a></p>



<p><strong>September 21 + 22, 2021</strong><br /><a href=\"https://2021.wpcampus.org/\"><strong>WPCampus 2021 Online</strong></a><br />&#8220;A free online conference for web accessibility and WordPress in higher education.&#8221;</p>



<hr class=\"wp-block-separator\" id=\"block-ee0670b9-9b56-410a-a5c8-1febc106dca5\" />



<p id=\"block-8c56f083-3d78-42e0-84ec-62ea90a2afa5\">On the<a href=\"https://wpcalendar.io/online/\"> <strong>Calendar for WordPress Online Events</strong> </a>you can browse a list of the upcoming WordPress Meetups, around the world, including WooCommerce, Elementor, Divi Builder and Beaver Builder meetups.</p>




<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-text-align-center\"><strong>Don&#8217;t want to miss the next Weekend Edition? </strong></p>



<form class=\"wp-block-newsletterglue-form ngl-form ngl-portrait\" action=\"https://gutenbergtimes.com/feed/\" method=\"post\"><div class=\"ngl-form-container\"><div class=\"ngl-form-field\"><label class=\"ngl-form-label\" for=\"ngl_email\">Type in your Email address to subscribe.</label><div class=\"ngl-form-input\"><input type=\"email\" class=\"ngl-form-input-text\" name=\"ngl_email\" id=\"ngl_email\" /></div></div><button class=\"ngl-form-button\">Subscribe</button><p class=\"ngl-form-text\">We hate spam, too and won&#8217;t give your email address to anyone except Mailchimp to send out our Weekend Edition</p></div><div class=\"ngl-message-overlay\"><div class=\"ngl-message-svg-wrap\"></div><div class=\"ngl-message-overlay-text\">Thanks for subscribing.</div></div><input type=\"hidden\" name=\"ngl_list_id\" id=\"ngl_list_id\" value=\"26f81bd8ae\" /><input type=\"hidden\" name=\"ngl_double_optin\" id=\"ngl_double_optin\" value=\"yes\" /></form>



<hr class=\"wp-block-separator is-style-wide\" />




<p>Featured Image: <a href=\"https://unsplash.com/@xavi_cabrera?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText\">Photo by&nbsp;</a><a href=\"https://unsplash.com/@pawel_czerwinski?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText\">Pawel Czerwinski</a>&nbsp;on&nbsp;<a href=\"https://unsplash.com/s/photos/blocks-of-flats?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText\">Unsplash</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Jun 2021 18:39:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Birgit Pauli-Haack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Gutenberg Times: WordCamp Europe: Full-Site Editing Panel discussion\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=18145\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://gutenbergtimes.com/wordcamp-europe-full-site-editing-panel-discussion/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:43875:\"<p>It was announced as a discussion panel about the present and future of WordPress with Full Site Editing.</p>



<p>The panelists, highly involved in this new feature, discussed many topics about FSE and how it is going to be a new revolution in the WordPress ecosystem.</p>



<p>The Panelist were <a href=\"https://europe.wordcamp.org/2021/speaker/danielle-zarcaro/\">Danielle Zarcaro</a>, <a href=\"https://europe.wordcamp.org/2021/speaker/grzegorz-ziolkowsk/\">Grzegorz Ziółkowski</a>, <a href=\"https://europe.wordcamp.org/2021/speaker/koen-van-den-wijngaert/\">Koen Van den Wijngaert</a> and <a href=\"https://europe.wordcamp.org/2021/speaker/milana-cap/\">Milana Cap</a></p>



<p>Jose Ramon Padron and Lesley Molecke moderated the discussion. </p>



<div class=\"wp-block-embed__wrapper\">
<div class=\"toolbelt-video-wrapper\"></div>
</div>



<p>Torque Magazine did an outstanding job live tweeting. </p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">\"With FSE a theme developer can develop with a more solid foundation. More of their time and energy can be spent building things that have more value for their customers\" <a href=\"https://twitter.com/vdwijngaert?ref_src=twsrc%5Etfw\">@vdwijngaert</a></p>&mdash; Torque (@TheTorqueMag) <a href=\"https://twitter.com/TheTorqueMag/status/1401945858598338562?ref_src=twsrc%5Etfw\">June 7, 2021</a></blockquote>
</div>



<p class=\"has-large-font-size\" id=\"0-the-transcript-and-table-of-contents\"><strong>The transcript and table of contents</strong></p>



<div class=\"wp-block-sortabrilliant-guidepost\"><ul><li><a href=\"https://gutenbergtimes.com/feed/#0-introduction-of-the-topic-and-the-panelists\">Introduction of the topic and the panelists</a></li><li><a href=\"https://gutenbergtimes.com/feed/#1-what-is-full-site-editing-and-where-did-it-come-from-nbsp\">What is full site editing and where did it come from?</a></li><li><a href=\"https://gutenbergtimes.com/feed/#2-what-problem-does-full-site-editing-solve\">What problem does Full-Site Editing solve?</a></li><li><a href=\"https://gutenbergtimes.com/feed/#3-what-happens-to-websites-that-are-live-in-production-when-word-press-5-8-is-released\">What happens to websites that are live (in production) when WordPress 5.8 is released?</a></li><li><a href=\"https://gutenbergtimes.com/feed/#4-what-does-full-site-editing-change-for-the-various-word-press-stakeholders\">What does Full Site Editing change for the various WordPress stakeholders </a></li><li><a href=\"https://gutenbergtimes.com/feed/#5-why\">Why will Full-Site Editing be in Core and not a plugin?</a></li><li><a href=\"https://gutenbergtimes.com/feed/#6-w\">What will be the role of existing page builders?</a></li><li><a href=\"https://gutenbergtimes.com/feed/#7-what-is-going-to-happen-with-the-rest-of-the-open-source-solutions-like-joomla-drupal\">What is going to happen with the rest of the open-source solutions like Joomla, Drupal?</a></li></ul></div>



<hr class=\"wp-block-separator is-style-wide\" />



<p><em>José Ramón Padron:</em> Hello, Lesley.</p>



<p><em>Lesley Molecke:</em> Hey, Moncho.</p>



<p><em>José Ramón Padron:</em> I&#8217;m laughing, because this is the moment my neighbor started to do this at home. I don&#8217;t know. I hope it doesn&#8217;t sound through the microphone, but I&#8217;m hearing a hammer quite hard on that building. I hope it&#8217;s not-</p>



<p><em>Lesley Molecke:</em> I can&#8217;t hear anything, but listen, I&#8217;m ready for this next session. I can&#8217;t believe that we&#8217;re already here. It&#8217;s already the final session of the day, and it&#8217;s going to be a good one.&nbsp;</p>



<h2 id=\"0-introduction-of-the-topic-and-the-panelists\">Introduction of the topic and the panelists</h2>



<p><em>José Ramón Padron:</em> Yes, it&#8217;s true. It&#8217;s going to be a good one, because we have a lot of good people talking about a quite good and hot topic inside the WordPress community. One of the things we are going to have, really near in, I don&#8217;t know, in 5.8, in the next version of WordPress, full site editing?</p>



<p><em>Lesley Molecke:</em> Yes. We would like to welcome our panelists. This is a panel presentation, so it should be a good conversation with a number of experts speaking. So they will join us here on stage in just a moment. Hello, hello. Hi, everybody.&nbsp;</p>



<p><em>Grzegorz Ziółkowski:</em> Hello.</p>



<p><em>Koen Van den Wijngaert:</em> Hello, there.&nbsp;</p>



<p><em>Lesley Molecke:</em> Will you please introduce yourselves?&nbsp;</p>



<p><em>Milana Cap:</em> Which order?</p>



<p><em>Lesley Molecke:</em> As you wish.&nbsp;</p>



<div class=\"wp-block-image is-style-rounded\"><img />Milana Cap</div>



<p><em>José Ramón Padron:</em> So let&#8217;s start with Milana, just for talking.</p>



<p><em>Milana Cap: </em>Because I&#8217;m the loudest. Well, you said expert. I&#8217;m here just for the cookies and to bribe contributors to come to documentation. Also, I&#8217;m here as documentation team co-rep. And I&#8217;m the docs focus lead for a new release, 5.8. I should be knowing what&#8217;s happening, hopefully soon. I&#8217;m Milana from Serbia.&nbsp;</p>



<p><em>Lesley Molecke:</em> How about you, Danielle?</p>



<p><em>José Ramón Padron:</em> Thank you so much.</p>



<p><em>Danielle Zarcaro:</em> Sure. I&#8217;m having an issue too. I don&#8217;t know whether he&#8217;s blowing leaves or mowing the lawn? I don&#8217;t know what&#8217;s happening.&nbsp;</p>



<div class=\"wp-block-image is-style-rounded\"><img />Danielle Zarcaro</div>



<p><em>Lesley Molecke:</em> We can&#8217;t hear it, it&#8217;s okay.</p>



<p><em>Danielle Zarcaro:</em> Good. I&#8217;m Danielle. I&#8217;m from the US. I am the head of paperback web development. We build custom WordPress websites and maintain them, and maintain existing websites, and all that that comes with. We just launched overnightwebsite.com. So that&#8217;s mostly what I deal with is the old and the new of WordPress. So it&#8217;s the whole range.</p>



<p><em>José Ramón Padron:</em> Thanks, Danielle. Let&#8217;s go with Koen.</p>



<div class=\"wp-block-image is-style-rounded\"><img /><em>Koen Van den Wijngaert</em></div>



<p><em>Koen Van den Wijngaert:</em> Hey, hi, there. Is this thing on? Hey, Good evening. I&#8217;m Koen. I&#8217;m a WordCamp and meetup organizer from Belgium. I run my own company called NEOK IT, where I provide software consultancy, partly around WordPress. I&#8217;ve been working with WordPress for a few years now. I like to learn things, as well as challenge myself while doing it.&nbsp;</p>



<p>So for a while now, I&#8217;ve been casually contributing to Gutenberg, as a way of giving back and mostly getting more accustomed to the ins and outs of the project. So that&#8217;s me.&nbsp;</p>



<div class=\"wp-block-image is-style-rounded\"><img src=\"https://i1.wp.com/pbs.twimg.com/profile_images/1047874472403845121/ckX4uiBZ_400x400.jpg?resize=203%2C203&ssl=1\" alt=\"Image\" width=\"203\" height=\"203\" /><em>Grzegorz Ziółkowsk</em></div>



<p><em>Grzegorz Ziółkowski:</em> It looks like it&#8217;s me now. So my name is Grzegorz Ziółkowski. I live in Oleśnica, Poland, and I work at Automatic, where I spend all time contributing to the WordPress core. My main focus is Gutenberg. I was helping to merge changes from the plugin, Gutenberg plugin to the WordPress core for the upcoming WordPress 5.8 release, which won&#8217;t contain all the necessary pieces of the full site editing. However, there is a lot of new goodies coming that will be ready to use on the site.&nbsp;</p>



<p><em>Lesley Molecke:</em> Excellent. So Moncho and I have come up with a bunch of questions for you. They go from really basic, and then they work up and get more and more exciting and interesting. So we&#8217;re going to start with the first one, which is actually, this is my question, because I don&#8217;t know the answer to it yet and hopefully you will educate me. What is full site editing and where did it come from?&nbsp;</p>



<h2 id=\"1-what-is-full-site-editing-and-where-did-it-come-from-nbsp\">What is full site editing and where did it come from?</h2>



<p><em>Koen Van den Wijngaert:</em> Maybe if I can start, maybe the best thing to say at first is that full site editing is not just a big monolithic heap of a big function. It&#8217;s better to think of it as a collection of a lot of features that come with Gutenberg, as part of the second phase of the Gutenberg roadmap. Maybe someone else can pitch in now, so I don&#8217;t do a monologue.</p>



<p><em>Grzegorz Ziółkowski:</em> If you don&#8217;t take a bigger picture, so full site editing is part of the Gutenberg project, there are four phases. And we are reaching this year, the end of phase two. The first one was introducing the building blocks for editing content. Now, we will be editing a full canvas of the sites. And the next two phases are collaborative editing. So to let people collaborate when they are changing websites or writing content. And the fourth one is multilingual support.</p>



<p><em>Koen Van den Wijngaert:</em> What everyone is waiting for, I believe. That&#8217;s going to be a big one.&nbsp;</p>



<h2 id=\"2-what-problem-does-full-site-editing-solve\">What problem does Full-Site Editing solve?</h2>



<p><em>José Ramón Padron:</em> Anything else? Anything else? Because one of the things inside of Lesley&#8217;s question is, what problem does it solve? Which is, I think, very interesting. What do you think?</p>



<p><em>Milana Cap:</em> I think that the problem it&#8217;s trying to solve is to give the user one unique workflow to edit everything. Because at this moment, you have post, you have page, and you go to block editor. Or if you are not brave enough, you&#8217;re still using classic editor and you edit your content there.&nbsp;</p>



<p>But then you want to change your logo, then you have to go to customizer. But then you have some theme options. And it depends on theme from theme, what will you edit and where? I believe the idea is to release end user from need to know everything about the theme, you just go there and you just edit.&nbsp;</p>



<p>And if you want to edit footer, and you&#8217;re on the post and you&#8217;re editing post, and then you realize the menu is not correct, you edit menu. You don&#8217;t need to know, because nobody cares is it customizer or whatever? People care to know where it is. And it&#8217;s a good thing that you can see how it looks on the front end, which I think was the initial idea for Gutenberg. But who knows? Maybe I&#8217;m wrong.</p>



<p>I think that&#8217;s a huge problem that will be fixed, and solved with full site editing. For us who are building websites, I know that for every website, I have to create a ton of tutorials and everything, to show clients how to use it. And this will solve all that. So we will be out of job.</p>



<p><em>Koen Van den Wijngaert:</em> I also like to think that it brings a lot of power and more freedom and flexibility to end users of a website. Because in the traditional way of doing things, there&#8217;s a few ways one can have a WordPress website. He can have an agency, have a website built for him. Or he could be using some sort of a theme builder, or he could have installed a theme from the theme directory or maybe it&#8217;s even a custom theme.</p>



<p>But now end users are able to have so much more power about editing templates, and editing all sorts of aspects of their website. I think that&#8217;s really exciting to look forward to.&nbsp;</p>



<p><em>Danielle Zarcaro:</em> I think it solves a couple of problems, to add to that. It takes away some of the ambiguity around how to edit each individual thing. So WordPress&#8217;s whole thing is to democratize publishing. There were areas of the websites that were just not available to edit to anyone who doesn&#8217;t know code.&nbsp;</p>



<p>So there&#8217;s the ease of use gap that came about, that you can&#8217;t edit the 404 page, you can&#8217;t edit the header or footer, unless an option is available. Is the theme using the site logo that you upload in WordPress, or you&#8217;re going to upload the image and then theme isn&#8217;t going to show it. It gets rid of those, however the theme developer decided to do it that day, and it streamlines a lot of that process to do some expected behavior to make it easier for anyone to hop into a site and edit it, and it democratizes publishing on a whole new level.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> That&#8217;s a nice way of saying it. Yes. Because right now there&#8217;s this huge fragmented world of all different ways of themes that came up with our own way of editing site features and headers and customizing things. But there&#8217;s no real standard way of doing that. So it just makes it harder to step out of that particular ecosystem, I think. I&#8217;m looking forward to the standardized way of doing theming in WordPress.</p>



<p><em>José Ramón Padron</em>: Grzegorz, I think you had something. Yes.</p>



<p><em>Grzegorz Ziółkowski:</em> I wanted to add some more to it. Because I think it&#8217;s important to note that it&#8217;s not only about unifying everything, but it&#8217;s also to giving the power to users to change those little bits that annoy them, like the color of the header, or the font size.&nbsp;</p>



<p>Before, you would have, or either learn CSS or learn HTML just to edit that. But now you will have tools that will allow that, and you won&#8217;t have to call your site administrator to do a simple change. So maybe you could tell that, remove the job from those people who maintain those sites, but on the other hand, they will have more time to work on expanding their offering and improving their own products or services, just to use the time.</p>



<p>So this is something that sounds scary, but on the other hand, it opens a lot of possibilities. Because the idea of blocks also gives you the power that you can create your own blocks that you can use in several websites, and give additional functionality out of the box for your customers.</p>



<h2 id=\"3-what-happens-to-websites-that-are-live-in-production-when-word-press-5-8-is-released\">What happens to websites that are live (in production) when WordPress 5.8 is released?</h2>



<p><em>José Ramón Padron:</em> So regarding that this is something new, something is going to happen from 5.8, as far as I know, what happens to the WordPress websites that are already live and in production? Must they be rebuilt in order to use full site editing? Or they&#8217;re going to work in the way they are?&nbsp;</p>



<p><em>Milana Cap:</em> They have to be rebuilt completely. It will crash. No, it won&#8217;t.</p>



<p><em>Koen Van den Wijngaert</em>: It will just crash when you update.&nbsp;</p>



<p><em>Milana Cap:</em> No, it won&#8217;t.</p>



<p><em>Lesley Molecke:</em>That&#8217;s big news.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> Oh, we were not supposed to say that, sorry.</p>



<p><em>Milana Cap:</em> No, they will not be crashed, they will not have to be rebuilt completely. As you all know, WordPress always build in mind with what is already out there, not to crash anything. And in 5.8, not everything will get in. So if I&#8217;m wrong, please correct me, but I think that in 5.8, you will have to install a Gutenberg plugin to actually use full site editing. So not everything will be there, but it will be foundation for the next releases when everything else will come in.&nbsp;</p>



<p>But still, we will have some nice things coming in and nothing will break. You can go part by part and rebuilding it and adapting for a complete editing experience.&nbsp;</p>



<p><em>José Ramón Padron:</em> Thanks, Milana. Anything to add ?</p>



<p><em>Koen Van den Wijngaert:</em> Maybe Grzegorz can do it.&nbsp;</p>



<p><em>Grzegorz Ziółkowski:</em> You can go.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> Okay, but you can just&#8230; Well, some of the full site editing features will be added to 5.8, I think, but Grzegorz will probably be able to say which one exactly. I&#8217;m hearing feedback.&nbsp;</p>



<p><em>José Ramón Padron:</em> An echo. There is an echo.</p>



<p><em>Koen Van den Wijngaert:</em> So it&#8217;s not some monolithic feature, like we said before, but it&#8217;s more like a collection of features and they won&#8217;t be turned off all at once by default, by just upgrading to WordPress 5.8. You do need to have a full site editing team to enable all features, but some of them will also be available for non-block based themes.&nbsp;</p>



<p>Things like the template editor blocks, the site logo, the tagline, the query blocks, posts, posts related blocks, like post title, post [inaudible 00:14:45], they will all be made available in the post editor. And as well as that, I think it was also possible to also not edit, but with add new templates to a normal theme and edit those in the template editor. It&#8217;s pretty awesome.&nbsp;</p>



<p><em>Grzegorz Ziółkowski:</em> So the first step is to allow people to change, use the block-based paradigm on a single page. So think about that, about previously you would have to create a PHP file to change a single page view. And now you will be able to do that to through UI, and that will create an override that you would be able to delete later. But as a user, so it&#8217;s more like empowering people who have access to the sites, rather that&#8217;s a feature for the team designer.</p>



<p>So that&#8217;s one thing. And everything like that is optional, so there will be a flag to disable that. So site owners or theme authors we will say that, &#8220;I don&#8217;t want that,&#8221; and they can remove that.&nbsp;</p>



<p>The one big change is that not necessarily related to full site editing, but is somehow in the same area is the widget editor, which will be&#8230; I don&#8217;t know what&#8217;s the final decision, but it will be depending on the feedback from the testing, either an opt-in or opt-out.</p>



<p>So the idea would be that you will be able to use the same blogs you use in your content to use also in site, when you would previously use widgets. So that&#8217;s a nice change. If you have your own custom blocks, you would be able to put there as well, which will open those new possibilities, and also somehow unify the interface.&nbsp;</p>



<p>But as you could hear, there is a lot of new blocks coming. But it&#8217;s just addition, it&#8217;s not something that you have to use. It&#8217;s just there if you want to try them out, that will be perfect time to do that after 5.8 is out. And there is a-</p>



<p><em>Koen Van den Wijngaert:</em> That will be released tomorrow, by the way. So if you want to test it, please do so. It&#8217;s by a lot of users that can test and provide feedback on the new update that we can improve upon those things, and decide what can be added and what should be skipped. So go install it tomorrow.</p>



<p><em>Lesley Molecke:</em>Yes, we should acknowledge that, that everyone here is actually working really hard right now to create the new release, while also attending WordCamp Europe and being here on this panel and contributing on track too, and y&#8217;all are everywhere. Thank you, thank you, thank you for your time.&nbsp;</p>



<h2 id=\"4-what-does-full-site-editing-change-for-the-various-word-press-stakeholders\">What does Full Site Editing change for the various WordPress stakeholders </h2>



<p>My next question has to do with stakeholders. So obviously, a big change like this to WordPress has multiple stakeholder groups. It has the end users, the users of WordPress websites down the road. It has the editors of WordPress websites. It has the companies who build themes and the companies who build plugins, and the people who contribute, all of these different groups.&nbsp;</p>



<p>I&#8217;m interested in talking about the theme creators who currently primarily rely on offering block patterns with their own header and footer and sidebar management. So how does that work with full site editing?</p>



<p><em>Danielle Zarcaro:</em> Well, it works the same way. You can offer whatever you want. I think it&#8217;s a misconception that by giving the users the ability to do what they want means that they&#8217;ll be able to do anything they want. If you are someone like me who&#8217;s creating custom sites, you can actually more easy put options and make it so that you don&#8217;t have to install a whole extra plugin to add a couple of extra options. You reserve that for the bigger projects that you&#8217;re doing.</p>



<p>And it&#8217;s up to the theme creators, if they&#8217;re creating a theme on a wider scale, instead of just an individual client, that&#8217;s up to them to decide how they want it to work. They just opt into stuff, they add stuff, they add their custom options, but it&#8217;s all working within the same ecosystem, and we&#8217;re all speaking the same language now instead.</p>



<p>So if you don&#8217;t want to make it so that your header and your footer and your sidebars are manageable in the block editor or in full site editing, then I guess you don&#8217;t have to. You can hard code whatever you want, you can do that now, you don&#8217;t have to make any options available.&nbsp;</p>



<p>But then at some point, you&#8217;re going to start to fall behind, in terms of what you&#8217;re able to do. So it&#8217;s going to work the same way, just with more possibilities. That&#8217;s how I go about looking at it.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> You&#8217;ll be able to turn off or on, or even tweak some of the configuration options just by providing a single JSON file for those things. But also, I like to think that with full site editing, a theme developer or theme designer can benefit from a more solid foundation that is standardized and optimized for things like accessibility, usability and performance.&nbsp;</p>



<p>That way more of their time and energy can be spent into building things that actually add value to their customers, all the while benefiting from the existing full site editing features and even tweaking them to their liking. So that&#8217;s a big plus, I think. So they don&#8217;t have to go and reinvent the wheel every time they build a new website.</p>



<p><em>José Ramón Padron:</em> There is something related to the last major change we saw in WordPress, when Gutenberg appears, when Gutenberg finally was born in 5.0. And now you can see that there is a plugin that is the old editor. And at this moment, we this kind of legacy, we can call it legacy, but it&#8217;s still available there.&nbsp;</p>



<h2 id=\"5-why\">Why will Full-Site Editing be in Core and not a plugin?</h2>



<p>My question is about why there are things that can sit in the core, and a different one can be set as a plugin? For example, why put the full site editing in the core when it is something that the majority of users at this moment don&#8217;t know? And we hope all of them are going to use it, but as everything that comes new in WordPress, there is always a time for getting used to it.&nbsp;</p>



<p>So what do you think is the main reason full site editing is in the core and not, for example, in a plugin and people can choose if they want it or not?</p>



<p><em>Milana Cap:</em> I think that now that we have Gutenberg in core, and full site editing is obviously expansion of what we were using in core by now, I think it would be silly not to have it in core and have it as a plugin, when you can use&#8230; This is just a foundation to put all the blocks that you already have. So it&#8217;s not like the structure that you still don&#8217;t have, you have. There is Gutenberg and now you will just expand it to the whole website.</p>



<p>And there is benefit in having everything standardized, especially for people who are using themes from our repository. So when you switch theme, you have all those available, things to edit, you know where it is, and you have all the blocks available.</p>



<p><em>José Ramón Padron:</em> Makes sense.</p>



<p><em>Milana Cap:</em> So that&#8217;s a huge benefit. I love that theme in wordpress.org is insisting on idea that people will change themes, and they cannot lose anything. I love that idea. I think this will really help having that.&nbsp;</p>



<p>So when you have custom themes, and people have different ways of editing right now the header, the footer, or they don&#8217;t have it at all, so you&#8217;re afraid to change the theme. But with full site editing, you will have all that available.</p>



<p>Now, as far as not knowing how to use it goes, we didn&#8217;t know many things, how to use. And the thing that we really need right now is, here comes my pitch, documentation. So we really, really need to document everything good, because when you don&#8217;t have documentation, people don&#8217;t know how to use it and then they don&#8217;t interact with it enough. They don&#8217;t find bugs, they don&#8217;t contribute. They don&#8217;t think ideas how to expand it, and you don&#8217;t have contributors, and there is no cycle for open source. So first, we need to do a good documentation.&nbsp;</p>



<p>We did fail a bit with Gutenberg getting in, and we can still feel it. We can still feel developers who are frustrated and don&#8217;t know how to work with it and how to build on that. I&#8217;m asking everyone to come and help. While doing documentation, you will actually learn how to do it.&nbsp;</p>



<p>I&#8217;m not afraid of new things. I don&#8217;t think anyone should be afraid, especially because this is not a really new thing, like Gutenberg was a new thing. We didn&#8217;t know what it was. Now we know, full site editing is what we already know, it&#8217;s new, but expanded, so it&#8217;s easier to learn. And if we do enough work, and we are doing&#8230; people make WordPress themes are doing great job.</p>



<p>Just mentioning few, Anne is doing the testing, great job, and Carolina even have a website for full site editing where you can read everything. So it&#8217;s doing better, and we can learn and there are resources, so there&#8217;s no need to be afraid of it.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> And if I&#8217;m not mistaken, there&#8217;s even seven milestones added to the full site editing milestones. It&#8217;s called gradual adoption. So that it focuses solely on making sure that full site editing features are being adopted better and more gradual. And that work is being put into actually making sure that the documentation is on par, and that the dev notes are up to date, and all of that kind of thing. So that&#8217;s also important. That&#8217;s also part of the work that&#8217;s now being done after the feature freeze for the 5.8 features.&nbsp;</p>



<p><em>Danielle Zarcaro:</em> I think from my perspective, as someone who&#8217;s working with it and working with people, no one&#8217;s going to use it if you make it optional. People are going to do what they&#8217;re going to do, if you let them.&nbsp;</p>



<p>I think WordPress itself has never, it&#8217;s been very transparent about where it&#8217;s going. We&#8217;ve all been able to use Gutenberg for years now. We&#8217;ve been able to install the plugin, and then we&#8217;ve been able to use the block editor in core for years now. So it&#8217;s like we&#8217;ve had this getting used to period.</p>



<p>So we&#8217;re just going in the direction that we said we&#8217;d go in, and people can still find ways to go backwards. They can still install the classic plugin for sites that need it, they can install the classic plugin for certain things. They cannot enable the block editor for custom post types. There&#8217;s all kinds of stuff that you can do to counteract some of that.&nbsp;</p>



<p>But like I referenced before, and I&#8217;ve talked a lot about this in the past, at some point, you have to embrace the tool that you&#8217;re using. So you&#8217;re either going to embrace the fact that we&#8217;re all working towards the same goal, or you&#8217;re working against it and basically forking your own version and working on your own, which is fine. But then you can&#8217;t offer the latest stuff.&nbsp;</p>



<p>I think it&#8217;s up to you as a developer to, on some level, work with things, and meet WordPress where it is. You have to give up. WordPress is open source. You have to allow yourself to go with the tide a little bit.&nbsp;</p>



<p>And when you have new users who come into WordPress, who are installing things, they&#8217;re not going to know that there was an old WordPress. They&#8217;re not going to know that, oh, I have to install this other plugin to enable all of these awesome features. You have to think forward. So you have to allow these new users to start installing it, and use all the cool latest stuff.&nbsp;</p>



<p>If someone wants to go backwards for a bit, then they can put the work in to do that.&nbsp;</p>



<p><em>Grzegorz Ziółkowski: </em>It&#8217;s also worth mentioning that the full site editing, it&#8217;s soon to be included in the core, it&#8217;s always something that we wanted to have. It&#8217;s not something that came, because there was the 5.0 release and the block editor. It&#8217;s the other way around.</p>



<p>So we took the smallest step possible to enable people to start using this block paradigm, start learning UI. We got a lot of feedback. And if you look at the iterations that worked, how the editor looked two and a half years ago and how it looks now, it&#8217;s a completely different product.</p>



<p>And also the way, how we people started thinking about building content with blocks is different. It&#8217;s not longer, building small custom blocks, but rather combining a lot of existing blocks into block patterns, into having UIs, having ways to change a big portion of the page with solutions. Like now it&#8217;s coming to the query block that allows you to switch the list of blog posts will be displayed on the page.</p>



<p>So we are constantly trying to make it easier for users to provide the infrastructure, also for plugin authors, for theme authors, so they can build upon that, and have the unified experience. So people, once they learn how to write a post, they will know how to change the template of the page, because it&#8217;s exactly the same paradigm.&nbsp;</p>



<p>It&#8217;s even in the same UI interface. You just go from one page to another, without the page reload. Everything can happen, you can go back, you can revisit how it looks when you compose everything together. It&#8217;s no longer you need to go to the preview of the page and see another tab to see, oh, it looks good, but now something broke outside of the post content. I need to go find customizers and go to this template, or call the theme author on the support and change that for me.&nbsp;</p>



<p>So this is a huge project, and has so many layers on top of that. We want to bring as much as possible, I would say, what makes sense to most of the users, but not all of them. Because there is always room for extenders to build their own solutions on top of that, and give this unique perspective and look and feel for the customers.</p>



<h2 id=\"6-w\">What will be the role of existing page builders?</h2>



<p><em>Lesley Molecke:</em> I feel like we&#8217;re tiptoeing closer and closer to this question. I&#8217;m just going to ask it, just get it out there on the table. What do you all feel is the big role for the online page builders, the Divi, the Elementor, these big guys, taking into account that we&#8217;re moving into full site editing, block patterns, all of these things that are being built into WordPress core? What is the role of these page builders that so many of us use?&nbsp;</p>



<p><em>Danielle Zarcaro:</em> I think that&#8217;s up to them. I think ultimately, they were there to push the envelope. They were there to bring us to where we currently are. I think without them, we might not have had this extra push. Maybe it would have taken a few more years to put all this into core. These builders saw this hole and filled it.&nbsp;</p>



<p>And ultimately, they&#8217;re going to have a different UI anyway. So they&#8217;re going to do have their fan base, they&#8217;re going to have their whatever preference to editing things, maybe certain things are dragging and dropping. Whatever they make available, they&#8217;re going to extend WordPress. So that&#8217;s up to them to decide how they&#8217;re going to go about it.&nbsp;</p>



<p>So they&#8217;re all already currently working with the block editor, all the major ones anyway are. If they&#8217;re concerned at all about future proofing themselves, they&#8217;ve already looked into how to integrate themselves with the block editor. I think it&#8217;s only going to enhance everything to see how they go about integrating themselves into the new ecosystem.&nbsp;</p>



<p>I really love, as a developer, I love the way Oxygen goes about it, where you can build stuff, and then go and edit it in Gutenberg. So that&#8217;s a really cool take on it. And so it&#8217;s just a new way to innovate, and they&#8217;re going to have their place.</p>



<p>I think it&#8217;s cool that we now have these established things. We have these people to look to, to see where are the new holes in WordPress? Where can we go from here? And they&#8217;re going to continue to just push the envelope. I love the diversity that&#8217;s out there.&nbsp;</p>



<p>When you talk about builders, there&#8217;s at least four that come to mind and that&#8217;s awesome. And I hope that it stays that way and grows. And that&#8217;s only going to help us. And so hopefully, it&#8217;ll take away some of that, Divi does this way and Elementor does this way. So some things are going to hopefully become uniform, and then they&#8217;ll branch out in other ways.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> Exactly. Because now, there&#8217;s a few big ones indeed, and they all seem to have their own ecosystem surrounding them, which is okay, because as you said, they all implement and provide their own stream of users to the WordPress platform. So it&#8217;s definitely interesting to look at, and observe how they will interact with WordPress and Gutenberg.</p>



<p>I know most of them already have some sort of a way to either include a new template view or something as a block, or even toggle between Gutenberg and their own editor. But the thing I&#8217;m actually quite looking forward to is whether or not they will start using the new default way of doing things. So that they can actually merit from how it is now going to be supposed to be done, and add on top of that their own set of features and new value-adding stuff.&nbsp;</p>



<p>Like the cadence theme, for example, is doing. In my eyes, it&#8217;s quite a nice way of implementing Gutenberg the right way. I&#8217;m very interested to see how they will be going to implement full site editing things in the near future, because now it&#8217;s all in the customizer, of course. So, interesting.&nbsp;</p>



<h2 id=\"7-what-is-going-to-happen-with-the-rest-of-the-open-source-solutions-like-joomla-drupal\">What is going to happen with the rest of the open-source solutions like Joomla, Drupal?</h2>



<p><em>José Ramón Padron:</em> We were talking about how full site editing can affect the own WordPress ecosystem, talking about for example, what happens with the builders, builders like Divi, Elementor, et cetera. But what do you think, taking account you are developers, designers, you are on the technical side, contributors, what do you think is going to happen with the rest of the open source solutions like Joomla, Drupal? How do you think it&#8217;s going to affect? So it&#8217;s going to make WordPress better than the rest, it&#8217;s going to be a real advantage in front of the rest, like Wix, like the other ones, not only in the open source reality, but outside WordPress? What do you think is going to happen with full site editing?</p>



<p><em>Milana Cap: </em>They will all take Gutenberg. Drupal already do it.</p>



<p><em>Koen Van den Wijngaert:</em> But Drupal also has a [crosstalk 00:37:15]. But there&#8217;s not like this CMS is better than the other one. They all serve different purposes. And it&#8217;s like using the right tool for the right job. And having more competition in the game is pretty good actually.</p>



<p>I think the biggest reason that we, as WordPress, have the biggest market share to date in the CMS market is because of the low threshold to start building websites. And that&#8217;s partly thanks to all of those theme builders. I think it&#8217;s important to reach out and make sure that we all keep using WordPress and not just fork off their own version of WordPress, because it&#8217;s open source, they can do that.&nbsp;</p>



<p>So if we all collaborate, we can build pretty nice things, I think.&nbsp;</p>



<p><em>Milana Cap:</em> I think we already saw this many times in history, but let&#8217;s just take a look at Internet Explorer 6. It was so bad that we got this good Chrome and Firefox. And it was so difficult to create posts for some people in WordPress, that we got page builders. So this is happening. There is always this kind of competition between WordPress and Joomla and Drupal.&nbsp;</p>



<p>But the truth is, they all have their share. Ours is a little bigger than theirs, but they will continue to exist, and I hope they will push, they will invent something new. And then we will be jealous, and we will do something better, because that&#8217;s how it works. Human mind compares. So that&#8217;s what we do.</p>



<p>I&#8217;m proud that 12 years ago I have selected WordPress and now it&#8217;s 40%. I think I&#8217;m smart, because I did that. But I don&#8217;t like just one way of doing things. I like things messing up. I like people inventing new things. That makes us all better and everything makes better.&nbsp;</p>



<p>I&#8217;m really looking forward to see what other CMSs will do, but also what will page builders do. I have never used page builder, as someone who builds website and some of you uses website. I cannot say anything.&nbsp;</p>



<p>But I&#8217;m seeing in our WordPress Serbia Facebook group, I&#8217;m seeing people asking questions about it. I know what they are doing and how, and I really hope to see they invent something insane, so we will have to push Gutenberg again and just pushing forward.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> Even better.</p>



<p><em>Danielle Zarcaro:</em> I think it&#8217;s going to blur the line a little bit. Because I just recently had to go into a Wix site and it is no longer Wix or Weebly. It is Wix or Webflow. Webflow popped up as an in between to Weebly and the GoDaddy builder and WordPress.</p>



<p>I think it blurs the line a little bit, where you can now visually edit things and you can now edit those parts, like I said, the 404. All these other things, you can just do now. And so I think it blurs the line and WordPress can now fit into more categories as well.</p>



<p>So maybe it&#8217;s not a Squarespace, which is a template machine that you stick a bunch of stuff in and it&#8217;s easy, but it does open it up to a whole nother market. Instead of just, oh, you got to have somebody on your side, it now opens the door for more people. And then now they&#8217;re ready to grow, and now they come to you and are familiar with WordPress.&nbsp;</p>



<p>So there&#8217;s the three or four other markets that&#8217;ll pop up as well. So it blurs a little bit and makes it a little more accessible.&nbsp;</p>



<p><em>Grzegorz Ziółkowski:</em> There&#8217;s also one thing that I&#8217;m looking forward to, is the blog patterns directory, which should enable a quicker creation of websites, instead of going, changing everything yourself. If you don&#8217;t have, like me, skills for designing, you just pick something that someone crafted very carefully. And maybe pay some fee for that and have unique experience for all the use cases you have.</p>



<p>It&#8217;s no longer you need to use one theme, and hope that it has all the solutions you need. Instead, you can combine from different sources and build the best experience you need. So that&#8217;s one thing.</p>



<p>One thing that I&#8217;m looking forward to is how I&#8217;m seeing the growth of headless. It&#8217;s getting a lot of attention at the conferences in the WordPress community. And that interaction with full site editing, I&#8217;m looking forward how that will evolve. Because at the moment, if you want to use headless solutions you need to build from scratch the front end side.</p>



<p>However, if you combine that with what Gutenberg can produce and reach that, that will open a new set of possibilities. And that will bring big companies looking at WordPress, because now they will be able to build completely custom solutions, and also use whatever WordPress provides in its core, rather treating it as a source of the content only.</p>



<p><em>José Ramón Padron:</em> I&#8217;m glad to read that question.&nbsp;</p>



<p><em>Lesley Molecke:</em> Koen, you have one final thing to add, before we sign off?</p>



<p><em>Koen Van den Wijngaert:</em> I was going to say that one obstacle might be that a lot of back end developers have mostly skills in writing PHP and stuff. But most of the new features, you really do benefit more if you have a JavaScript back end. I think we should also focus on helping those developers transition into more and more adopting JavaScript and active development to develop even better new solutions.</p>



<p><em>Milana Cap: </em>And documentation.&nbsp;</p>



<p><em>Koen Van den Wijngaert:</em> Most importantly, of course.&nbsp;</p>



<p><em>Lesley Molecke: </em>Yes. Well, thank you, thank you, thank you all for this really interesting conversation. I now know more about full site editing than I do before, thanks to you. But also, I think our audience does as well, which is fantastic.</p>



<p>And again, thank you for taking the time to join us, even though you&#8217;re also so, so busy working on the new release, and working on this massive change to WordPress. We&#8217;re really grateful to you and your time. Enjoy the rest of the conference. We will see you later and thank you.&nbsp;</p>



<p>Will you be heading over to the Q&amp;A room to talk with the audience? Does that sound like a familiar thing to you? All right.&nbsp;</p>



<p><em>Milana Cap:</em> We can, if there are questions.</p>



<p><em>José Ramón Padron:</em> There will be.</p>



<p><em>Lesley Molecke:</em> People can also make meetings with you and see you in other rooms and things.</p>



<p><em>José Ramón Padron:</em> There will be more content related full site editing during WordCamp Europe, in each day, I think, or also in the number two track. So this is not the last time we are going to talk about full site editing.&nbsp;</p>



<p>Another thing is to say thank you for accepting our invitation, more or less in the last minute. Thank you. Thank you so much.</p>



<p><em>Lesley Molecke:</em>Thank you all.</p>



<p><em>Milana Cap:</em> Thank you, bye.&nbsp;</p>



<p><em>Grzegorz Ziółkowski:</em> Thank you.</p>



<p><em>Koen Van den Wijngaert:</em> Thank you. Very nice to being here.&nbsp;</p>



<p><em>José Ramón Padron:</em> See you around. Ta-ta.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Jun 2021 18:31:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Birgit Pauli-Haack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Gutenberg 10.8 Adds New Typography Controls and Block Previews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118211\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/gutenberg-10-8-adds-new-typography-controls-and-block-previews?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-10-8-adds-new-typography-controls-and-block-previews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6354:\"<p class=\"has-drop-cap\">On Wednesday, <a href=\"https://make.wordpress.org/core/2021/06/10/whats-new-in-gutenberg-10-8-9-june/\">Gutenberg 10.8</a> landed in the WordPress plugin directory. The release includes new typography options for controlling the Heading block&rsquo;s font-weight and the List block&rsquo;s font family. The Audio and File blocks now show preview content in the inserter.</p>



<p><a href=\"https://wptavern.com/gutenberg-10-7-integrates-with-the-pattern-directory-introduces-new-block-design-controls\">Gutenberg 10.7</a> felt like it introduced flashier features than 10.8. But, this was still a solid release. Sometimes the things that you do not see are just as important as those that you do. Full Site Editing (FSE) components continue to move along at a swift pace. Most changes were bug fixes rather than enhancements.</p>



<p>One of the primary theme-related FSE upgrades allows developers to set the <a href=\"https://github.com/WordPress/gutenberg/pull/31878\">padding for nav menu links</a> via <code>theme.json</code>. This may be a small win, but it is unlikely to address the numerous issues with styling navigation items and nested lists. The change also does not affect the Page List block links, which can be set as a nav menu item. The Navigation block will be one of the toughest nuts to crack before site editing is a possibility. Enhancements like this help, but it is a long and winding road to a solution that satisfies both theme authors and users.</p>



<p>Users should see the <a href=\"https://github.com/WordPress/gutenberg/pull/32037\">post title in template-editing mode</a>. The template details modal also includes <a href=\"https://github.com/WordPress/gutenberg/pull/32042\">more detailed information</a>, such as how to best name custom templates.</p>



<h2>New Typography Options</h2>



<p class=\"has-drop-cap\">Gutenberg 10.8 enables the <a href=\"https://github.com/WordPress/gutenberg/pull/27639\">font-weight control for Heading blocks</a>. This allows theme authors to define the default weight via their <code>theme.json</code> files, and users can override this via the sidebar panel in the editor.</p>



<img />Testing font weights for the Heading block.



<p>The control displays all nine possible weights:</p>



<ul><li>Thin</li><li>Extra Light</li><li>Light</li><li>Regular</li><li>Medium</li><li>Semi Bold</li><li>Bold</li><li>Extra Bold</li><li>Black</li></ul>



<p>While each weight is selectable, it does not mean all fonts support a specific weight. For example, users will see no difference between Extra Bold and Black with the Twenty Twenty-One theme.</p>



<p>In the long term, this should be coupled with the font family control. This would allow theme authors to define which weights are supported by a specific family, making those the only options for users.</p>



<p>The List block is jumping ahead of others with its <a href=\"https://github.com/WordPress/gutenberg/pull/27510\">support of the font family option</a>. Generally, we would see the Heading or Paragraph blocks gain such features first.</p>



<img />Setting a custom font family for a List block.



<p>The Site Title, Site Tagline, and Post Title blocks all currently support the font family control. It is a welcome addition to see expanded typography options, but I look forward to the day they are offered across every block.</p>



<p>Theme authors can also define <a href=\"https://github.com/WordPress/gutenberg/pull/31118\">custom letter spacing</a> for the Site Title and Site Tagline blocks. However, the feature does not currently appear in the block options sidebar, which would allow users to customize it. There is an <a href=\"https://github.com/WordPress/gutenberg/issues/32577\">open ticket</a> to address this missing piece of the UI.</p>



<h2>Audio and File Block Previews</h2>



<img />Audio block preview in the inserter.



<p class=\"has-drop-cap\">The development team added new previews for the <a href=\"https://github.com/WordPress/gutenberg/pull/32333\">Audio</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/32350\">File</a> blocks in the inserter. This is a nice-to-have enhancement, adding long-missing previews of some of the remaining core blocks, but it is also a bug fix.</p>



<p>In previous versions of the block editor, users who attempted to upload media via the Audio or File blocks would get a <a href=\"https://github.com/WordPress/gutenberg/issues/8119#issuecomment-850787884\">duplicate upload</a>. This only happened in situations where their theme or a plugin registered a custom block style. Adding a preview apparently fixed this odd bug.</p>



<p>This change also nearly gives us a complete set of previews for the pre-WordPress 5.8 blocks. Classic, Spacer, Shortcode, and Legacy Widget do not have them, but they are unique cases. The upcoming theme-related blocks also lack previews.</p>



<h2>&ldquo;Archives&rdquo; Label Now Shown for Archives Dropdown</h2>



<img />Duplicate archives heading and label.



<p class=\"has-drop-cap\">When using the Archives block as a dropdown, it now <a href=\"https://github.com/WordPress/gutenberg/pull/30527\">outputs a label titled &ldquo;Archives.&rdquo;</a> While it is a seemingly trivial change, it could impact how themes typically present this block.</p>



<p>This <em>enhancement</em> changes some existing expectations. The primary use case throughout WordPress&rsquo;s history has been to show the Archives dropdown in a widget. In that case, there is almost always a widget title with the &ldquo;Archives&rdquo; text preceding it. I expect most other use cases would follow a similar pattern. This essentially creates duplicate text.</p>



<p>Themes Team representative Carolina Nymark had an <a href=\"https://github.com/WordPress/gutenberg/pull/30527#issuecomment-817026048\">alternate suggestion</a>:</p>



<blockquote class=\"wp-block-quote\"><p>What if the label was visible by default, but there was an option for hiding it? Similar to the search block, except there would be an actual label hidden with a screen reader text CSS class when the option is toggled.</p></blockquote>



<p>That would have been my suggestion too if I had seen the ticket earlier. For now, theme authors who need to hide it should target the <code>.wp-block-archives-dropdown &gt; label</code> class in their CSS.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 12 Jun 2021 00:50:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: WordCamp Europe 2021 Gutenberg Demo: “The Block Editor Gets Ready to Become a Site Builder”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118187\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:241:\"https://wptavern.com/wordcamp-europe-2021-gutenberg-demo-the-block-editor-gets-ready-to-become-a-site-builder?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-europe-2021-gutenberg-demo-the-block-editor-gets-ready-to-become-a-site-builder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3213:\"<p>Matt Mullenweg and Mat&iacute;as Ventura joined <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a> to chat about what&rsquo;s happening with the Gutenberg project and celebrate the progress contributors have made over the past four years.</p>



<p>&ldquo;For me, 2020 was the year that really felt like people started to see the vision of Gutenberg from four or five years ago, when it was very abstract and they saw it as kind of like the old WYSIWYG editor with some extra lines on it or something,&rdquo; Mullenweg said. &ldquo;The first 17 or 18 years of WordPress democratized people putting text into a box. Now we&rsquo;re democratizing design, allowing people to control the boxes.&rdquo;</p>



<p>Ventura commented on how transformative patterns have been for making page design approachable for users.</p>



<p>&ldquo;Perhaps it was a smaller part of the roadmap initially but it&rsquo;s becoming a centerpiece &ndash; especially because it allows&hellip;world class designers to provide a starting point for users and users get to learn design as they are interacting with themes,&rdquo; Ventura said. He began his WordPress developer journey by &ldquo;tinkering with themes,&rdquo; as many others did, and believes that blocks can unlock a similar experimental learning experience.</p>



<p>&ldquo;I think we are getting into a chapter where people will be able to tinker with things that were sort of hidden for you in WordPress &ndash; more advanced things like queries and loops, that we can now expose through blocks,&rdquo; Ventura said. &ldquo;They can be stepping stones for people to learn how to work with WordPress.&rdquo;</p>



<p>Mullenweg commented on how things that previously would have required a fairly experienced WordPress developer to do, like creating a home page with a column that shows five recent posts from a particular category, and another column that shows featured posts in a different category, you can now do with just a few clicks.</p>



<p>&ldquo;It&rsquo;s no code &ndash; it&rsquo;s like expanding the layers of accessibility of what people are able to do with WordPress,&rdquo; Mullenweg said. &ldquo;That, to me, is very core to our mission.&rdquo;</p>



<p>Mullenweg and Ventura debuted a new &ldquo;Gutenberg highlight&rdquo; video that covers current and new features coming to the block editor, as it &ldquo;gets ready to become a site builder.&rdquo; These kinds of marketing videos are so valuable because users don&rsquo;t always know what is possible, even if the tools are approachable for anyone to use. </p>



<p>The video demonstrates new design features for different blocks, including the transform live previews, dragging media into container blocks, inline cropping without leaving the editor canvas, the template editor, duotone image filters, more customization options for navigation, improvements to the list view browser, and the new global styles design that is coming soon.</p>



<p>Check out the video below and you can also <a href=\"https://youtu.be/o-IvKy3322k?t=10673\">watch Mullenweg and Ventura&rsquo;s conversation</a> that was recorded during the event.</p>



<div class=\"wp-block-embed__wrapper\">

</div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Jun 2021 20:11:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: Gutenberg Highlights\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10779\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/gutenberg-highlights/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:879:\"<p>During <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a> this past Wednesday Matt and I gathered to discuss the latest developments of Gutenberg and to share a video with some of the current and upcoming highlights. The video is wonderfully narrated by <a href=\"https://profiles.wordpress.org/beafialho/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>beafialho</a> and it was a great opportunity to celebrate all the incredible work that contributors are doing around the globe to improve the editing and customization experience of WordPress. For those that weren&#8217;t able to attend live it&#8217;s now available for watching online.</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>Matt also opened a thread for questions <a href=\"https://ma.tt/2021/06/wceu-open-thread/\">on his blog</a>, so be sure to chime in there if you have any!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Jun 2021 11:03:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matias Ventura\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: A Progress Bar Block Plugin Done Right by the Tiles Team\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118206\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:177:\"https://wptavern.com/a-progress-bar-block-plugin-done-right-by-the-tiles-team?utm_source=rss&utm_medium=rss&utm_campaign=a-progress-bar-block-plugin-done-right-by-the-tiles-team\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4425:\"<p class=\"has-drop-cap\">I have been on the hunt for a decent progress bar solution for a while now. Most of them are bundled in large block libraries, requiring me to install another 20 or 30 blocks in which I have no need. Others seem to miss the mark entirely with odd configurations and block options. Some of the remaining plugins still use shortcodes and widgets, but it is 2021. I am looking for a block.</p>



<p>A couple of days ago, the <a href=\"https://wordpress.org/plugins/tiles-progress-block/\">Tiles Progress Block</a> landed in the directory. It seems to be a smaller piece of a larger project named Tiles. I have been keeping an eye on the team&rsquo;s work since its initial <a href=\"https://wordpress.org/plugins/tiles/\">design and patterns framework plugin</a> launched last week. That project is still in beta, and only time will tell if it becomes a competitive project in the block space.</p>



<p>However, the team&rsquo;s new progress bar block was just what I was looking for. Other than one bug, which I <a href=\"https://wordpress.org/support/topic/background-style-object-object/\">reported to the developer</a>, I found no serious issues.</p>



<p>The plugin does what it says on the tin. It registers a Progress Bar block:</p>



<img />Small and Large progress bars with default colors.



<p>Out of the box, it includes Small and Large styles, allowing the user to adjust the size of the bar.</p>



<p>Its strength is that &mdash; I cannot stress this enough &mdash; the block&rsquo;s content is editable within the editor canvas area. This includes the label and percentage. This is a refreshing change from the many others that require users to jump back into the block options sidebar to change simple text. Because the block uses Rich Text fields for its label and percentage, end-users can use inline formatting tools like bold, italic, and more.</p>



<p>The block also uses the standard typography and color palette  controls from core WordPress. This provides access to the theme&rsquo;s font sizes and colors.</p>



<img />Adding custom labels, percentages, and colors.



<p>Plus, users can choose wide and full-width layouts, an often overlooked feature in block plugins.</p>



<p>Overall, I am digging this block plugin. If I had one feature request, it would be to add a border-radius option. By default, the progress bar is rounded, but some users might prefer squared corners.</p>



<h2>Extending the Block</h2>



<p class=\"has-drop-cap\">In theme previews, I almost always see progress bars showcased alongside how much PHP, HTML, and JavaScript the demo&rsquo;s <em>faux</em> developer has learned. It is rarely a real-world representation of progress bars. <em>How do you quantify how much of a coding language you have mastered?</em> I have been doing this for nearly two decades and cannot answer that.</p>



<p>Progress bars should be of measurable things. For example, steps someone has taken in an online learning course, percentage of total donations received, and any number of things that can be counted are far more realistic.</p>



<p>My favorite use of progress bars also happens to be on my <a href=\"https://www.brandonsanderson.com/\">favorite novelist&rsquo;s website</a>. I like to keep an eye on Brandon Sanderson&rsquo;s work, looking forward to getting my next literary fix (yes, I am a fanboy).</p>



<img />Brandon Sanderson&rsquo;s writing progress.



<p>Currently, Tiles Progress Block does not handle that exact layout. However, because it is built on the block system and does not do anything out of the ordinary, theme authors can change that with custom styles.</p>



<p>And that is just what I did. My <em>Sanderson-esque</em> book progress bars (rough, unpolished <a href=\"https://gist.github.com/justintadlock/479210f63ce97f980efd37d6392cf2e9\">code available as a Gist</a>):</p>



<img />Progress bars with custom block style.



<p>The thing I love about the block system is that themers can extend blocks in this way. There is no needless checking for active plugins, loading additional per-plugin stylesheets, or figuring out each plugin&rsquo;s unique system.</p>



<p>If a block is coded to the current standards, theme authors merely need to hook in with their own styles. Users can then select those styles via the editor and even make them the default.</p>



<p>I want to see more of this from the block plugin ecosystem.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 11 Jun 2021 02:48:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: WordPress 5.8 Introduces Support for WebP Images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118088\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:161:\"https://wptavern.com/wordpress-5-8-introduces-support-for-webp-images?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-8-introduces-support-for-webp-images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3789:\"<p><a href=\"https://developers.google.com/speed/webp\">WebP</a> support is coming to WordPress 5.8. This modern image file format was created by Google in September 2010, and is now supported by <a href=\"https://caniuse.com/webp\">95%</a> of the web browsers in use worldwide. It has distinct advantages over more commonly used formats, providing both lossless and lossy&nbsp;compression that is <a href=\"https://developers.google.com/speed/webp/docs/webp_lossless_alpha_study#results\">26% smaller</a>&nbsp;in size compared to PNGs and <a href=\"https://developers.google.com/speed/webp/docs/webp_study\">25-34% smaller</a>&nbsp;than comparable JPEG images.</p>



<p>WebP is currently used by <a href=\"https://w3techs.com/technologies/details/im-webp\">1.6%</a> of all the top 10 million websites, according to W3Techs, and usage has increased over the past five years.</p>



<div class=\"wp-block-image\"><img /><a href=\"https://w3techs.com/technologies/history_overview/image_format/all/y\">W3Techs</a>: Historical yearly trends in the usage statistics of image file formats for websites</div>



<p>Adding WebP support to core won&rsquo;t make all WordPress sites instantly faster, but it will give every site owner the opportunity to reduce bandwidth by uploading WebP images. In the <a href=\"https://make.wordpress.org/core/2021/06/07/wordpress-5-8-adds-webp-support/\">dev note</a>, Adam Silverstein suggested converting images to WebP using command line&nbsp;<a href=\"https://developers.google.com/speed/webp/docs/precompiled\">conversion tools</a>&nbsp;or web based tools like&nbsp;<a href=\"https://squoosh.app/\">Squoosh</a>, but there are also many plugins that can perform conversion on upload. </p>



<p><a href=\"https://wordpress.org/plugins/webp-express/\">WebP Express</a> uses the&nbsp;<a href=\"https://github.com/rosell-dk/webp-convert\">WebP Convert</a>&nbsp;library to convert the images and then serves them to supporting browsers. It is used on more than 100,000 WordPress sites. <a href=\"https://wordpress.org/plugins/imagify/\">Imagify</a> is one of the most popular plugins in use with more than 500,000 active installs. It has a Bulk Optimizer tool that&nbsp;can convert previously uploaded images with one click. The <a href=\"https://wordpress.org/plugins/ewww-image-optimizer/\">EWWW Image Optimizer</a> plugin, used on more than 800,000 websites, also has support for automatically converting images to the WebP format.</p>



<p>By default, WordPress will create the sub-sized images as the same image format as the uploaded file. More adventurous users can experiment with Silverstein&rsquo;s <a href=\"https://github.com/adamsilverstein/wordpress-modern-images\">plugin</a> that offers a setting for specifying the default image format used for the sub-sized images WordPress generates. A new <code>wp_editor_set_quality</code>&nbsp;filter&nbsp;is available for developers to modify the quality setting for uploaded images.</p>



<p>&ldquo;The media component team is also <a href=\"https://core.trac.wordpress.org/ticket/52867\">exploring the option of having WordPress perform the image format conversion</a> on uploaded images &ndash; using WebP as the default output format for sub-sized images,&rdquo; Silverstein said. &ldquo;We are also keeping our eyes on even more modern formats like AVIF and JPEGXL that will both improve compression and further reduce resources required for compression.&rdquo;</p>



<p>WordPress 5.8 is expected to be released on July 20, introducing WebP support for uploads. The new release also <a href=\"https://core.trac.wordpress.org/changeset/50817\">adds information to the Media Handling section of the Site Health screen</a>, showing the ImageMagick/Imagick supported file formats for the site in case users need it for debugging.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Jun 2021 04:27:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"WPTavern: Original Dark Mode Developer Relaunches Plugin After the Apparent ‘Cash Grab’ of the New Owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117984\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:251:\"https://wptavern.com/original-dark-mode-developer-relaunches-plugin-after-the-apparent-cash-grab-of-the-new-owners?utm_source=rss&utm_medium=rss&utm_campaign=original-dark-mode-developer-relaunches-plugin-after-the-apparent-cash-grab-of-the-new-owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6073:\"<img />WordPress dashboard screen with Dark Mode 2.



<p class=\"has-drop-cap\">Daniel James, the original Dark Mode WordPress plugin creator, is stepping back into WordPress development after a two-year pursuit of other projects. His new plugin: <a href=\"https://darkmode2.com/\">Dark Mode 2</a>.</p>



<p>It is a response to the recent <a href=\"https://wptavern.com/dark-mode-plugin-repurposed-and-renamed-to-wp-markdown-editor-change-leaves-users-confused\">change to the original Dark Mode plugin</a> for WordPress. Last month, I reported that the WPPool repurposed the plugin to include the commercial <a href=\"https://useiceberg.com/\">Iceberg editor</a>, a feature entirely unrelated to providing a dark viewing mode for the WordPress admin. It is now called WP Markdown Editor.</p>



<p>After the change, several plugin users left one-star ratings. However, its user base was small compared to that of ProfilePress (<a href=\"https://wptavern.com/profilepress-rebrands-and-repurposes-wp-user-avatar-now-a-membership-plugin-users-revolt-via-the-wordpress-review-system\">formerly WP User Avatar</a>), which continues getting drenched in low ratings. Still, the change did not sit well with James.</p>



<p>&ldquo;After finding out that Dark Mode had been passed on to multiple people, I was disappointed to see so many people say they&rsquo;d take it on without actually bothering to do anything with it,&rdquo; said James. &ldquo;It became even more disappointing when I learned the latest developers to have hold of it had ripped out the original functionality in favor of something completely different as a means of selling a product.&rdquo;</p>



<p>The Dark Mode plugin was <a href=\"https://wptavern.com/dark-mode-is-possibly-coming-to-a-wordpress-dashboard-near-you\">once a feature proposal</a> for WordPress. James began the process in 2018, but it never moved much beyond the initial stage. In 2019, he put the <a href=\"https://wptavern.com/dark-mode-wordpress-plugin-up-for-adoption\">plugin up for adoption</a>. It changed hands a couple of more times before WPPool became the owner.</p>



<p>In hindsight, James said he <a href=\"https://wptavern.com/dark-mode-plugin-repurposed-and-renamed-to-wp-markdown-editor-change-leaves-users-confused#comment-376844\">should have just abandoned</a> the plugin. At the time, he was stepping away from WordPress entirely to pursue other projects, including building applications with the Laravel PHP framework. However, he never stopped using WordPress completely and has kept an eye on the community.</p>



<p>&ldquo;I think there is more things that WordPress.org maintainers could do, specifically the Plugin Review Team,&rdquo; he said. &ldquo;I think more checks need to be done when plugins change ownership and/or are updated. As someone who used to put a lot of time into WordPress, I know how demanding it can be, so having volunteers tasked with more work is always a tricky thing to handle.&rdquo;</p>



<p>However, he said he did not have the solution to the problem. &ldquo;When you take Dark Mode and, more recently, WP User Avatar having their code changed for what appears to be a cash grab, all it does is hurt developers, agencies, and site admins.&rdquo;</p>



<p>The repurposing of his former work was the catalyst that he needed to rebuild a solution from scratch. Now, Dark Mode 2 is on the scene.</p>



<h2>A New Plugin and a Fresh Take</h2>



<img />Manage posts screen with Dark Mode enabled.



<p class=\"has-drop-cap\">James says Dark Mode 2 is still early in its development lifecycle. However, he does not think it is far off from where the original plugin would be if he would have continued it. Maybe just shy an extra setting or two.</p>



<p>&ldquo;I&rsquo;ve finally got it to a point where it&rsquo;s ready to be used and replace the classic Dark Mode plugin,&rdquo; he said. &ldquo;The great thing about starting again is that it&rsquo;s easier to style the WordPress dashboard. There is so much going on in the various wp-admin stylesheets that starting over was the only way. It means it supports the latest version of WordPress and cuts out any outdated styling that was previously there.&rdquo;</p>



<p>The plugin currently only has one setting, which individual users can set via their profile page. It is an option between &ldquo;Light&rdquo; and &ldquo;Dark&rdquo; viewing modes.</p>



<img />Configuring Dark Mode from the user profile screen.



<p>There are several features James is eager to work on going forward. One of the most requested from the &ldquo;classic&rdquo; Dark Mode days is styling the WordPress editor. At the moment, the plugin steers clear of it.</p>



<p>&ldquo;I&rsquo;ve always been hesitant to do that because of theme editor styles,&rdquo; he said. &ldquo;However, lots of themes tend to style the editors in a very basic fashion, so I&rsquo;ll be looking at adding in &lsquo;support&rsquo; styles for those that want a fully dark dashboard.&rdquo;</p>



<p>One of the other features he is working on is scheduling when Dark Mode is active or inactive. This would primarily work based on a user&rsquo;s system preferences if they have their OS set up for light or dark mode at different times of the day.</p>



<p>&ldquo;For something that appears to be quite a basic plugin, there&rsquo;s so much you can do with it,&rdquo; said James.</p>



<p>This time around, the plugin developer is making Dark Mode 2 a commercial-only plugin. He is pricing it at &pound;25 (~$35.28 at today&rsquo;s exchange rate). This includes lifetime updates with no installation limits. James said he wanted to keep the price low and not have people worry about another renewal fee every year while also still being supported for his effort.</p>



<p>&ldquo;I&rsquo;m not going to make millions from this plugin, and that&rsquo;s okay,&rdquo; he said. &ldquo;That&rsquo;s not my goal. My goal is to make a plugin that helps people and makes it easier for them to manage their website. Plus, it&rsquo;s about time WordPress got a proper Dark Mode!&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Jun 2021 23:20:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: WCEU Open Thread\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=54320\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://ma.tt/2021/06/wceu-open-thread/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:524:\"<p>I just wrapped up a fun session with <a href=\"https://matiasventura.com/\">Matías</a> and <a href=\"https://krogsgard.com/\">Brian</a>, and though we covered a lot of ground we weren&#8217;t able to get to all the questions from the audience. Starting at 2:58:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>So this is an open thread, if you have any question from the talk please drop it in the comments here, and myself or someone in the community will respond! We&#8217;ll keep this open for a day or so.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Jun 2021 17:30:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.8 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10733\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2021/06/wordpress-5-8-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9976:\"<p>WordPress 5.8 Beta 1 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it is not recommended to run this version on a production site. Instead, we recommend that you run this on a test site to play with the new version.</p>



<p>You can test the WordPress 5.8 Beta 1 in two ways:</p>



<ul><li>Install and activate the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (select the “Bleeding edge” channel and &#8220;Beta/RC Only&#8221; stream).</li><li>Direct download the <a href=\"https://wordpress.org/wordpress-5.8-beta1.zip\">beta version here&nbsp;(zip)</a>.</li></ul>



<p>The current target for the final release is July 20, 2021.  This is just&nbsp;<strong>six weeks away</strong>, so your help is vital to ensure this release is tested properly and as good as it can be.</p>



<p>Keep your eyes on the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;for&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-8+dev-notes/\">5.8-related developer notes</a>&nbsp;in the coming weeks, breaking down these and other changes in greater detail.</p>



<p>So what&#8217;s new in this 5.8?  Let&#8217;s start with some highlights.</p>



<h2>Highlights</h2>



<h3>Powerful Blocks</h3>



<ul><li>Discover several new blocks and expressive tools, including blocks for&nbsp;<em>Page Lists</em>,&nbsp;<em>Site Title</em>,&nbsp;<em>Logo</em>, and&nbsp;<em>Tagline</em>. A powerful&nbsp;<em>Query Loop</em>&nbsp;block offers multiple ways for displaying lists of posts and comes with new block patterns that take advantage of its flexibility and creative possibilities.</li><li>Interacting with nested blocks has been made easier with a permanent toolbar button for selecting a parent. Block outlines are shown when hovering or focusing on the different block type buttons. Block handles are now also present for drag and drop when in “select” mode.</li><li>Introduces the&nbsp;<strong>List View</strong>, a panel that can be toggled and helps navigate complex blocks and patterns.</li><li>Reusable blocks have an improved creation flow and support for history revisions. </li><li>A cool new duotone block adds images effects which can be used in media blocks or supported in third-party blocks. Color presets can also be customized by the theme.</li></ul>



<h3>Handpicked Patterns</h3>



<p>Patterns can now also be recommended and selected during block setup, offering powerful new flows. Pattern transformations are also possible and allow converting a block or a collection of blocks into different patterns.</p>



<p>New collection of Patterns and an initial integration with the upcoming Pattern Directory on WordPress.org.</p>



<h3>Better Tools</h3>



<ul><li><span>New template editor that allows creating new custom templates for a page using blocks.</span></li><li>Themes can now control and configure styling with a theme.json file, including layout configuration, block supports, color palettes, and more.</li><li>New design tools and enhancements to existing blocks, including more color, typography, and spacing options, drag and drop for Cover backgrounds, additions to block transformation options, ability to embed PDFs within the File block, and more.</li><li>Includes improvements to how the editor is rendered to more accurately resemble the frontend.</li></ul>



<h3>Internet Explorer 11</h3>



<p>Support for Internet Explorer 11 is ending in WordPress this year. In this release, most of those changes are being merged so use the Beta and RC periods to test!</p>



<h3>Blocks in Widgets Area</h3>



<ul><li>You can now use any block in your theme’s widget areas using the all new Widgets screen and updated Customizer.</li><li>Existing third party widgets continue to work via the <a href=\"https://developer.wordpress.org/block-editor/how-to-guides/widgets/legacy-widget-block/\">Legacy Widget block</a>.</li><li>Not quite ready for a full switch? To ease the transition, users can use the <a href=\"https://wordpress.org/plugins/classic-widgets/\">Classic Widgets plugin</a> and themes can call <a href=\"https://developer.wordpress.org/block-editor/how-to-guides/widgets/opting-out/\">remove_theme_support( &#8216;widgets-block-editor&#8217; )</a>.</li></ul>



<p><em>Looking for a change and can&#8217;t find it? There are more improvements listed after the break.</em></p>



<h2><strong>How You Can Help</strong></h2>



<h3>Do some testing!</h3>



<p>Testing for bugs is an important part of polishing the release during the beta stage and a great way to contribute.</p>



<p>If you think you’ve found a bug, please post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>. That’s also where you can find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p>Thanks for joining us, and happy testing!</p>



<p class=\"has-text-align-left\"><em><span><i>Props to </i></span><a href=\"https://profiles.wordpress.org/audrasjb/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>audrasjb</a>, <a href=\"https://profiles.wordpress.org/cbringmann/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>cbringmann</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>youknowriad</a>, <a href=\"https://profiles.wordpress.org/annezazu/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>annezazu</a>, <a href=\"https://profiles.wordpress.org/matveb/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>matveb</a>, and <a href=\"https://profiles.wordpress.org/desrosj/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>desrosj</a><span><i> for </i>editing/proof reading</span> this post, and <a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a> for final review.</em></p>



<hr class=\"wp-block-separator is-style-default\" />



<p><em>Full Site Editing<br />Coming at the end of year<br />But first, Beta 1</em></p>



<span id=\"more-10733\"></span>



<h2><strong>Improvements in this Release</strong></h2>



<ul><li>Improvements to Reusable blocks, Cover block, Table block, List View, Rich text placeholder, Template Editing Mode, Block Inserter, and Top Toolbar</li><li>Query loop block that uses a query/filter to create a flexible post list based on templates. Best used with patterns.</li><li>Parity refinement between editor and frontend, Standardization to block toolbars organization</li><li>Block widgets in the Customizer</li><li>Introducing the Global Styles and Global Settings APIs: control the editor settings and available customization tools and style blocks using a theme.json file.Template editor opens inside an iframe to more accurately resemble the front end.</li><li>Ability to transform Media and Text into Columns</li><li>Embedded PDFs within File block</li><li>Spacing options for Social Links and Buttons, Spacer block width adjustments</li><li>Twemoji has been updated to version 13.1, bringing you many new Emoji.</li><li>Editor performance improvements</li><li>Hide writing prompt from subsequent empty paragraphs</li><li>More descriptive publishing UI</li><li>Added capability to set the default format for image sub-sizes as well as WebP support</li><li>Added widgets block editor to widgets.php and customize.php</li><li>Added block patterns to default themes</li><li>Added ability to mark a plugin as unmanaged</li><li>Enable revisions for the reusable block custom post type</li><li>Enqueue script and style assets only for blocks present on the page</li><li>Abstracted block editor configuration by deprecating existing filters and introducing replacements that are context-aware</li><li>New sidebars, widget, and widget-types REST API endpoints</li><li>Added support for modifying the term relation when querying posts in the REST API</li><li>Site Health now supports custom sub-menus and pages</li><li>Themes now display the number of available theme updates in the admin menu</li><li>Speed up cached <code>get_pages()</code> calls</li><li>Underscore updates from 1.8.3 to 1.9.1</li></ul>



<p>To see all of the features for Gutenberg release in detail check out these posts: <a href=\"https://make.wordpress.org/core/2021/02/17/whats-new-in-gutenberg-10-0-february/\">10.0</a>, <a href=\"https://make.wordpress.org/core/2021/03/02/whats-new-in-gutenberg-10-1-3-march/\">10.1</a>, <a href=\"https://make.wordpress.org/core/2021/03/17/whats-new-in-gutenberg-10-2-17-march/\">10.2</a>, <a href=\"https://make.wordpress.org/core/2021/04/02/whats-new-in-gutenberg-10-3-31-march/\">10.3</a>, <a href=\"https://make.wordpress.org/core/2021/04/14/whats-new-in-gutenberg-10-4-14-april/\">10.4</a>, <a href=\"https://make.wordpress.org/core/2021/04/30/whats-new-in-gutenberg-10-5-28-april/\">10.5</a>, <a href=\"https://make.wordpress.org/core/2021/05/14/whats-new-in-gutenberg-10-6-12-may/\">10.6</a>, and <a href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\">10.7</a>. In addition to those changes, contributors have fixed&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&milestone=5.8&group=component&max=500&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">215 tickets in WordPress 5.8</a>, including&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&status=reopened&type=enhancement&type=feature+request&milestone=5.8&col=id&col=summary&col=type&col=status&col=milestone&col=owner&col=priority&col=changetime&col=keywords&order=changetime\">88 new features and enhancements</a>, with more bug fixes on the way.</p>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 09 Jun 2021 02:47:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Jeffrey Paul\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Open Invitation To Contribute to the WordPress Block Pattern Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=118068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:205:\"https://wptavern.com/open-invitation-to-contribute-to-the-wordpress-block-pattern-directory?utm_source=rss&utm_medium=rss&utm_campaign=open-invitation-to-contribute-to-the-wordpress-block-pattern-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4427:\"<p class=\"has-drop-cap\">The upcoming <a href=\"https://wordpress.org/patterns\">block pattern directory</a> is launching alongside WordPress 5.8 in July. The goal is to make several high-quality designs available for users right off the bat. However, the official submission process will not open until the directory launches. In this chicken-and-egg scenario, the Design team is asking for early contributors to submit their pattern candidates <a href=\"https://github.com/WordPress/pattern-directory\">via GitHub</a>.</p>



<p>&ldquo;The project needs a collection of high-quality, diverse, community-designed patterns to populate it with during development,&rdquo; wrote Kjell Reigstad in <a href=\"https://make.wordpress.org/design/2021/06/08/initial-patterns-for-the-wordpress-org-patterns-directory/\">the announcement post</a>. &ldquo;These patterns will set the tone for quality in the repository and will make the directory useful for folks upon its launch.&rdquo;</p>



<p>Alongside Reigstad, Beatriz Fialho and Mel Choyce-Dwan have already added several block patterns. They are available through the Gutenberg plugin now.</p>



<img />Several of the current block patterns.



<p>The trio has also submitted the majority of the 18 current potential patterns. While they have produced solid work thus far, the directory needs a more diverse set of designs from the community to launch with a bang.</p>



<p>Creating a pattern requires no coding skills. It is possible directly via the block editor. Just design, copy, and submit. The team already has a GitHub template in place for <a href=\"https://github.com/WordPress/pattern-directory/issues/new/choose\">submitting patterns</a>. Be sure to use CC0 (public domain) images if they are a part of your creation.</p>



<img />Copying a pattern from the WordPress editor.



<p>I have somewhere between 40 and 50 patterns lying around. You could say that I have been doing a bit of dabbling in the art of block-pattern design in my free time. Many of these patterns rely on custom block styles, so they are not suitable for the directory. However, I have several that are general enough for submission.</p>



<p>As always, I try to pay it forward when possible. Therefore, I cleaned a couple of patterns today using the Twenty Twenty-One theme and submitted them for inclusion.</p>



<p>The first was a three-column section of <a href=\"https://github.com/WordPress/pattern-directory/issues/138\">&ldquo;about me&rdquo; or &ldquo;connect with me&rdquo; boxes</a>. This has been one of my favorites to play around with.</p>



<img />About me boxes.



<p>It is not on par with my original design, but I like how it turned out. If you have read any of my past posts on blocks and patterns, I will sound like a broken record. However, I must say it for those who did not hear the message the first 100 times. The main limiting factor for block patterns is the lack of spacing options on almost all blocks.</p>



<p>Blocks like Group and Column have padding controls, which are a nice feature. However, vertical margin options are must-haves for the directory to be as successful with its goals as it intends to be.</p>



<p>A prime example is in my first pattern. My original mockup closes the gap between the heading and subheading. In my submission, I tightened the space by setting the line height, but I needed an option for zeroing out the vertical margin.</p>



<p>If you compare it to the original idea built with some features not yet available, you can see how much improved the overall layout&rsquo;s spacing is.</p>



<img />Original about me boxes with tighter margin control.



<p>I ran into the same issue with my second pattern, <a href=\"https://github.com/WordPress/pattern-directory/issues/140\">Team Social Cards</a>, between the Image and Separator blocks. The gap there has more to do with Twenty Twenty-One&rsquo;s inconsistent spacing.</p>



<img />



<p>I may revisit the giraffe photo, but it is growing on me. It is fun. Plus, end-users are meant to actually replace it.</p>



<p>I will probably submit one or two more during this early phase, and I will definitely contribute more once the pattern directory is officially open. For now, I want to see our talented design community giving a little something back to the WordPress project. This is such an easy way to contribute that has no coding requirement &mdash; just a little time.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Jun 2021 20:53:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"WPTavern: Review Signal Publishes 2021 Hosting Performance Benchmarks on New WordPress-Powered Site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117467\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:243:\"https://wptavern.com/review-signal-publishes-2021-hosting-performance-benchmarks-on-new-wordpress-powered-site?utm_source=rss&utm_medium=rss&utm_campaign=review-signal-publishes-2021-hosting-performance-benchmarks-on-new-wordpress-powered-site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5577:\"<p>Kevin Ohashi has published his <a href=\"https://wphostingbenchmarks.com/\">2021 WordPress Hosting Performance Benchmarks</a> report. The annual report is broken down into six different hosting tiers, from the most economical &lt;$25/month, to the $500+ enterprise level. This is the second year the stats include WooCommerce-specific hosts as a separate category.</p>



<p>After eight years of measuring peak performance and consistency for WordPress hosts, <a href=\"https://reviewsignal.com/\">Review Signal</a> has relaunched benchmarks on <a href=\"https://wphostingbenchmarks.com/\">wphostingbenchmarks.com</a>, a WordPress-powered site.  </p>



<p>Review Signal started using sentiment analysis to capture consumer reviews of hosting companies on Twitter in 2011 and launched in 2012. Ohashi added a WordPress blog but said it never really integrated well with the code and design of the rest of the site. He launched the benchmarks in 2013, publishing the first handful of tests via a simple blog post.</p>



<p>&ldquo;In 2020 it was dozens of companies, 6 full price tiers of competition, and a separate WooCommerce group as well,&rdquo; Ohashi said. &ldquo;It really has become its own product,&nbsp;and creating a dedicated site for them at WPHostingBenchmarks.com is recognition of that fact. It also opened the door for a rebranding effort and a much better presentation of the results.&rdquo;</p>



<p>Results on the new site are much easier to understand at a glance with honorable mentions and top tier companies denoted by a half star and full star. Visitors can click through to get more specific information about each host&rsquo;s performance on the tests.</p>



<img />



<p>Top tier performers in the &lt;$25 tier included 20i, CynderHost, EasyWP by Namecheap, Eco Web Hosting, Green Geeks, Lightning Base, RAIDBOXES, and WPX, with a handful of honorable mentions. In the Enterprise tier (shown above), RAIDBOXES, Scaleforce powered by Jelastic, Seravo, Servebolt, Servebolt Accelerated, and WordPress VIP capture the top tier spots.</p>



<p><a href=\"https://wphostingbenchmarks.com/company/seravo/\"></a>Now that the new site is database driven, Ohashi can publish faster and reduce the amount of work it takes going forward.</p>



<p>&ldquo;It also lets me auto generate pages from the data &ndash; for example company profile pages,&rdquo; he said. &ldquo;I attempted to write a blog post in the past about companies that did well, but it was never really a success. Now, I can display all their historical results, pull up analysis, compare them all by year, etc. So I am happier,&nbsp;companies are&nbsp;(hopefully) happier, and most of all &ndash; consumers get better insight into the&nbsp;results.&rdquo;</p>



<h2>WooCommerce Benchmarks Expanding</h2>



<p>WooCommerce benchmarks have expanded since their first time to be included separately last year. Five out of the 11 companies tested scored top tier results, including Lightning Base, Pressable, Servebolt, SiteGround, and WordPress.com.</p>



<p>Servebolt scored 99.999% Uptime and the fastest Load Storm average response time, along with the fastest wp-login, Buyer and Customer profiles and second fastest Home profile. Pressable reprised its top tier status with perfect uptime and the second fastest Average Response Time on WebPageTest. WordPress.com posted perfect uptime, the second fastest K6 average response time, and a solid Load Storm test. On the WebPageTest results WordPress.com took 10/12 of the fastest response times and posted the fastest WP Bench scores Ohashi has ever recorded and the second fastest PHP Bench.</p>



<p>In 2021, SiteGround slipped to honorable mention status in every other tier where it was tested, with the exception of WooCommerce. Lightning Base maintained its top tier status with a 99.99% uptime rating, very good flat Load Storm and K6 results, and no problems with the tests.</p>



<img />



<p>&ldquo;For WooCommerce I had seven companies participate last year and this year had 11 companies, which is a 57% increase,&rdquo; Ohashi said. &ldquo;The traditional WordPress benchmarks grew from ~29 companies last year to 35-37 depending on if you differentiate Automattic brands (VIP, WP.com, Pressable) which is at least a 20% growth in participation.&rdquo;</p>



<p>Ohashi said he is pleased with the mix of new entrants and companies that have participated for years, but the pandemic has slowed Review Signal&rsquo;s business.</p>



<p>&ldquo;It&rsquo;s been a bit slow revenue wise,&rdquo; he said. &ldquo;I don&rsquo;t sell any products and don&rsquo;t think I&rsquo;ve found any advantage during the pandemic to make what I do stand out relative to what&rsquo;s happening to the world. That is another motivating reason for creating <a href=\"https://WPHostingBenchmarks.com\">WPHostingBenchmarks.com</a>, I wanted to take that extra time I have and make the biggest change for Review Signal in years.&rdquo;</p>



<p>Review Signal&rsquo;s benchmarks are one of the most thorough and transparent evaluations of hosting products in the industry. This is because Ohashi doesn&rsquo;t accept any hosting sponsorship. Each company pays a small, publicly documented, fee for participation to cover the costs of the tests. These fees are standardized based on the pricing tier of the product entered into the testing. Consumers in the market for a new hosting company will find <a href=\"https://WPHostingBenchmarks.com\">WPHostingBenchmarks</a> a solid resource for comparing how companies perform at different pricing tiers. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 08 Jun 2021 04:06:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Spice Up Your Food or Recipe Blog With the Nutmeg WordPress Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117981\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/spice-up-your-food-or-recipe-blog-with-the-nutmeg-wordpress-theme?utm_source=rss&utm_medium=rss&utm_campaign=spice-up-your-food-or-recipe-blog-with-the-nutmeg-wordpress-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5683:\"<p class=\"has-drop-cap\">Last week, Dumitru Br&icirc;nzan <a href=\"https://www.ilovewp.com/nutmeg-plus-food-blogging-recipes-wordpress-theme/\">announced Nutmeg Plus</a>. It is the latest commercial theme offering through his ILOVEWP brand. Earlier today, the <a href=\"https://wordpress.org/themes/nutmeg/\">free version of Nutmeg</a> landed in the WordPress theme directory. The theme is built for food and recipe bloggers and is another solid example of building on the block system.</p>



<p>As is typical of his style, Nutmeg rests on a foundation of clean lines and readable typography. It pulls elements from some of Br&icirc;nzan&rsquo;s previous work, such as the featured pages section of <a href=\"https://wordpress.org/themes/photozoom/\">Photozoom</a> and the two-column intro from <a href=\"https://wordpress.org/themes/endurance/\">Endurance</a>. Reusing code is one of the cornerstones of smart development.</p>



<p>The theme never gets too flashy, nor is it a bold step forward in design. However, it has a timeless layout that is hard to go wrong with.</p>



<p>Where it shines is in its use of block patterns and styles.</p>



<img />Recipe post built with Nutmeg.



<p>Sometimes, theme authors surprise me with, in hindsight, simple solutions. Nutmeg&rsquo;s List block styles had me asking, &ldquo;Why didn&rsquo;t I think of that?&rdquo;</p>



<p>Last month, I <a href=\"https://wptavern.com/you-might-not-need-that-block\">challenged theme authors</a> to build out patterns that are often created as custom blocks. In the post, I showcased an example of how themers could provide pricing columns for their users. The Nutmeg theme is a perfect example of that same concept, only applied to recipes.</p>



<p>The unique aspect is that Br&icirc;nzan did not make it complex. With a few simple styles for the List block, he had all the makings of the typical &ldquo;recipe card&rdquo; seen on many food blogs. <em>Is it as advanced as a fully-featured recipe card plugin?</em> No. But, that should not be the goal. If users need more advanced recipe-related features and functionality, that is where plugins make sense. The theme even recommends a few like WP Recipe Maker, Recipe Card Blocks, and Delicious Recipes for those who need more.</p>



<p>However, for bloggers who are just starting, undecided on recipe plugins, or simply do not want another dependency, the theme has built-in solutions for them. It is tough to discount the value in that.</p>



<img />Adding instructions and ingredients.



<p>With a starting point of the Recipe Info, Ingredients List, or Ingredients + Instructions patterns, users can quickly pop these sections into their content. Or, they can go the alternate route of starting with the List block and selecting one of four custom styles.</p>



<blockquote class=\"wp-block-quote\"><p>Theme authors should be able to build unique and complex combinations of blocks with custom styles. Users should be able to just make it look like the demo.</p><cite><a href=\"https://wptavern.com/block-patterns-will-change-everything\">Block Patterns Will Change Everything</a></cite></blockquote>



<p>It was March 2020. The Gutenberg development team had just pushed block patterns into the plugin, but the feature would not land in core WordPress for months. I do not want to call myself a prophet. It was plain enough for anyone to see: block patterns would eventually change how end-users interact with the editor and build their sites.</p>



<p>Patterns were the answer to elaborate homepage setups. Instead of jumping back and forth between non-standard theme options, hoping for the best from a theming community that never learned to entirely leverage the customizer, users could simply click buttons and insert layout sections where they wanted.</p>



<p>Recreating Nutmeg&rsquo;s homepage demo was easy. By just picking a few patterns and adding some custom images, I was up and running in minutes. No tutorial necessary. No half-hour session of figuring out a theme&rsquo;s custom options setup.</p>



<ol><li>Select the custom homepage template.</li><li>Add the Cover with Overlay pattern and upload an image.</li><li>Drop in the Opening Message pattern and customize.</li><li>Insert the Featured Pages pattern and add images.</li></ol>



<img />Homepage built from patterns.



<p>Simple setup processes like this are the exact thing that theme authors have been repeatedly asking about for the better part of a decade. Except for a powerful Query solution, which is arriving in a limited form in WordPress 5.8 (the Post Featured Image block is the weak point), the tools are mostly in place. The feature set is only growing with each release.</p>



<p>One of my favorite solutions in the theme is the use of the Cover block&rsquo;s inner container. The plugin has several styles for moving this inside box around and creating a featured section.</p>



<img />Customizing the Cover block with styles.



<p>One improvement I might suggest is to provide &ldquo;width&rdquo; styles for the inner container here. Core already provides an alignment matrix option. Styles for 25%, 50%, and 75% width (100% being the default) would offer more variety when coupled with the existing alignments.</p>



<p>The only things that felt out of place with the theme were its alignment block styles for Heading and Paragraph blocks. WordPress already provides alignment options for these blocks. I am not sure if there is a use case that I am unaware of for the styles, but they were definitely confusing.</p>



<p>The theme is worth a test run for any food or recipe bloggers who need a dash of <em>Nutmeg</em> to spice up their site.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 22:54:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WordPress.org blog: People of WordPress: Tijana Andrejic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10427\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2021/06/people-of-wordpress-tijana-andrejic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13617:\"<p><strong>WordPress is open source software, maintained by a global network of contributors. There are many examples of how WordPress has changed people’s lives for the better. In this monthly series, we share some of the amazing stories.</strong></p>



<p>This month to coincide with WordCamp Europe, we feature Tijana Andrejic from Belgrade, Serbia, about her journey from fitness trainer to the WordPress world, with the freelance and corporate opportunities it introduced. </p>



<img width=\"632\" height=\"387\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/06/2021-07-Tijana-Andrejic_Featured-Img_1.jpg?resize=632%2C387&ssl=1\" alt=\"Tijana - portrait picture\" class=\"wp-image-10713\" />



<p>As a professional manager with a college degree in Organizational Science and a certified fitness instructor, Tijana is nothing if not driven and goal-oriented.&nbsp;</p>



<p>Following her time as a fitness trainer, Tijana moved to work in IT around 2016. She first explored content creation and design before focusing on SEO and becoming an independent specialist.&nbsp;&nbsp;</p>



<p>Tijana was hired as a Customer Happiness Engineer for a hosting company, where she discovered the benefits of having a team. She realized that having close working relationships with colleagues is helpful for business success and accelerates personal growth.</p>



<p>Tijana hopes that by sharing her story, she can help others who are either starting their career or are moving roles. She describes the opportunities she discovered in the WordPress community as ‘a huge epiphany’, especially in the world of freelancing.</p>



<p>She highlights <strong>5 things that helped her to start a new freelancing career</strong>. Let’s dive into them.</p>



<h2>What motivates me?</h2>



<p>“Why am I doing this?” is the first question that Tijana asks herself before starting anything new. This self-review and honesty, she feels, allows her to determine her priorities. She also benchmarks options around her motivations of wanting a flexible schedule and to grow professionally.&nbsp;</p>



<p>She lists the reasons to make a particular choice, like being a freelancer, to help her choose the right job, pathway, or identify alternatives.&nbsp;</p>



<p>She recommends that others can take a similar approach. If freelancing is still the best solution after examining all their goals and motivations, Tijana believes a good next step would be to learn WordPress-related skills.</p>



<img src=\"https://lh6.googleusercontent.com/cdHeIL-H_mE6QFCUxUT-gfKS2GzizRHtn4iCENoaWOimC82BfModRJh44QbhvHPW0GNVP5eUPhgxQteDRbA_9EUzpssTXMGWje1hUuKyrfXUgGhCnvXQdraaUQiaGBjFr73dNYxr\" alt=\"WordCamp Europe 2019 group picture\" />



<h2>Develop WordPress related skills</h2>



<p>The next question you may ask: “Why WordPress?”</p>



<p>WordPress is used by more than 40% of websites in some form and offers various roles, many of which are not developer-specific. Tijana highlights a few:&nbsp;</p>



<ul><li>web developer (coding websites, themes, and plugins)</li><li>web implementor (creating websites from existing themes without coding)</li><li>web designer (designing website mock-ups, editing images, or creating online infographics)</li><li>client support professional (helping people with their websites)</li><li>website maintenance (WordPress, themes, and plugins are maintained and backed up regularly)</li><li>WordPress trainer (helping clients with how to use the platform or teaching other web professionals)</li><li>content writer</li><li>accessibility specialist (making sure standards are met and suggesting solutions for accessibility barriers)</li><li>SEO consultant (improving search outcomes and understanding)</li><li>statistics consultant, especially for web shops</li><li>WordPress assistant (adding new content and editing existing posts)</li><li>website migration specialist (moving websites from one server to another)</li><li>web security specialist</li></ul>



<img src=\"https://lh4.googleusercontent.com/16XExYT_P4R4PX3orOaWbueDfkBIA6PFQ-CuYEXdeN9AvUIuIF33aIjT1DpdnFCqhrijWv1f68OR2Qh14xGT9REHGJ-MqK-OxJ9XcrhZ3IkcW8DBI7nVAtvFcCnCHL0woka_FV6t\" alt=\"WCBGD group picture\" />



<p>Tijana emphasized: “Another reason why WordPress is great for freelancers is the strong community that exists around this content management system (CMS).&#8221; WordCamps and Meetups are a way to get useful information and meet people from a large and very diverse community and get answers to many questions straight away.&nbsp;</p>



<p>In the past year, these events have been primarily online. However, the contributors who run them continue to make an effort to provide an experience as close to in-person events as possible. The biggest advantage to online events is that we can attend events from across the world, even if sometimes during these difficult times, it is difficult to get enough time to deeply into this new experience. Since Tijana’s first Meetup, she has attended many WordPress community events and volunteered as a speaker.</p>



<h2>Plan in advance</h2>



<p>Becoming a freelancer takes time. For Tijana, success came with proper planning and following her plan to ‘acquire or improve relevant skills that will make you stand out in the freelance market.’ She strongly believes that learning and growing as a professional opens more business opportunities.&nbsp;</p>



<p>If you are considering a freelance career, she advises improving relevant skills or developing new skills related to your hobbies as ‘there is nothing better than doing what you love.’ In cases where no previous experience and knowledge can be used, she suggests choosing ‘a job that has a shorter learning curve and builds your knowledge around that.’</p>



<p>Tijana started as a content creator and learned to become an SEO expert. However, she highlights many alternative paths, including starting as a web implementer and moving to train as a developer.&nbsp;</p>



<p>She suggests to others: “It would be a good idea to analyze the market before you jump into the learning process.” She also recommends people check the latest trends and consider the future of the skills they are developing.</p>



<p>Visit the new <a href=\"https://learn.wordpress.org/\">Learn WordPress.org</a> to see what topics are of interest to you. In this newly established resource, the WordPress community aggregates workshops to support those who want to start and improve their skills, provides lesson plans for professional WordPress trainers and helps you create personal learning to develop key skills. There is also material on helping you be part of and organize events for your local community.</p>



<p>Tijana highlights that there are many places for freelancers to find clients. For example, the WordPress Community has a place where companies and individual site owners publish their job advertisements&nbsp; &#8211; <a href=\"https://jobs.wordpress.net/\">Jobs.WordPress.net</a>.</p>



<h2>Hurray, it’s time to get a first freelancing job</h2>



<p>As a pragmatic person, Tijana recommends: “Save money before quitting your job to become a full-time freelancer. Alternatively, try freelancing for a few hours per week to see if you like it. Although some people do benefit when taking a risk, think twice before you take any irreversible actions.”&nbsp;</p>



<p>She shared some possible next steps:&nbsp;</p>



<ul><li>use a freelancing platform</li><li>triple-check your resume</li><li>professionally present yourself</li><li>fill up your portfolio with examples</li><li>use video material</li></ul>



<p>“By using video material, your clients will not see you like a list of skills and previous experiences, but as a real person that has these skills and experiences and that provides a certain service for them.”</p>



<p>She adds: “Have a detailed strategy when choosing your first employer. Choose your first employer wisely, very wisely. I can’t emphasize enough how important this is”.</p>



<p>When Tijana took her first freelancing job, she considered the following:</p>



<ul><li>how was the employer rated by other freelancers who worked for him previously</li><li>how does the employer rate other freelancers</li><li>how much money had they already spent on the platform</li><li>the number of open positions for a specific job and the number of freelancers that have already applied&nbsp;</li></ul>



<p>“The first job is not all about the money. Don’t get greedy on your first job. If you get good recommendations, your second job can pay two to three times more. And your third job can go up to five times more. That was my experience.”</p>



<h2>Take responsibility as a freelancer</h2>



<p>Tijana reminds us: “Freedom often comes with responsibility; individual responsibility is key when it comes to freelancing.”</p>



<p>She advises others not to take a job if you can not make a deadline and have someone reliable who can help you.&nbsp;</p>



<p>Missing deadlines will cost your client money and affect the review the client will be willing to leave about your job, and this can have a big impact on your future opportunities or freelance jobs.</p>



<p>She adds: “This can start a downward spiral for your career. However, we are all humans, and unpredictable things can happen. If for some reason you are not able to complete your work in a timely manner, let your client know immediately so they can have enough time to hire someone else”.</p>



<p>Tijana emphasizes the importance of making expectations clear before accepting a job, both what the client is expecting and what you can expect from the client.&nbsp;</p>



<p>Lastly, she points out that if you are working from home, your friends and family should treat you the way they would if you were in an office. She advises: “Let them know about your working schedule.”</p>



<p>She hopes that these basic guidelines will be useful in launching freelance careers, as they did her, even though there is no universal recipe for all.</p>



<p>Tijana highlights: “It’s just important to stay focused on your goals and to be open to new opportunities.” Freelancing wasn’t the only way she could have fulfilled her goals, but it was an important part of her path, and it helped her be confident in her abilities to make the next big step in her life.</p>



<p>As a freelancer, she was missing close relationships with colleagues and teamwork, which she has now found in her current firm. Her colleagues describe her as a: “walking-talking bundle of superpowers: sports medicine and fitness professional, SEO expert, blogger, designer and a kitty foster mum”.</p>



<img src=\"https://lh4.googleusercontent.com/PIGT9R6FmtEHsNBvWzyViW5htRAm156asTOsohOGOUwfsWjW1TuDhUI9yuZnjIe-1eFHfFUWPULPtw82P3YYXHa0bsY_jA5keelmDHfSkTdd3xUsVZTmG9KvdE8XTojvU3LxYCsi\" alt=\"Conference reception\" />



<p>If you are considering starting your career as a freelancer, take the courses offered at <a href=\"https://learn.wordpress.org/\">learn.wordpress.org,</a> reach out to companies that you would be interested in working with, and remember that there are a whole host of opportunities in the WordPress project.</p>



<p><a href=\"https://make.wordpress.org/\">The WordPress.org Teams</a> &#8211; what they do, when and where they meet</p>



<p><a href=\"https://learn.wordpress.org/\">Learn WordPress resource</a> &#8211; free to use to expand your knowledge and skills of using the platform and learning about the community around it.</p>



<p>The 3-day <a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe 2021</a> online event begins on 7 June 2021. You can discover more about being a contributor in its live sessions and <a href=\"https://europe.wordcamp.org/2021/contribute-to-wordpress/\">section on ways to contribute to WordPress</a>.</p>



<h2>Contributors</h2>



<p>Thanks to Olga Gleckler (<a href=\"https://profiles.wordpress.org/oglekler/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>oglekler</a>), Abha Thakor (<a href=\"https://profiles.wordpress.org/webcommsat/\">@webcommsat</a>), Chloé Bringmann (<a href=\"https://profiles.wordpress.org/cbringmann/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>cbringmann</a>), Surendra Thakor (<a href=\"https://profiles.wordpress.org/sthakor/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>sthakor</a>), and Meher Bala (<a href=\"https://profiles.wordpress.org/meher/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>meher</a>) for working on this story. Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\">@chanthaboune</a>) and also to Topher DeRosia (<a href=\"https://profiles.wordpress.org/topher1kenobe/\">@topher1kenobe</a>) who created HeroPress. Thank you to Tijana Andrejic (<a href=\"https://profiles.wordpress.org/andtijana/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>andtijana</a>) for sharing her #ContributorStory</p>



<img src=\"https://lh4.googleusercontent.com/FEZ2FQJ0vQ311YoPfh6ny15NXh8saTLH_RjyDO4pUOuEGBTa-Czk63PGoWL04FawKviRfNx0QXePx-goK04X12ry1BR_WXh-kVPIfsEeItPAX6reN5fHS96q6-8dUI506ZO38Z0G\" alt=\"HeroPress logo\" />



<p><em>This post is based on an article originally published on HeroPress.com. It highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members in our <a href=\"https://wordpress.org/news/category/heropress/\">People of WordPress series</a>.</em></p>



<p><em>#ContributorStory #HeroPress</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 22:00:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"webcommsat AbhaNonStopNewsUK\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"BuddyPress: BuddyPress 8.0.0 “Alfano”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=319133\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://buddypress.org/2021/06/buddypress-8-0-0-alfano/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11623:\"<p>&#8220;Alfano&#8221; is our first major release of 2021. It is named after <a href=\"http://www.alfanopizza.com\">Alfano’s Pizza</a> in Rock Island, Illinois, a family-run pizzeria that’s been around since the 1970s. They know how to keep it simple: there’s nothing on the menu but mouth-watering pizzas and calzones featuring their own made-from-scratch sauce and crust. For the true Alfano’s experience, order a stuffed pizza and dine in with as many friends as you can bring. The massive, two-crust pizza will be brought to the table piping hot, and there will be plenty for everyone!</p>



<div class=\"wp-block-buttons is-content-justification-center\">
<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-white-color has-text-color has-background\" href=\"https://downloads.wordpress.org/plugin/buddypress.8.0.0.zip\"><strong>Get BuddyPress 8.0.0</strong></a></div>
</div>



<div class=\"wp-block-spacer\"></div>



<p>You can get it clicking on the above button, downloading it from the&nbsp;<a href=\"https://wordpress.org/plugins/buddypress/\">WordPress.org plugin directory</a>&nbsp;or checking it out from our&nbsp;<a href=\"https://buddypress.trac.wordpress.org/browser/branches/8.0\">Subversion repository.</a></p>



<p><img src=\"https://s.w.org/images/core/emoji/13.1.0/72x72/1f449.png\" alt=\"?\" class=\"wp-smiley\" />&nbsp;<em>If you’re upgrading from a previous version of BuddyPress, it’s always a good idea to back-up your WordPress database and files ahead of time.</em></p>



<p>You can review all of the changes in this 8.0.0 release in the&nbsp;<a href=\"https://codex.buddypress.org/releases/version-8-0-0/\">release notes</a>. Below are the key features we believe you are going to enjoy most!</p>



<div class=\"wp-block-spacer\"></div>



<h2>Your current members are the best way to recruit fantastic new members for your community.</h2>



<p>Whether public registration is enabled or not, you can activate this great new opt-in feature from your site&#8217;s BuddyPress settings; with it, your trusted members will handpick new members who will enrich your community.</p>



<div class=\"wp-block-image\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/front-invites-tool.png\"><img width=\"985\" height=\"646\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/front-invites-tool.png\" alt=\"Illustration showing the Members Invite Screen.\" class=\"wp-image-319137\" /></a></div>



<p>Once activated, each member will be able to send new Member Invitation emails and manage the pending invitations directly from his or her profile area.</p>



<div class=\"wp-block-image\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/front-pending-invites-tool.png\"><img width=\"981\" height=\"406\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/front-pending-invites-tool.png\" alt=\"Illustration showing the Members Pending Invites Screen.\" class=\"wp-image-319140\" /></a></div>



<p>You keep control of everything thanks to two new screens we added to the BuddyPress Tools dashboard: invitations and opt-outs management.</p>



<div class=\"wp-block-image\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/admin-invites-tool.png\"><img width=\"1176\" height=\"519\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/admin-invites-tool.png\" alt=\"Illustration showing the Members Invitations Administration Screen.\" class=\"wp-image-319141\" /></a></div>



<div class=\"wp-block-buttons is-content-justification-right\">
<div class=\"wp-block-button has-custom-font-size is-style-outline has-normal-font-size\"><a class=\"wp-block-button__link has-white-background-color has-text-color has-background\" href=\"https://bpdevel.wordpress.com/2021/05/26/bp-8-0-introduces-site-membership-invitations/\"><strong>Read more about it</strong></a></div>
</div>



<div class=\"wp-block-spacer\"></div>



<h2>Improved registration experience.</h2>



<p>First, you can select any xProfile field from any xProfile field group to use on your site&#8217;s registration form. Second, if your site requires that users accept specific rules such as terms of service or a code of conduct, you can now take advantage of the new Checkbox Acceptance xProfile Field type to record their agreement.</p>



<ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/signup-fields.png\"><img width=\"1024\" height=\"492\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/signup-fields-1024x492.png\" alt=\"\" class=\"wp-image-319146\" /></a><a href=\"https://bpdevel.wordpress.com/2021/05/06/selectable-xprofile-sign-up-fields-in-8-0-0/\"><span class=\"has-inline-color has-white-color\">Read more about Selectable signup fields</span></a></li><li class=\"blocks-gallery-item\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/checkbox-acceptance.png\"><img width=\"1006\" height=\"763\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/checkbox-acceptance.png\" alt=\"\" class=\"wp-image-319145\" /></a><a href=\"https://bpdevel.wordpress.com/2021/05/05/new-xprofile-field-type-checkbox-acceptance-will-be-introduced-in-buddypress-8-0-0/\"><span class=\"has-inline-color has-white-color\">Read more about the Checkbox Acceptance field type</span></a></li></ul>



<p>Third, once a user activates his or her account, BuddyPress will send a welcome email to help get him or her engaged with your community. You can customize the content of this email from the Emails menu of your WordPress dashboard. Have a look to this <a href=\"https://bpdevel.wordpress.com/2021/05/24/8-0-0-will-include-a-bp-email-to-welcome-new-community-members/\">developer note</a> to find out more about it.</p>



<div class=\"wp-block-spacer\"></div>



<h2>WP xProfile field types.</h2>



<p>The WP Biography field type lets you include the user&#8217;s Biographical Info and thanks to the WP Textbox field you can include the first &amp; last name, the Website URL as well as <strong>any</strong> of the custom contact methods of your users.</p>



<div class=\"wp-block-image\"><a href=\"https://buddypress.org/wp-content/uploads/1/2021/06/wordpress-fields.png\"><img width=\"847\" height=\"497\" src=\"https://buddypress.org/wp-content/uploads/1/2021/06/wordpress-fields.png\" alt=\"Illustration showing the xProfile Field Edit Screen.\" class=\"wp-image-319149\" /></a></div>



<div class=\"wp-block-buttons is-content-justification-right\">
<div class=\"wp-block-button has-custom-font-size is-style-outline has-normal-font-size\"><a class=\"wp-block-button__link has-white-background-color has-text-color has-background\" href=\"https://bpdevel.wordpress.com/2021/03/24/wordpress-xprofile-field-types/\"><strong>Read more about it</strong></a></div>
</div>



<div class=\"wp-block-spacer\"></div>



<div><span class=\"dashicons dashicons-admin-generic\"></span></div>



<div class=\"wp-block-spacer\"></div>



<h2 class=\"has-text-align-center\">Under the hood</h2>



<p>8.0.0 includes more than 45 changes to improve the Activity component, the BP Nouveau Template pack, the BP REST API and many more components and features.</p>



<div class=\"wp-block-spacer\"></div>



<div><span class=\"dashicons dashicons-buddicons-buddypress-logo\"></span></div>



<div class=\"wp-block-spacer\"></div>



<h2 class=\"has-text-align-center\">Many thanks to the 47 contributors who helped us build &amp; translate BuddyPress 8.0.0</h2>



<p><a href=\"https://profiles.wordpress.org/oztaser/\">Adil Oztaser (oztaser)</a>, <a href=\"https://profiles.wordpress.org/chaion07/\">Ahmed Chaion (chaion07)</a>, <a href=\"https://profiles.wordpress.org/dontdream/\">Andrea Tarantini (dontdream)</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone B Gorges (boonebgorges)</a>, <a href=\"https://profiles.wordpress.org/sbrajesh/\">Brajesh Singh (sbrajesh)</a>, <a href=\"https://profiles.wordpress.org/thee17/\">Charles E. Frees-Melvin (thee17)</a>, <a href=\"https://profiles.wordpress.org/needle/\">Christian Wach (needle)</a>, <a href=\"https://profiles.wordpress.org/comminski/\">comminski</a>, <a href=\"https://profiles.wordpress.org/dancaragea/\">Dan Caragea (dancaragea)</a>, <a href=\"https://profiles.wordpress.org/dcavins/\">David Cavins (dcavins)</a>, <a href=\"https://github.com/dominic-ks/\">dominic-ks</a>, <a href=\"https://github.com/edusperoni/\">Eduardo Speroni (edusperoni)</a>, <a href=\"https://profiles.wordpress.org/fernandot/\">Fernando Tellado (fernandot)</a>, <a href=\"https://profiles.wordpress.org/mociofiletto/\">Giuseppe (mociofiletto)</a>, <a href=\"https://profiles.wordpress.org/hz_i3/\">hz_i3</a>, <a href=\"https://profiles.wordpress.org/ianbarnes/\">Ian Barnes (ianbarnes)</a>, <a href=\"https://profiles.wordpress.org/atxamart/\">Iker Garaialde (atxamart)</a>, <a href=\"https://profiles.wordpress.org/nobnob/\">Javier Esteban (nobnob)</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby (johnjamesjacoby)</a>, <a href=\"https://profiles.wordpress.org/krupajnanda/\">Krupa (krupajnanda)</a>, <a href=\"https://profiles.wordpress.org/offereins/\">Laurens Offereins</a>, <a href=\"https://profiles.wordpress.org/mahdiar/\">mahdiar</a>, <a href=\"https://profiles.wordpress.org/markscottrobson/\">Mark Robson (markscottrobson)</a>, <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet (imath)</a>, <a href=\"https://profiles.wordpress.org/mattneil/\">mattneil</a>, <a href=\"https://profiles.wordpress.org/meijioro/\">meijioro</a>, <a href=\"https://profiles.wordpress.org/kalich5/\">Michal Janata (kalich5)</a>, <a href=\"https://profiles.wordpress.org/modemlooper/\">modemlooper</a>, <a href=\"https://profiles.wordpress.org/DJPaul/\">Paul Gibbs (DJPaul)</a>, <a href=\"https://profiles.wordpress.org/podporawebu/\">podporawebu</a>, <a href=\"https://profiles.wordpress.org/psmits1567/\">Peter Smits (psmits1567)</a>, <a href=\"https://profiles.wordpress.org/nekojonez/\">Pieterjan Deneys (nekojonez)</a>, <a href=\"https://profiles.wordpress.org/r-a-y/\">r-a-y</a>, <a href=\"https://profiles.wordpress.org/espellcaste/\">Renato Alves (espellcaste)</a>, <a href=\"https://profiles.wordpress.org/renegade1/\">renegade1</a>, <a href=\"https://profiles.wordpress.org/slaffik/\">Slava Abakumov (slaffik)</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt (sabernhardt)</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar (netweb)</a>, <a href=\"https://profiles.wordpress.org/studiocrafted/\">studiocrafted</a>, <a href=\"https://profiles.wordpress.org/sippis/\">Timi Wahalahti (sippis)</a>, <a href=\"https://profiles.wordpress.org/mobby2561/\">Tomas (mobby2561)</a>, <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher (topher1kenobe)</a>, <a href=\"https://profiles.wordpress.org/utsav72640/\">Utsav tilava (utsav72640)</a>, <a href=\"https://profiles.wordpress.org/vapvarun/\">Varun Dubey (vapvarun)</a>, <a href=\"https://profiles.wordpress.org/venutius/\">Venutius</a>, <a href=\"https://profiles.wordpress.org/weddywood/\">WeddyWood</a>, <a href=\"https://profiles.wordpress.org/yordansoares/\">Yordan Soares (yordansoares)</a>.</p>



<div class=\"wp-block-spacer\"></div>



<div><span class=\"dashicons dashicons-format-chat\"></span></div>



<div class=\"wp-block-spacer\"></div>



<h2 class=\"has-text-align-center\">Feedbacks welcome!</h2>



<p>Receiving your feedback and suggestions for future versions of BuddyPress genuinely motivates and encourages our contributors. Please share&nbsp;your&nbsp;feedback about this version of BuddyPress in the comments area of this post. And of course, if you’ve found a bug: please tell us about it into our&nbsp;<a href=\"https://buddypress.org/support/\">Support forums</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 19:45:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WordPress.org blog: WP Briefing: Episode 10: Finding the Good In Disagreement\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/news/?post_type=podcast&p=10424\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wordpress.org/news/2021/06/episode-10-finding-the-good-in-disagreement/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12066:\"<p>To Agree, disagree, and everything in-between. In this episode, Josepha talks about forming opinions and decision-making in the WordPress project.</p>



<p><em><strong>Have a question you&#8217;d like answered? You can submit them to <a href=\"mailto:wpbriefing@wordpress.org\">wpbriefing@wordpress.org</a>, either written or as a voice recording.</strong></em></p>



<h2>Credits</h2>



<p>Editor:<a href=\"https://profiles.wordpress.org/dustinhartzler/\"> Dustin Hartzler</a></p>



<p>Logo:<a href=\"https://profiles.wordpress.org/beafialho/\"> Beatriz Fialho</a></p>



<p>Production:<a href=\"https://profiles.wordpress.org/mkaz/\"> </a><a href=\"https://profiles.wordpress.org/cbringmann/\">Chloé Bringmann</a></p>



<p>Song: Fearless First by Kevin MacLeod</p>



<h2>References</h2>



<p><a href=\"https://www.oprah.com/spirit/suzy-welchs-rule-of-10-10-10-decision-making-guide/all\">10/10/10 Rule</a></p>



<p><a href=\"https://en.wikipedia.org/wiki/Time_management#The_Eisenhower_Method\">The Eisenhower Matrix&nbsp;</a></p>



<p><a href=\"https://en.wikipedia.org/wiki/Minimax\">The Maximin Strategy&nbsp;</a></p>



<p><a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a></p>



<p><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></p>



<p><a href=\"https://make.wordpress.org/core/5-8/\">WordPress 5.8 Development Cycle</a></p>



<h2>Transcript</h2>



<span id=\"more-10424\"></span>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:10</p>



<p>Hello, everyone, and welcome to the WordPress Briefing, the podcast where you can catch quick explanations of some of the ideas behind the WordPress open source project and the community around it, as well as get a small list of big things coming up in the next two weeks. I&#8217;m your host, Joseph Haden Chomphosy. Here we go!</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>00:40</p>



<p>For anyone who has ever organized something, whether it&#8217;s a social event, a school project, or an annual family gathering, you know that there are many different opinions. The more opinions you have, the more likely people don&#8217;t see eye to eye. And before you know it, you&#8217;ve got some disagreements. Some things make disagreements worse, like imbalance of information, lack of showing your work, and sometimes just “too many cooks in the kitchen,” to use a regional phrase. Frankly, sometimes it seems like the second you have more than one cook in your kitchen, you&#8217;re going to get some disagreements. But I think that&#8217;s a healthy thing. WordPress is huge. And there are huge numbers of people contributing to WordPress or any other open source project you want to name. So there&#8217;s a lot of stuff available to disagree about. If we never saw anyone pointing out an area that wasn&#8217;t quite right, there would probably be something wrong. If you, like me, think that a healthy tension of collaborative disagreement can be useful when approached thoughtfully, then this quick start guide is for you.&nbsp;</p>



<p>Step one, prepare to host a discussion. This is, by the way, just the hardest step out there. You have to take a little time to figure out what problem you&#8217;re solving with the solution you&#8217;re suggesting, any goals that it relates to, and then figure out what the bare minimum best outcome would be and what the wildest dreams magic wand waving outcome would be. And you have to be honest with yourself.&nbsp;</p>



<p>Step two, host the discussion. The venue will be different for different discussions, but you see a lot of these on team blogs or within the actual tickets where work is being done. Wherever you&#8217;re hosting it, state the problem, state your idea for the solution and ask for what you missed. If you&#8217;re hosting a discussion in person, like in a town hall format, this can be hard. And generally, hosting discussions in an in-person or voice call or zoom call kind of way is hard. So if you have an opportunity to start doing this in text first and level your way up to in person, that&#8217;s my recommendation.&nbsp;</p>



<p>Step three is to summarize the discussion and post a decision if possible. So organizing a big discussion into main points is a really good practice for the people you&#8217;re summarizing it for and yourself. It helps you to confirm your understanding, and it also gives you the chance to pair other solutions with the problem and goals you outlined in step one. If a different solution solves the same problem but with less time or effort, it&#8217;s worth taking a second look with less time or effort. There’s something that I say to WordPress contributors frequently, and that is there are a lot of yeses. There are a lot of right ways to do things and only a few clear wrong ways to do things. So be open-minded about whether or not someone else&#8217;s right way to do things could still achieve the goals you&#8217;re trying to accomplish with your solution. A note on step three where I said, “and post the decision if possible.” Sometimes you&#8217;re the person to make that decision, but sometimes you are not the person who can give something the green light, and so you&#8217;re preparing a recommendation. Whether you&#8217;re making a decision or a recommendation, sometimes you may experience a little decision-making paralysis. I know I do. So here are a few of the tools that I use.</p>



<p>If you&#8217;re avoiding the decision, use the 10/10/10 rule; it can help you figure out if you&#8217;re stuck on a short-term problem. If there are too many good choices, use the Eisenhower Matrix that can help you to prioritize objectively. If there are too many bad choices, use the Maximin strategy. It can help you to identify how to minimize any potential negative impacts.&nbsp;</p>



<p>Okay, so you&#8217;ve considered your position. You’ve discussed everything. You summarized the big points. Maybe you also worked your way through to a recommendation or a decision. What about everyone who disagreed with the decision? Or have you made a recommendation, and it wasn&#8217;t accepted? How do you deal with that? That&#8217;s where “disagree and commit” shows up. This phrase was made popular by the folks over at Amazon, I think. But it first showed up, I believe at Sun Microsystems as this phrase, “agreeing, commit, disagree and commit or get out of the way.”</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>05:34</p>



<p>Disagree and commit as a concept works pretty well when everyone agrees on the vision and the goals, but not necessarily how to get to those goals. We&#8217;ve had moments in recent history where folks we&#8217;re not able to agree, we’re not able to commit, and so then left the project. I hate when that happens. I want people to thrive in this community for the entire length of their careers. But I also understand that situation shows up in the top five learnings of open source when you no longer have interest in the project and handed it off to a competent successor. So there it is &#8211; disagreements in open source in WordPress.&nbsp;</p>



<p>As with so many of the things I discuss on this podcast, this is incredibly complex and nuanced in practice. Taking an argument, distilling facts from feelings, and adjusting frames of reference until the solution is well informed and risk-balanced. That is a skill set unto itself. But one that increases the health of any organization. I’ll share that list of references and general materials in the show notes, including a link explaining each of those decision-making tools that I shared. I&#8217;m also going to include the contributor training module on decision-making in the WordPress project. It&#8217;s got excellent information. It&#8217;s part of a series of modules that I asked team reps to take and sponsored contributors. I don&#8217;t require it from anyone, but I do hope that it is useful for you. Also, speaking of useful for you, if you are just here for leadership insights, I included some hot takes after the outro music for you. It&#8217;s like an Easter egg, but I just told you about it.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>07:33</p>



<p>And that brings us to our small list of big things! First off, WordCamp Europe is happening this we; I hope that everybody has an opportunity to attend. If you still haven&#8217;t gotten your tickets, they are free, and I think there are still a few left. I will include a link in the show notes as well. There&#8217;s going to be a little demo with Matt Mullenweg and Matias Ventura on the WordPress 5.8 release that&#8217;s coming up. And then kind of a retrospective discussion between Matt and Brian Krogsgard. I encourage you to join; I think it&#8217;s going to be very interesting.&nbsp;</p>



<p>There&#8217;s also WordCamp, Japan coming up June 20 through 26th. I mentioned it last time &#8211;&nbsp; it has a big section of contributing and contribution time. So if you&#8217;re looking to get started, some projects are laid out, and I encourage you to take a look at that as well.&nbsp;</p>



<p>The new thing on this list, and I don&#8217;t know how new It is, in general, I hope it&#8217;s not too new to you, is that WordPress 5.8 release is reaching its beta one milestone on June 8th, so right in the middle of WordCamp Europe. I encourage every single theme developer, plugin developer that we have, agency owners that we have to really take a look at this release and dig into testing it. It&#8217;s a gigantic release. And I have so many questions about what will work and will not work once we get it into a broader testing area. We&#8217;ve been doing a lot of testing in the outreach program. But it&#8217;s always helpful to get people who are using WordPress daily in their jobs to really give a good solid test to the beta product to the beta package. And put it all through its paces for us.&nbsp;</p>



<p>So, that my friends, is your small list of big things. Thank you for tuning in today for the WordPress Briefing. I&#8217;m your host Josepha Haden Chomphosy, and I&#8217;ll see you again in a couple of weeks.</p>



<p><strong>Josepha Haden Chomphosy&nbsp; </strong>10:09</p>



<p>Hey there, you must be here because I told you about this totally not hidden easter egg about my hot takes on organizational health; I have three for you. And if you&#8217;ve ever worked with me, none of this will surprise you. But if you haven&#8217;t worked with me, hopefully, it kind of gives you some idea about how I approach all of this a bit differently. So, number one, critical feedback is the sign of a healthy organization. And I will never be dissuaded from that opinion. A complete lack of dissent doesn&#8217;t look like “alignment.” To me, that looks like fear. And it goes against the open source idea that many eyes make all bugs shallow.&nbsp;</p>



<p>Tip number two, a bit of tension is good, a bit of disagreement is good. The same thing that I say about women in tech, we&#8217;re not all the same. And if we were, then we wouldn&#8217;t need to collaborate anyway. But diversity, whether that&#8217;s the diversity of thought or of a person or of experience, just doesn&#8217;t happen without some misunderstandings. It&#8217;s how we choose to grow through those misunderstandings that make all the difference for the type of organization we are.&nbsp;</p>



<p>And hot take number three, changing your mind isn&#8217;t flip-flopping or hypocritical. I think that&#8217;s a sign of growth and willingness to hear others. I like to think of my embarrassment at past bad decisions &#8211; as the sore muscles of a learning brain. And I, again, probably won&#8217;t be dissuaded from that opinion. Although, you know, if I&#8217;m sticking true to changing your mind some flip-flopping or hypocritical, maybe I will, but you can always try to, to give me the counter-argument for that, and we&#8217;ll see how it goes. Thank you for joining me for my little public easter egg.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 07 Jun 2021 12:22:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Chloe Bringmann\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"Gutenberg Times: Themes for Full-Site Editing and Getting ready for WordPress 5.8 – Weekend Edition #172\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=18038\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://gutenbergtimes.com/themes-for-full-site-editing-and-getting-ready-for-wordpress-5-8-weekend-edition-172/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19490:\"<p>Howdy, </p>



<p>It&#8217;s the eve of the second virtual <a href=\"https://europe.wordcamp.org/2021/\"><strong>WordCamp Europe</strong></a>. Tickets are still available for another awesome three days with talks, workshops and contributor events. This year, the organizer decide to sprinkle contributor event into the rest of the schedule and have for all three days, a mix between techtalk, business talks and contributor presentation and discussions. There are quite a few events around the Block editor, Full-site-editing and block-based themes. <a href=\"https://gutenbergtimes.com/wordcamp-europe-2021-starts-monday/\">I compiled a list for you.</a> And just because I am so focused on Gutenberg, doesn&#8217;t mean you have to. ? <a href=\"https://europe.wordcamp.org/2021/schedule/\">Check out the schedule</a> and <a href=\"https://europe.wordcamp.org/2021/registration/\">get your tickets now</a>. </p>



<p>Hopefully, it will be the last virtual conference and we will see each other at an in-person WordCamp Europe in 2022. I am still hoping for Porto, Portugal.  At this state of withdrawal from meeting WordPress friends in person, it doesn&#8217;t matter where it will take place, thought. It&#8217;ll be a Hug-Fest. </p>



<p>Last week, I mentioned the next<a href=\"https://us02web.zoom.us/webinar/register/4216223029678/WN_gyOVb1h4S4iO_UZi1GMQaA\"> <strong>Gutenberg Times Live Q &amp; A</strong></a> in the subscribers-only section of this newsletter. Now we have a full panel. <a href=\"https://us02web.zoom.us/webinar/register/4216223029678/WN_gyOVb1h4S4iO_UZi1GMQaA\">Registration is officially open</a>. I am thrileed to host Daisy Olsen, Jeff Ong and Tammie Lister for our show on <strong>How to get started on Theme building for Full-site Editing and using the Theme.json file</strong> to configure your theme, and its interaction with the block editor. The Theme.json file will be introduced with the release of WordPress 5.8 in July 2021. <a href=\"https://us02web.zoom.us/webinar/register/4216223029678/WN_gyOVb1h4S4iO_UZi1GMQaA\">Get a head start and join us!</a></p>



<p><strong>Grzegorz (Greg) Ziolkowski</strong> will be back from vaction next week and we will record our next <strong>Changelog </strong>episode on Friday 11, 2021. I am so excited and can&#8217;t wait until Grzegorz is back!  If you have questions or suggestions or news, you want us to consider, hit reply or send them to <a href=\"mailto:changelog@gutenbergtimes.com\">changelog@gutenbergtimes.com</a>. We now have consitently 500 &#8211; 800 downloads per week. It&#8217;s humbling, mind-boggling and inspiring.  And if YOU are a listener, Thank You!  If you have a minute or two, <a href=\"https://lovethepodcast.com/gutenbergchangelog\">consider writing a review of the podcast</a>. We&#8217;d be grateful and might read it out loud on the next show. </p>



<p>Alright, that&#8217;s the news around Gutenberg Times. Below you&#8217;ll find what else happened in the Gutenberg universe. Enjoy! </p>



<p>Yours, ?<br />Birgit</p>



<p><em>PS: Hope to see you at WordCamp Europe. Don&#8217;t forget to join the #WCEU channel on WordPress Slack and meet speaker, sponsors, organizer and attendees like you and me. </em></p>





<hr class=\"wp-block-separator is-style-wide\" />



<h2>Full-Site-Editing &amp; Themes</h2>



<p><strong>Anne McCarthy</strong> published the <a href=\"https://make.wordpress.org/test/2021/06/02/fse-program-stick-the-landing-pages-summary/\"><strong>Stick the landing (pages) Summary</strong></a>. This post is a summary of the sixth call for testing for the experimental FSE outreach program, which also was translated into Italian to reach more of the non-English audience. Earlier calls were also translated into Japanese. The group of FSE testers is much bigger now, thanks to the persistent efforts by Anne to reach out to the community and stay on top of all the issues around the template editor. </p>



<p>A reminder: You can still join the the seventh call for testing:<a href=\"https://make.wordpress.org/test/2021/05/26/fse-program-testing-call-7-polished-portfolios/\"> </a><strong><a href=\"https://make.wordpress.org/test/2021/05/26/fse-program-testing-call-7-polished-portfolios/\">Polished Portfolios</a> </strong>&#8211; The deadline for your feedback was extended to June 16th, 2021. </p>



<p>If you read this before Sunday night, you can participate in the <a href=\"https://www.meetup.com/Philadelphia-WordPress-Meetup-Group/events/278507419/\"><strong>Full Site Editing Review and Test-a-thon </strong></a>Sunday, June 6th at  7 &#8211; 8:30 pm with the <strong>WordPress Meetup </strong>group in Philadelphia. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<p>Reading through the summary,  I am stuck on trying to understand the difference between a template built by the site-owner and a theme template. What will happen with their templates when the site-owner decides to change the overall theme of their site? There is still plenty to be figured out. <strong><a href=\"https://github.com/WordPress/gutenberg/pull/31971\">How edited block templates are linked to themes</a></strong> is topic of the discussion on GitHub. The Gutenberg team would appreciate some thoughts from folks familiar with these APIs (theme mods, performance, database).</p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong>Kjell Reigstad</strong> posted again acomprehensive list of issues and discussions regarding block-based themes and Full-Site Editing: <a href=\"https://make.wordpress.org/themes/2021/06/04/gutenberg-themes-week-of-may-31-2021/\"><strong>Gutenberg + Themes: Week of May 31, 2021</strong></a>. Any of the listed items are worth checking out and consider commenting. The more the team knows the better the next iteration of Full-Site editing and block-based themes becomes. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>WordPress 5.8 release preparations</h2>



<p>From the <a href=\"https://make.wordpress.org/core/2021/06/05/devchat-meeting-summary-june-2-2021/\">meeting notes of this week&#8217;s Dev Chat</a>: &#8220;Docs needs the most help with end user documentation. For block editor in particular. Some changes from 5.6 and 5.7 are still not published and we had a significant drop in number of contributors due to pandemic situation. Anyone interested in getting involved please&nbsp;ping <strong><a href=\"https://twitter.com/DjevaLoperka\">Milana Cap</a></strong>&nbsp;&nbsp;(<strong>zzap</strong>&nbsp;on&nbsp;Slack).&nbsp;</p>



<p>The summary of needed <strong><a href=\"https://github.com/WordPress/gutenberg/issues/32365\">DevNotes for new features in WordPress 5.8</a></strong> is available on GitHub and could use contributors. There is also a <a href=\"https://github.com/WordPress/gutenberg/pulls?q=is%3Apr+is%3Amerged+label%3A%22Needs+Dev+Note%22\">&#8220;needs dev note&#8221; label for pull requests</a>. </p>



<p>The widget screen could use some more testing. As a reminder, please read<strong> <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://make.wordpress.org/core/2021/05/12/help-test-the-widgets-editor-for-wordpress-5-8/\">Help Test the Widgets Editor for WordPress 5.8</a></strong> by <a href=\"https://twitter.com/andraganescu\"><strong>Andre Draganescu</strong></a></p>



<h2>Block Patterns</h2>



<p><strong>Hector Pietro</strong> wrote in his post <a href=\"https://make.wordpress.org/core/2021/06/04/whats-next-in-gutenberg-june-2021/\"><strong>What’s next in Gutenberg? (June 2021)</strong></a>: </p>



<p>&#8220;Since&nbsp;<a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/core/2021/05/27/whats-new-in-gutenberg-10-7-26-may/\" target=\"_blank\">Gutenberg 10.7</a>, block patterns displayed in the inserter are fetched from the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://wordpress.org/patterns/\" target=\"_blank\">WordPress.org Pattern Directory</a>. This opens the door to having a big amount of wonderful patterns available in the inserter, which will require&nbsp;<a rel=\"noreferrer noopener\" href=\"https://github.com/WordPress/gutenberg/issues/31153\" target=\"_blank\">iterating on the pattern insertion experience</a>. </p>



<p>For more updates on the Pattern Directory, stay tuned for&nbsp;<a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/meta/2021/04/28/block-pattern-directory-update/\" target=\"_blank\">Block Pattern Directory updates</a>&nbsp;and check the most recent&nbsp;<a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/design/tag/patterns-directory/\" target=\"_blank\">design iterations for the Pattern Directory</a>.&#8221;. </p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>Plugins for the Block Editor</h2>



<p><a href=\"https://wordpress.org/plugins/feature-box/\"><strong>Featured Box Plugin</strong></a> with this plugin &#8220;you can highlight a image with your key features&#8221; wrote <strong>Sumaiya Siddika</strong> on WordPress.org. <a href=\"https://wptavern.com/building-featured-boxes-with-the-wordpress-block-editor?utm_source=dlvr.it&utm_medium=twitter&utm_campaign=building-featured-boxes-with-the-wordpress-block-editor\">Justin Tadlock took it for a spin.</a></p>



<hr class=\"wp-block-separator is-style-wide\" />



<p><strong><a href=\"https://wordpress.org/plugins/jetformbuilder/\">JetFormBuilder — Form Builder plugin for Gutenberg</a></strong> from the plugins stable at CrocoBlock. The developers <a href=\"https://profiles.wordpress.org/mjhead/\">Andrey Shevchenko</a> and <a href=\"https://profiles.wordpress.org/hugreed/\">Oleksandr Ivanenko</a> also added an extensive Post action hook system that allows you to daisy chain actions and integrated with 3rd party systems. I haven&#8217;t tested it yet, but it looks promising. Crocoblock has been building plugins and tools for Elementor and has now started supporing Gutenberg with their products as well. </p>



<p>Another new plugin is the <a href=\"https://crocoblock.com/plugins/jetengine-gutenberg/\"><strong>JetEngine for Gutenberg</strong></a>  a dynamic content plugin that lets you build a complex websites fast and cost-effectively.</p>



<h2 id=\"fsethemes\">Themes for Full-Site Editing</h2>



<p>A few people ask about Themes that are already working with the Full-Site Editing system and Site Editor. So I put a list together of those I know about. Now before you use them, you need to be aware that they are all built while Full-Site Editing is still under active development, hasn&#8217;t been released yet and ergo many features are still experimental. Do not use in production or live site. </p>



<ul><li><a href=\"https://wordpress.org/themes/blockbase/\">Block Base</a> by Automattic</li><li><a href=\"https://wordpress.org/themes/naledi/\">Naledi </a>by Anariel Design </li><li><a href=\"https://wordpress.org/themes/tt1-blocks/\">TT1 Blocks</a> by WordPress contributors, the FSE sibling of the Twenty-Twenty-One Theme</li><li><a href=\"https://wordpress.org/themes/block-based-bosco/\">Block-Based Bosco</a> by Fränk Klein</li><li><a href=\"https://wordpress.org/themes/armando/\">Armando</a> by Carolyn Newmark</li><li><a href=\"https://wordpress.org/themes/q/\">Q </a>by Ari Stathopoulos</li><li><a href=\"https://wordpress.org/themes/hansen/\">Hansen</a> by Uxl Themes</li></ul>



<p>If you find any missing, let me know.</p>



<h2>Gutenberg related Business Updates</h2>



<p>This week&#8217;s big WordPress business news is the aquisition of <strong><a href=\"https://twitter.com/elliotcondon\">Eliots Condon</a></strong>&#8216;s plugin <strong><a href=\"https://www.advancedcustomfields.com/\">Advanced Custom Fields</a></strong> (ACF)  by Delicious Brains. With over more then 1 million active installs ACF is one of the widest used plugins. Thousands for developers depened on it in the <a href=\"https://www.advancedcustomfields.com/blog/10-years-of-acf-a-truly-wonderful-time/\">last ten years</a> to build complex WordPress sites. </p>



<blockquote class=\"wp-block-quote\"><p>Stepping away from ACF has not been an easy decision to make. The reasoning behind it comes from a place of humility. As the number of installs have grown from thousands to millions, the needs of the product have outgrown my ability to develop solutions. The last thing I want to do to this amazing community is unintentionally hold back the project, so something needed to change.</p><cite><a href=\"https://www.advancedcustomfields.com/blog/10-years-of-acf-a-truly-wonderful-time/\">Elliot Condon, ACF </a></cite></blockquote>



<p>Early on into the development of the block editor, Candon was also developing a<strong> <a href=\"https://wptavern.com/block-building-without-javascript-testing-acf-block-lab-and-lazy-blocks\">php way to build blocks</a></strong> and integrated it into Advanced Custom Fields Pro starting with the version 5.8. This effort certainly helped developers even more. Now they could use their existing tools and offer their users Gutenberg compatible sites withouth learning ES6 JavaScript or ReactJS. </p>



<p><strong><a href=\"https://deliciousbrains.com/\">Delicious Brains</a></strong> also caters to WordPress Developers with products like  <a href=\"https://spinupwp.com/\">SpinupWP</a> (?), WP Migrate DB and more. Their team seems to be the right fit to pick up the torch and put ACF on an even stronger path for future growth. </p>



<p>You can learn more about the aquisition via </p>



<ul><li><a href=\"https://wptavern.com/delicious-brains-acquires-advanced-custom-fields-plugin\">WPTavern (Sarah Gooding)</a>, </li><li><a href=\"https://poststatus.com/excerpt/12/\">Post Status Excerpt</a> (Cory Miller &amp; David Bisset) , </li><li><a href=\"https://deliciousbrains.com/epic-wordpress-announcement/\">A WordPress Announcement of Epic&nbsp;Proportions</a> (Delicious Brain) </li><li><a href=\"https://www.advancedcustomfields.com/blog/10-years-of-acf-a-truly-wonderful-time/\">10 Years of ACF – A truly wonderful time </a></li></ul>



<hr class=\"wp-block-separator is-style-wide\" />




<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-top is-image-fill has-background\"><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a><div class=\"wp-block-media-text__content\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong><br />on June 24, 2021 at 11am EDT / 15:00 UTC</p>



<p><strong>Theme.json for Theme Authors or building themes for full-site editing in WordPress.</strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olson, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>




<h2 id=\"events\">Upcoming WordPress Events</h2>



<p><strong>June 6, 2021</strong> <strong>7:00 pm EDT / 23:00 UTC</strong><br /><strong><a href=\"https://www.meetup.com/Philadelphia-WordPress-Meetup-Group/events/278507419/\">WordPress Meetup Philadelphia</a></strong><br />Full Site Editing Review and Test-a-thon</p>



<p><strong>June 7 &#8211; 9th, 2021</strong><br /><strong><a href=\"https://europe.wordcamp.org/2021/\">WordCamp Europe</a></strong><br />A virtual event and contributor day. <a href=\"https://europe.wordcamp.org/2021/call-for-sponsors/\">Call for sponsors is open.</a></p>



<p><strong>?</strong>  Gutenberg Times is a media partner of WordCamp Europe 2021 </p>



<p><strong>June 10th, 2021</strong><br /><strong><a href=\"https://www.meetup.com/SF-WordPress-Users/events/278491308\">WordPress &#8220;Mega Meetup&#8221;: Plugins That Keep Websites Running</a></strong></p>



<p><strong>June 20 &#8211; 26, 2021</strong><br /><strong><a href=\"https://japan.wordcamp.org/2021/\">WordCamp Japan</a></strong><br /><em>The schedule has been posted. Most sessions will be in Japanese, with exceptions, I think&#8230; </em></p>



<p><strong>June 24, 2021 </strong><br /><strong><a href=\"https://attend.wpengine.com/summit-us-2021/\">WPEngine Summit 2021</a></strong><br /><em>The digital breakthrough conference</em> <a href=\"https://events.wpengine.com/event/fd217870-fc78-46d2-8c5e-96c85e6e371c/websitePage:645d57e4-75eb-4769-b2c0-f201a0bfc6ce?environment=P2&tm=nSwmA1-ZyLXwe2wM80Vzve3wDjKBWeqKrHbJFivPV4o&locale=en-US\">just released their schedule</a>. Personally, I am very much looking forward to the Keynote talk with <strong>Reshma Saujani</strong>, founder of Girls Who Code and Marchall Plan for Moms at 12:55 EDT / 16:55 UTC.  I also hope to see talks with Rob Stinston, Carrie Dils and Chris Wiegman. There are also deep dive talks listed into Headless WordPress. Enterprise WordPress is definitely heading down that route. </p>



<p><strong>June 24 &#8211; 26, 2021</strong><br /><strong><a href=\"https://cochabamba.wordcamp.org/2021/\">WordCamp Cochabama</a></strong> (Colombia) </p>



<p><strong>July 17 + 18th, 2021</strong><br /><strong><a href=\"https://santaclarita.wordcamp.org/2021/\">WordCamp Santa Clarita</a></strong><br />Calls for speakers ends TODAY! </p>



<p><strong>July 23, 2021</strong><br /><a href=\"https://www.wordfest.live/\"><strong>WordFest Live </strong></a>&#8211; <em>The&nbsp;</em>festival of WordPress</p>



<p>A<strong>ugust 6 + 7, 2021</strong><br /><a href=\"https://nicaragua.wordcamp.org/2021/\"><strong>WordCamp Nicaragua</strong></a></p>



<p><strong>September 21 + 22, 2021</strong><br /><a href=\"https://2021.wpcampus.org/\"><strong>WPCampus 2021 Online</strong></a><br />&#8220;A free online conference for web accessibility and WordPress in higher education.&#8221;</p>



<hr class=\"wp-block-separator is-style-wide\" />



<p>On the<a href=\"https://wpcalendar.io/online/\"> <strong>Calendar for WordPress Online Events</strong> </a>you can browse a list of the upcoming WordPress Meetups, around the world, including WooCommerce, Elementor, Divi Builder and Beaver Builder meetups. </p>




<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-text-align-center\"><strong>Don&#8217;t want to miss the next Weekend Edition? </strong></p>



<form class=\"wp-block-newsletterglue-form ngl-form ngl-portrait\" action=\"https://gutenbergtimes.com/feed/\" method=\"post\"><div class=\"ngl-form-container\"><div class=\"ngl-form-field\"><label class=\"ngl-form-label\" for=\"ngl_email\">Type in your Email address to subscribe.</label><div class=\"ngl-form-input\"><input type=\"email\" class=\"ngl-form-input-text\" name=\"ngl_email\" id=\"ngl_email\" /></div></div><button class=\"ngl-form-button\">Subscribe</button><p class=\"ngl-form-text\">We hate spam, too and won&#8217;t give your email address to anyone except Mailchimp to send out our Weekend Edition</p></div><div class=\"ngl-message-overlay\"><div class=\"ngl-message-svg-wrap\"></div><div class=\"ngl-message-overlay-text\">Thanks for subscribing.</div></div><input type=\"hidden\" name=\"ngl_list_id\" id=\"ngl_list_id\" value=\"26f81bd8ae\" /><input type=\"hidden\" name=\"ngl_double_optin\" id=\"ngl_double_optin\" value=\"yes\" /></form>



<hr class=\"wp-block-separator is-style-wide\" />




<p>Featured Image: Photo by&nbsp;<a href=\"https://unsplash.com/@xavi_cabrera?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText\">Xavi Cabrera</a>&nbsp;on&nbsp;<a href=\"https://unsplash.com/s/photos/lego?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText\">Unsplash</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 05 Jun 2021 19:32:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Birgit Pauli-Haack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"Gutenberg Times: WordCamp Europe 2021 starts Monday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=17964\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://gutenbergtimes.com/wordcamp-europe-2021-starts-monday/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6936:\"<p>WordCamp Europe 2021 will be one of the largest virtual WordCamps again and the schedule has some great talks for every WordPress users, developers, site builders, theme designers, DIY site owners and content creators. </p>



<p>We looked through the schedule and spotted very forward-looking Gutenberg related talks, workshops and discussions. Before you study the list, I would recommend the site <a href=\"https://www.timeanddate.com/worldclock/converter.html\">Time Zone Converter</a> to help you convert the listed times from <strong>C</strong>entral <strong>E</strong>urope <strong>S</strong>ummer <strong>T</strong>ime (CEST) to your local time. Once in a while I get confused by time zones, and that&#8217;s my favorite site to set me straight. </p>



<div class=\"wp-block-image is-style-rounded\"><img /></div>



<p class=\"has-large-font-size\"><strong>Fabian Kägy, developer at 10up:  </strong><br /><strong><a href=\"https://europe.wordcamp.org/2021/session/building-great-experiences-in-the-new-editor/\">Building great experiences in the new editor</a></strong></p>



<p><strong>Description: </strong>Starting out building blocks or experiences for the WordPress block editor can be a bit daunting. Where do I start? Custom blocks, block patterns or just styling core blocks. In this talk, Kägy will walk through the different options and share the benefits and downsides of each while talking about overall good practices for building great editorial experiences.</p>



<p>As a sidenote: Almost exactly a year ago,  <a href=\"https://gutenbergtimes.com/tooling-using-create-block-scaffolding-and-3rd-party-templates/\">Fabian Kägy was a presenter at a Gutenberg Times Live Q &amp; A</a> together with Grzegorz Ziolkowski, and demo&#8217;d how you can use and extend the official WordPress create-block scaffolding tool. </p>



<p><strong>Monday, June 7th, 2021, at 10am EDT / 14:00 UTC / 16:00 CEST</strong></p>



<hr class=\"wp-block-separator is-style-wide\" />



<h2>Full-Site Editing Panel Discussion</h2>



<p>The names of the panelist are still a secret, and I will update the post when we know more. </p>



<p>If you&#8217;d like to get a jump start here are few resources: </p>



<ul><li><a href=\"https://gutenbergtimes.com/video-full-site-editing-overview-with-anne-mccarthy/\">Video: Full-Site Editing Overview with Anne McCarthy</a></li><li><a href=\"https://gutenbergtimes.com/full-site-editing/\">Full-Site-Editing – the Ultimate Resource List</a></li><li><a href=\"https://gutenbergtimes.com/so-you-want-to-talk-about-full-site-editing/\">So, You want to talk about Full-site Editing?</a></li></ul>



<p><strong>Monday, June 7, 2021 at 12:34 pm EDT / 16:34 UTC / CEST: 18:34</strong></p>



<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-large-font-size\">Workshop: <a href=\"https://europe.wordcamp.org/2021/session/a-walkthrough-of-full-site-editing-fse-from-one-of-the-contributors-to-the-experiment/\">A walkthrough of Full Site Editing</a> with Herb Miller, Web developer in UK,</p>



<div class=\"wp-block-image is-style-rounded\"><img /></div>



<p><strong>Description:</strong> Herb Miller will give a short tour of Full Site Editing (FSE) in this workshop from his perspective as a contributor to the outreach experiment for this major development in WordPress.</p>



<p>He has created a&nbsp;<a href=\"https://sneak-peek.me/\">learning resource</a>&nbsp;which attendees can use to follow on during the workshop.</p>



<p>Herb will give attendees an overview of:</p>



<ul><li>how to get started</li><li>the components of the Site Editor</li><li>example templates and template parts</li><li>some blocks used to create FSE themes</li><li>example themes</li><li>a very few code samples</li><li>some answers to FAQs</li><li>how to become involved</li><li>and many links to other resources</li></ul>



<p><strong>Tuesday, June 8th, 2021 11am EDT / 15:00 UTC / 17:00 CEST</strong></p>



<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-large-font-size\">Lee Shadle, web developer  <a href=\"https://europe.wordcamp.org/2021/session/blazing-fast-block-development/\">Blazing fast block development</a> </p>



<div class=\"wp-block-image is-style-rounded\"><img /></div>



<p>Lee Shadle wrote in his description: <em>&#8220;I’ve been OBSESSED w/ building blocks since before Gutenberg was released. I’ve built a BUNCH of custom block plugins over the years. In this workshop I’m going to share the framework I’ve been using for quickly building custom block plugins for WordPress.&#8221;</em>. Shadle recently also held a talk at WordSesh and demo&#8217;d his create-block-plugin scaffolding tool and it was inspiring. This is definitely not a talk to miss. </p>



<p><strong>Tuesday June 8, 2021 12:00 EDT / 16:00 UTC / 18:oo CEST</strong></p>



<hr class=\"wp-block-separator is-style-wide\" />



<p class=\"has-large-font-size\">The Future of Themes in WordPress</p>



<p>The future of themes will be a topic of this panel discussion. Stay tuned or follow WordCamp Europe on Social Media (<a href=\"https://twitter.com/WCEurope\">Twitter</a>, <a href=\"https://www.facebook.com/WCEurope/\">Facebook</a>, <a href=\"https://www.instagram.com/wceurope/\">Instagram</a>).</p>



<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-top is-image-fill has-background\"><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a><div class=\"wp-block-media-text__content\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong><br />on June 24, 2021 at 11am EDT / 15:00 UTC</p>



<p><strong>Theme.json for Theme Authors or building themes for full-site editing in WordPress.</strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olson, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>



<p></p>



<hr class=\"wp-block-separator is-style-wide\" />



<div class=\"wp-block-image is-style-rounded\"><img /></div>



<p class=\"has-large-font-size\">Conversation with Matt Mullenweg</p>



<p>Matt Mullenweg is the co-founder of WordPress and the CEO of Automattic. The conversation should be the highlight of the WordCamp Europe</p>



<p><strong>Wednesday, June 9th, 2021 &#8211; 11:42 EDT / 15:42 UTC /  17:42 CEST</strong></p>



<hr class=\"wp-block-separator is-style-wide\" />



<p>This edition of the WordCamp Europe also offers interesting Sponsor talks. Look for them <a href=\"https://europe.wordcamp.org/2021/schedule/\">on the schedule</a>, too.  </p>



<p class=\"has-text-align-center has-dark-gray-color has-text-color has-normal-font-size\"></p>



<img />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 05 Jun 2021 04:00:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Birgit Pauli-Haack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"Gutenberg Times: So, You want to talk about Full-site Editing?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://gutenbergtimes.com/?p=17970\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://gutenbergtimes.com/so-you-want-to-talk-about-full-site-editing/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:16846:\"<div class=\"wp-block-image is-style-rounded\"><img src=\"https://ca.slack-edge.com/T024MFP4J-U02S2V0TP-d1c0c67781e2-512\" alt=\"Anne McCarthy\" width=\"282\" height=\"282\" /><a href=\"https://nomad.blog\">Anne McCarthy writes at nomad.blog</a></div>



<p>As we’re nearing 5.8, there’s an increasing demand for people to speak about Full Site Editing and this post should help act as a resource guide to enable more people to do so. As always, I would love contributions from the wider community to build this out into an even more comprehensive resource! While this post covers a lot of content, see it as a go to place to mix and match as you’d like for your own presentation rather than something you need to know every detail of. For example, if you’re presenting to theme authors, you can use this to get a sense at a glance of what might be relevant from what to demo, what resources to share, what GitHub issues to highlight, and more.</p>



<div class=\"wp-block-sortabrilliant-guidepost\"><ul><li><a href=\"https://gutenbergtimes.com/feed/#0-resources\">Resources</a></li><li><a href=\"https://gutenbergtimes.com/feed/#1-key-points-to-cover-around-5-8\">Key points to cover around 5.8:</a></li><li><a href=\"https://gutenbergtimes.com/feed/#2-demo-ideas\">Demo ideas</a></li><li><a href=\"https://gutenbergtimes.com/feed/#3-helpful-git-hub-issues\">Helpful GitHub issues</a></li><li><a href=\"https://gutenbergtimes.com/feed/#4-helpful-posts\">Helpful Posts</a></li><li><a href=\"https://gutenbergtimes.com/feed/#5-conversation-starters\">Conversation Starters</a></li><li><a href=\"https://gutenbergtimes.com/feed/#6-fa-qs\">FAQs</a></li></ul></div>



<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-top is-image-fill has-background\"><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a><div class=\"wp-block-media-text__content\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong><br />on June 24, 2021 at 11am EDT / 15:00 UTC</p>



<p><strong>Theme.json for Theme Authors or building themes for full-site editing in WordPress.</strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olson, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>



<h2 id=\"0-resources\">Resources</h2>



<ul><li>Feel free to re-use or get inspiration from&nbsp;this&nbsp;<a href=\"https://href.li/?https://www.youtube.com/watch?v=aPPzATDkHzg\">FSE Overview</a>.</li><li>Pull from this&nbsp;<a href=\"https://href.li/?https://docs.google.com/document/d/1RGNG3HlB1HXPNXaFi50I56MIr1XHb9MiV3nc--MuBvs/edit\">working transcript for the above talks</a>.</li></ul>



<h2 id=\"1-key-points-to-cover-around-5-8\">Key points to cover around 5.8:</h2>



<ul><li>FSE&nbsp;is a collection of features and not a monolith.</li><li>Because FSE is a collection of features, Core can be flexible in shipping what is both stable and adds the most value.</li><li>5.8 is focused mainly on bringing tools to extenders with limited changes to the user experience. This includes theme.json, new theme blocks, design tools, and template editing mode.</li></ul>



<h2 id=\"2-demo-ideas\">Demo ideas</h2>



<p>Depending on who you are and who the audience, the following are your best bets for demo content:</p>



<ul><li>Block Theme building.&nbsp;<a href=\"https://profiles.wordpress.org/mkaz/\">@mkaz</a>&nbsp;has some&nbsp;<a href=\"https://href.li/?https://www.youtube.com/c/MarcusKazmierczak/videos\">great videos uploaded to YouTube</a>&nbsp;that you can check out and Carolina Nymark&nbsp;<a href=\"https://fullsiteediting.com/\">has this lovely site</a>.</li><li>Template Editing Mode.&nbsp;<a href=\"https://www.youtube.com/watch?v=Z571V_jlD-o&feature=youtu.be\">Here’s an overview video from yours</a>&nbsp;truly&nbsp;but keep in mind&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/pull/31461\">this in progress PR</a>&nbsp;that, if merged, would change the experience of editing a post/page inside template editing mode.</li><li>Explore blocks with a focus on the Navigation &amp;&nbsp;Query&nbsp;Blocks. Note that the Navigation Block is not planned for 5.8. You can see a list of blocks&nbsp;<a href=\"https://github.com/WordPress/gutenberg/blob/trunk/packages/block-library/src/index.js#L172-L192\">planned for inclusion here</a>.</li><li>Build a custom 404 page. You can&nbsp;<a href=\"https://href.li/?https://make.wordpress.org/test/2021/03/09/fse-program-testing-call-3-create-a-fun-custom-404-page/\">follow these instructions</a>&nbsp;to set up your demo.</li></ul>



<h2 id=\"3-helpful-git-hub-issues\">Helpful GitHub issues</h2>



<ul><li><a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/24551\">Site Editing Milestones</a>: to get a high level overview of how this work has been approached and where to follow along.</li><li>On plans for restricting access:&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/26573\">mapping features/functionality in order to update the UI</a>&nbsp;+&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/27597\">proposal for a robust permissions system with FSE</a>.</li><li>On types of pathways for classic themes:&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/28744\">Enabling FSE blocks in Classic Themes</a>,&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/theme-experiments/pull/209\">Experiment to add Customizer Color Controls to TT1</a>,&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/theme-experiments/pull/173\">Experiment using theme.json and Customizer</a>,&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/pull/30438\">Allow creating custom block templates in Classic themes</a>.</li><li>On the placement of the site editor experience:&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/29630#issuecomment-811617222\">Design and discussion exploring how best to finalize</a>&nbsp;the placement of FSE related features in wp-admin. This is a long term item to keep in mind as the Site Editor is not shipping in 5.8.</li><li><a href=\"https://github.com/WordPress/gutenberg/issues/32365\">Upcoming Dev Notes for 5.8</a>&nbsp;to get an early peak at what’s new.</li></ul>



<h2 id=\"4-helpful-posts\">Helpful Posts</h2>



<ul><li><a href=\"https://href.li/?https://make.wordpress.org/core/2020/05/20/ways-to-keep-up-with-full-site-editing-fse/\">Ways to keep up with FSE</a>&nbsp;so people can pick and choose their communication adventure.&nbsp;</li><li><a href=\"https://href.li/?https://make.wordpress.org/core/2021/02/01/full-site-editing-and-themes-where-things-are/\">Full Site Editing and Themes: where things are</a>&nbsp;from February 2021.</li><li><a href=\"https://href.li/?https://make.wordpress.org/test/handbook/full-site-editing-outreach-experiment/\">Full Site Editing Outreach Program</a>&nbsp;for those interested in helping to test and give feedback.&nbsp;</li><li><a href=\"https://href.li/?https://make.wordpress.org/test/tag/fse-answers/\">A recent series of questions and answers</a>&nbsp;about Full Site Editing from 2021.</li><li><a href=\"https://href.li/?https://www.youtube.com/watch?v=JHxsDSAImn0\">A great overview of FSE features</a>&nbsp;for non technical people.</li><li><a href=\"https://make.wordpress.org/core/2020/12/10/status-check-site-editing-and-customization/\">Status check on Site Editing and Customization</a>&nbsp;from December 2020 for a more historical perspective.</li><li><a href=\"https://href.li/?https://make.wordpress.org/core/2021/04/15/full-site-editing-go-no-go-april-14-2021/\">Go/No Go Recap post</a>: to show how decisions were made around this release.</li><li><a href=\"https://href.li/?https://make.wordpress.org/core/2021/04/20/full-site-editing-go-no-go-next-steps/\">Go/No Go Next Steps post</a>: to give greater context around what needs to happen for each feature to be properly considered for inclusion in 5.8.</li><li><a href=\"https://href.li/?https://make.wordpress.org/test/handbook/full-site-editing-outreach-experiment/\">Full Site Editing Outreach Program handbook page:</a>&nbsp;to highlight how people can get involved in giving feedback and improving FSE.</li><li><a href=\"https://href.li/?https://make.wordpress.org/test/handbook/full-site-editing-outreach-experiment/how-to-test-fse/\">How to Test FSE:</a>&nbsp;to give practical guidance around how to explore these features.</li><li><a href=\"https://href.li/?https://developer.wordpress.org/block-editor/how-to-guides/themes/block-theme-overview/\">Block Theme Documentation</a>: to help people get started with block theme creation.</li><li><a href=\"https://href.li/?https://developer.wordpress.org/block-editor/handbook/full-site-editing/\">Full Site Editing Documentation</a>: to give a high level overview of FSE and an entry point to learn more.</li><li><a href=\"https://href.li/?https://github.com/WordPress/theme-experiments\">Theme Experiments Repo</a>: to help people explore current approaches to block themes and various in progress experiments.</li><li><a href=\"https://href.li/?https://make.wordpress.org/themes/tags/gutenberg-themes-roundup/\">Gutenberg + Themes Roundups</a>: to help people stay up to date on happenings in&nbsp;Gutenberg&nbsp;that impact themes.</li><li><a href=\"https://href.li/?https://make.wordpress.org/themes/tags/meeting/\">Bi-monthly Block theme meeting</a>: to give people a chance to discuss the latest and greatest with block themes.</li><li><a href=\"https://make.wordpress.org/test/tag/fse-hallway-hangout/\">FSE Hallway Hangouts</a>: to hear from those working on and giving feedback on these features.</li></ul>



<h2 id=\"5-conversation-starters\">Conversation Starters</h2>



<ul><li>What would you like to see done as part of the&nbsp;<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/24551\">gradual adoption milestone</a>?&nbsp;</li><li>What would make you more inclined to use Full Site Editing? On the flip side, what would make you less inclined?&nbsp;</li><li>Are there any key people or resources like podcasts, courses, documentation, etc that have helped you explore Full Site Editing?&nbsp;</li><li>How do you think Full Site Editing will change the WordPress ecosystem? What excites you there? What makes you nervous?&nbsp;</li><li>What do you think is most helpful to communicate about Full Site Editing right now to put more people at ease and build excitement?&nbsp;</li><li>What are you still confused about when it comes to Full Site Editing?</li></ul>



<h2 id=\"6-fa-qs\">FAQs</h2>



<p>These are the top questions you can most likely expect to get asked with high level answers to get you started in the right direction. For a more comprehensive list of questions and answers,&nbsp;<a href=\"https://href.li/?https://make.wordpress.org/test/tag/fse-answers/\">check out the FSE Outreach Program’s roundups</a>.</p>



<div class=\"schema-faq wp-block-yoast-faq-block\"><div class=\"schema-faq-section\" id=\"faq-question-1622843349108\"><strong class=\"schema-faq-question\">What is Full Site Editing and what value will it bring?</strong> <p class=\"schema-faq-answer\">Full Site Editing is a collection of features that bring the familiar experience and extendability of blocks to all parts of your site rather than just post and pages. In terms of value, it depends on who you are:<br />User: empowerment to customize what you want to your liking without needing to dive into code.<br />Themer/developer: focus less on coding thanks to various design tools and more on creating a compelling experience with your theme.<br />Agency: greater control and consistency over what you offer clients including things like setting custom branding colors or locking down various aspects of the site such as typography settings.<br />When you see or feel this value depends on who you are, how early you adopt features, and when stable features land in Core. Thanks to FSE being a collection of features, some independent and some interdependent, there’s wonderful room to ship what’s stable.</p> </div> <div class=\"schema-faq-section\" id=\"faq-question-1622843371957\"><strong class=\"schema-faq-question\">What is going to happen to themes and what kinds of pathways are being created?</strong> <p class=\"schema-faq-answer\">In the long run, it should make theme development much easier and simpler with design tools ready to tap into allowing theme authors to focus less on coding and functions and more on design expression and aesthetics. Because Full Site Editing requires a block based theme, this makes themes extremely important to get right! As a result, lots of pathways are being created including the ability to use theme blocks in a classic theme, exploring how to use the customizer and site editor as part of a “universal theme”, unlocking the ability to create a new block template in a classic theme, allowing classic themes to adopt the block widget editor, and more.<br />Key: Themes are a key part of the FSE experience, lots of work is being done to allow for a breadth of options going forward, and we need feedback from theme authors to make the transition easier. </p> </div> <div class=\"schema-faq-section\" id=\"faq-question-1622843448534\"><strong class=\"schema-faq-question\">What about page builders/site builders?</strong> <p class=\"schema-faq-answer\">FSE is being built in a way that site builders, if they choose to, can build on top of what’s being created. Overall though, FSE is being built partially so people don’t get locked into one site builder over another. While the goals shared between FSE and site builders are similar in terms of empowering users and give better tools to customize a site, the main difference is that we are developing tools that work for users, themers, and hopefully also page builders by expanding how WordPress uses blocks as a whole. Since Core has to strike a nice balance, it’s expected that future plugins will play a role here in exposing more/less depending on user needs.</p> </div> <div class=\"schema-faq-section\" id=\"faq-question-1622843480900\"><strong class=\"schema-faq-question\">How will restricting access to these features work?</strong> <p class=\"schema-faq-answer\">This will depend on who is asking the question (a user, a theme author, a developer, etc) but some of the GitHub issues referenced above should help. For users, I’d focus on the fact that they would either need to seek out a block theme to use or their current theme would need to ship specific updates. For a themer/developer, I’d share that there will be various options to opt in and out of this work (<a href=\"https://href.li/?https://github.com/WordPress/gutenberg/issues/27814#issuecomment-823921386\">for example with creating block templates</a>). Upcoming <a href=\"https://github.com/WordPress/gutenberg/issues/32365\">5.8 dev notes</a> should address this for any new features.</p> </div> <div class=\"schema-faq-section\" id=\"faq-question-1622843499287\"><strong class=\"schema-faq-question\">Will upgrading to 5.8 cause FSE to take over my site like the Core Editor did in 5.0?</strong> <p class=\"schema-faq-answer\">No. 5.8 is focused on giving tools to extenders first and foremost before more user facing changes are launched going forward and integrated into themes. In terms of user facing features, you can expect to see</p> </div> </div>



<p><em><a href=\"https://nomad.blog/2021/06/02/so-you-want-to-talk-about-full-site-editing/\">Anne McCarthy published this post on her personal blog</a> and gave us permission to republish it here as well.</em></p>



<div class=\"wp-block-media-text alignfull is-stacked-on-mobile is-vertically-aligned-top is-image-fill has-background\"><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\"><img /></a><div class=\"wp-block-media-text__content\">
<p class=\"has-normal-font-size\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Join us for our next Live Q &amp; A</a> </strong><br />on June 24, 2021 at 11am EDT / 15:00 UTC</p>



<p><strong>Theme.json for Theme Authors or building themes for full-site editing in WordPress.</strong><br /><strong>Host</strong>: Birgit Pauli-Haack<br /><strong>Panel:</strong>&nbsp;Daily Olson, Tammie Lister and Jeff Ong           <span class=\"has-inline-color\"><strong><a href=\"https://us02web.zoom.us/webinar/register/8816229019893/WN_gyOVb1h4S4iO_UZi1GMQaA\">Register Now</a></strong></span></p>
</div></div>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 05 Jun 2021 00:50:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Anne McCarthy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Jetpack 9.8 Introduces WordPress Stories Block Alongside Forced Security Update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117820\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:223:\"https://wptavern.com/jetpack-9-8-introduces-wordpress-stories-block-alongside-forced-security-update?utm_source=rss&utm_medium=rss&utm_campaign=jetpack-9-8-introduces-wordpress-stories-block-alongside-forced-security-update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6610:\"<p><a href=\"https://jetpack.com/2021/06/01/jetpack-9-8-engage-your-audience-with-wordpress-stories/\">Jetpack 9.8</a> was released this week, introducing WordPress&nbsp;Stories as the headline feature. The Story block, which allows users to create interactive stories, was previously only available on mobile. It can now be used in the web editor. Stories went into <a href=\"https://wptavern.com/wordpress-for-android-previews-new-story-posts-feature-now-in-public-beta\">public beta on the Android app</a> in January 2021, and were officially <a href=\"https://wptavern.com/wordpress-com-and-jetpack-adds-story-block-for-mobile-apps\">released</a> on the mobile apps in March.</p>



<p>Version 9.8 also included a security patch for all sites using the Carousel feature. The <a href=\"https://wpscan.com/vulnerability/08a8a51c-49d3-4bce-b7e0-e365af1d8f33\">vulnerability</a> allowed the comments of non-published pages/posts to be leaked. It was severe enough for the Jetpack team to work with WordPress.org to release 78 patched versions &ndash; every version of Jetpack since 2.0. Sites not using the Carousel feature were not vulnerable but could be in the future if it was enabled and left unpatched. </p>



<p>In a rare move, WordPress.org pushed a forced update to all vulnerable versions, surprising those who have auto-updates disabled. Several Jetpack users posted in the support forums, asking why the plugin had <a href=\"https://wordpress.org/support/topic/jetpack-updated-without-permission/\">updated automatically without permission</a> and in some cases not to the newest version.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">So this update was a forced update on WordPress sites even with auto-updates disabled? <br /><br />We had this go live on a prod site at 2am last night that has auto-updates disabled for very specific reasons. <br /><br />Not cool Jetpack. <a href=\"https://t.co/55upBmyeHp\">https://t.co/55upBmyeHp</a></p>&mdash; Brad Williams (@williamsba) <a href=\"https://twitter.com/williamsba/status/1400498727991787521?ref_src=twsrc%5Etfw\">June 3, 2021</a></blockquote>
</div>



<p>Jetpack team member Jeremy Herve said the vulnerability was responsibly disclosed via Hackerone, allowing them to work on a patch for the issue. After it was ready to go, the Jetpack team reached out to the <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wordpress.org/\">WordPress.org</a>&nbsp;security team to inform them of a vulnerability impacting multiple versions of the plugin.</p>



<p>&ldquo;We sent them the patch alongside all the info we had (a PoC for the vulnerability, what features had to be active, what versions of Jetpack were impacted),&rdquo; Herve said. &ldquo;They recommended we release point releases for older versions of Jetpack as well.</p>



<p>&ldquo;We created those new releases, and when we were ready to release them, someone from the&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wordpress.org/\">WordPress.org</a>&nbsp;team made some changes on the&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wordpress.org/\">WordPress.org</a>&nbsp;side so folks running old, vulnerable versions of the plugin would get auto-updated, just like it works for Core versions of WordPress.&rdquo;</p>



<p>Jetpack team member Brandon Kraft estimated the number of vulnerable sites at 18% of the plugin&rsquo;s active installs. He said that Jetpack was not part of the discussion about the pushing out a forced update.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">We weren\'t part of the discussion. Provided details and got the response, but I wouldn\'t expect a security convo to be public. But, yes. Single feature impacted. A few things need to be all true for it to matter on a site, which looked like qualified about 18% of sites IIRC.</p>&mdash; A Guy Called Kraft &#128567;&#128137; (@Kraft) <a href=\"https://twitter.com/Kraft/status/1400545471165304839?ref_src=twsrc%5Etfw\">June 3, 2021</a></blockquote>
</div>



<p>&ldquo;What probably adds to the confusion is that WordPress 5.5 added a UI for plugin (and theme) autoupdates,&rdquo; Herve said. &ldquo;That UI, while helping one manage plugin autoupdates on their site, is a bit different from Core&rsquo;s forced update process. Both of those update types can be deactivated by site owners, just like core&rsquo;s autoupdates can be deactivated, but I don&rsquo;t believe (and honestly wouldn&rsquo;t recommend) that many folks deactivate those updates.&rdquo;</p>



<p>Brandon Kraft dug deeper into the topic and published a <a href=\"https://kraft.blog/2021/06/automatic-updates-in-wordpress/\">post</a> that explains the differences between auto-updates and forced updates. It includes how to lock down file modifications if you don&rsquo;t want to receive any forced updates in the future. Forced updates, however, are exceedingly rare, and Kraft counts only three for Jetpack since 2013.</p>



<p>In this instance, the Jetpack team followed the <a href=\"https://developer.wordpress.org/plugins/wordpress-org/plugin-security/#automatic-plugin-security-updates\">official process for reporting a critical vulnerability</a> to the plugin and security teams who determine the impact for users based on a set criteria. Users who received an email notification about an automatic update from Jetpack, despite having the UI in the dashboard set to disable them, should be aware that these forced updates can come once in a blue moon for security purposes. </p>



<p><a href=\"https://perezbox.com/\">Tony Perez</a>, founder of NOC and former CEO at Sucuri, <a href=\"https://noc.org/2021/06/03/automattics-jetpack-plugin-for-wordpress-abuses-user-defined-settings-calls-into-question-auto-updates/\">contends</a> that forcing a security update like this violates the intent users&rsquo; assign when using the auto-updates UI in WordPress. He highlighted the potential for abuse if the system were to become vulnerable to a bad actor.</p>



<p>&ldquo;The platform is making an active decision that is arguably contrary to what the site administrator is intending when they explicitly say they don&rsquo;t want something done,&rdquo; Perez said. &ldquo;Put plainly, it&rsquo;s an abuse of trust that exists between the WordPress user and the Foundation that helps maintain the project.</p>



<p>&ldquo;My position is not that it shouldn&rsquo;t exist. That&rsquo;s a much deeper ideological debate, but it is about respecting an administrators explicit intent.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 05 Jun 2021 00:04:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: Create Per-Post Social Media Images With the Social Image Generator WordPress Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"https://wptavern.com/create-per-post-social-media-images-with-the-social-image-generator-wordpress-plugin?utm_source=rss&utm_medium=rss&utm_campaign=create-per-post-social-media-images-with-the-social-image-generator-wordpress-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6689:\"<img />



<p class=\"has-drop-cap\">It was a bit of a low-key announcement when Daniel Post introduced <a href=\"https://socialimagegenerator.com/\">Social Image Generator</a> to the world in February <a href=\"https://twitter.com/danielpost/status/1357680161546764293\">via tweet</a>. But, when you get <a href=\"https://css-tricks.com/auto-generated-social-media-images/\">repped by Chris Coyier</a> of CSS-Tricks and the co-founder of WordPress <a href=\"https://twitter.com/photomatt/status/1398044870489657345\">uses your plugin</a> (come on, Matt, set a default image), it means your product is on the right track.</p>



<p>I am not easily impressed by every new plugin to fly across my metaphorical desk. I probably install at least a couple dozen every week. Sometimes, I do so because something looks handy on the surface, and I want to see if I can find some use for it. Other times, I think it might be worth sharing with Tavern readers. More often than not, I consider most of them cringeworthy. I have high standards.</p>



<p>As I chatted with Post about this new plugin, I was excited enough to call Social Image Generator one of those <em>OMG-where-have-you-been?</em> types of plugins. You will not hear that from me often.</p>



<p>Post quit his day job to venture out earlier this year, creating his one-man WordPress agency named <a href=\"https://posty.studio/\">Posty Studio</a>. Social Image Generator is its first product.</p>



<p>&ldquo;I kept seeing tutorials on my Twitter feed on how to automatically generate images for your social media posts, but unfortunately, they all used a similar approach (Node.js) that just wasn&rsquo;t suitable for WordPress,&rdquo; said Post of the inspiration for the plugin. &ldquo;This got me thinking: would it be possible to make this for WordPress? I started playing around with image generation in PHP, and when I got my proof of concept working, I realized that this might actually be something I should pursue.&rdquo;</p>



<p>In our chat over Slack, we actually saw the plugin in action. As he shared Coyier&rsquo;s article from CSS-Tricks, the chatting platform displayed the social image in real-time.</p>



<img />Auto-generated image appearing via Slack.



<p>Maybe it was fate. Maybe Post knew it would happen and thought it would be a good idea to show off his work as we talked about his project. Either way, it was enough to impress the writer who is unafraid to call your plugin a dumpster fire if he smells smoke.</p>



<p>Post seems to be hitting all the right notes with this commercial plugin. It has a slew of features built into version 1.x, which we will get to shortly. It is dead simple to use. It is something nearly any website owner needs, assuming they want to share their content via social networks. And, with a <a href=\"https://socialimagegenerator.com/#pricing\">$39/year starting price</a>, it is not an overly expensive product for those on the fence about buying.</p>



<h2>How the Plugin Works</h2>



<p class=\"has-drop-cap\">After installing and activating Social Image Generator, users are taken to the plugin&rsquo;s settings screen. Other than a license key field and a button for clearing the image cache, most users will want to dive straight into the template editor.</p>



<p>At the moment, the plugin includes 23 templates. From Twenty Seventeen to Twenty Twenty-One, each of the last four default WordPress themes also has a dedicated template. After selecting one, users can customize the colors for the logo, post title, and more &mdash; the amount of customization depends on the chosen template.</p>



<img />Browsing the plugin&rsquo;s templates.



<p>Aside from selecting colors, users can choose between various logo and text options. They can also upload a default image for posts without featured images.</p>



<img />Editing a template from Social Image Generator.



<p>When it comes time to publish, the plugin adds a meta box to the post sidebar. Users can further customize their social image and text on a per-post basis.</p>



<img />Social image preview box on the post-editing screen.



<p>Once published, the plugin creates an image that will appear when a post is shared on social media.</p>



<p>On the whole, there is a ton that anyone can do with the built-in templates. There is also an API for developers to create their own. For a first outing, it is a robust offering. However, there is so much more that can be done to make the plugin more flexible.</p>



<h2>Version 2.0 and Beyond</h2>



<p class=\"has-drop-cap\">Thus far, Post said he has received tons of positive feedback along with feature requests. Primarily, users are asking for more customization options and the ability to create and use multiple templates. These are the focus areas for the next version. With a 1,718% increase in revenue in the past month, it seems he might have the initial financial backing to invest in them.</p>



<p>&ldquo;I&rsquo;ve started building a completely <a href=\"https://twitter.com/danielpost/status/1390316805596590083\">overhauled drag-n-drop editor</a>, which will allow you to create basically any custom image you want,&rdquo; he said. &ldquo;It will be heavily inspired by the block editor, and I want to keep the UI and UX as close to the block editor as possible.&rdquo;</p>



<p>The new template editor would allow users to create multiple layers, an idea similar to how Photoshop, Gimp, and other image-editing software works. The difference would be that it can pull in data from WordPress.</p>



<p>&ldquo;For example, an &lsquo;Image&rsquo; layer will have options such as height/width and positioning, as well as some stylistic options like color filters and gradient overlays,&rdquo; said Post. &ldquo;A &lsquo;Text&rsquo; layer can be any font, color, and size and can show predefined options (post title, date, etc.) or whatever you want. You can add an infinite number of layers and order them however you&rsquo;d like.&rdquo;</p>



<p>He seems excited about opening up new possibilities with an overhauled editor. Users could potentially create social image templates for each post type. A custom layer might pull in post metadata, such as displaying product pricing or ratings from eCommerce plugins like WooCommerce.</p>



<p>&ldquo;The prebuilt templates will still exist, similar to Block Patterns in the block editor,&rdquo; said the plugin developer. &ldquo;They will, however, serve as a starting point rather than the final product. I&rsquo;ll also try to implement theme styling as much as possible.</p>



<p>&ldquo;The possibilities here are so endless, and I&rsquo;m incredibly excited for this next part.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Jun 2021 23:59:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Building Featured Boxes With the WordPress Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117803\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:175:\"https://wptavern.com/building-featured-boxes-with-the-wordpress-block-editor?utm_source=rss&utm_medium=rss&utm_campaign=building-featured-boxes-with-the-wordpress-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6333:\"<p class=\"has-drop-cap\">It is a new day with another chase for that elusive block plugin that will bring a little joy into my life. Today&rsquo;s experiment comes courtesy of the <a href=\"https://wordpress.org/plugins/feature-box/\">Feature Box plugin</a> by Sumaiya Siddika. It is a simple block that allows end-users to upload an image and add some content to an offset box.</p>



<p>The plugin&rsquo;s output is a typical pattern on the web. As usual, I am excited to see plugin authors experimenting with bringing these features to WordPress users. I want to see more of it, especially from first-time plugin contributors.</p>



<p>I was able to quickly get the block up and running, adding my custom content. The following is what the block looked like after entering my content and customizing it. <em>I envisioned myself as a recipe blogger for this test.</em></p>



<img />Inserting and modifying the Feature Box block.



<p>On a technical level, the plugin worked well. I ran into no errors. Everything was simple to customize. However, it never felt like an ideal user experience.</p>



<p>The first thing I immediately noticed is that image uploading happens in the block options sidebar. Core WordPress blocks have a dedicated button in the toolbar for adding images and other media. I also found myself wanting more direct control over individual elements. <em>How could I change the heading font size? Where were the typical button styles like Outline and Solid Color? How do I insert other blocks, like a list?</em></p>



<p>None of those things were possible. Like many other blocks, the developer has created a system with specific parameters, and the user cannot move outside of them. There are times when that rigidity makes sense, such as when building custom blocks for clients. However, more often than not, publicly-released plugins should be far more open.</p>



<p>This tightly controlled block is reflective of how WordPress worked in the past. It was often inflexible, leaving users to what theme and plugin developers thought was best for their sites.</p>



<p>The block system is about tossing out these overly rigid concepts and giving users power over their content. The job of plugins and themes is to define the framework the user is operating under. They set up some rules to more or less keep things from breaking, but the users get to strap themselves into the driver&rsquo;s seat. Their destination is their own.</p>



<p>The block would have been far more well-rounded if users could control all of the content in the box. Ideally, they could put whatever blocks they wanted into the &ldquo;content&rdquo; area of the Feature Box block. The design would match their theme better too.</p>



<p>A couple of weeks ago, I wrote a post titled <a href=\"https://wptavern.com/you-might-not-need-that-block\">You Might Not Need That Block</a>. The premise was that users could recreate some blocks with the current editor and that themers could make this easier by offering patterns.</p>



<p>I knew replicating this particular block would be impossible without at least a little custom code. WordPress&rsquo;s editor does not have a feature for offsetting a block&rsquo;s position.</p>



<p>A theme author could easily duplicate this functionality. Typically, I would create a custom pattern, complete with all the existing pieces in place. However, I wanted to approach this with custom block styles. This would allow end-users to select the content offset from the sidebar and switch it around if needed.</p>



<p class=\"is-style-default\"><strong>Note:</strong> For those who wish to learn how to create custom block styles, Carolina Nymark&rsquo;s <a href=\"https://fullsiteediting.com/lessons/custom-block-styles/\">tutorial</a> is the best resource.</p>



<p>The Cover block made an ideal candidate for this. Because it has an existing &ldquo;inner wrapper&rdquo; element, it meant that I could target it with CSS and move it around. The following is a screenshot of the Offset Left style I created:</p>



<img />Offset Left Cover block style.



<p>I simply replicated the code and changed a few values to create an Offset Right style immediately after. The code is available as a <a href=\"https://gist.github.com/justintadlock/70180c2019f1e2dbdda96ee263610671\">GitHub Gist</a>.  It is a simple proof-of-concept and not a polished product.  There are various approaches to this, and several Cover block options are left unhandled.  Theme authors are free to take the code and run with it.</p>



<p>These block styles looked far better because they matched my theme. Everything from the spacing to the border-radius to the button looked as it should.</p>



<ul><li class=\"blocks-gallery-item\"><img /></li><li class=\"blocks-gallery-item\"><img /></li></ul>Offset Left and Right block styles.



<p>The big win was that I had design control over every aspect of the content box. I could select the button style I wanted. I could change my font sizes. The default spacing matched my theme as it should.</p>



<p>The problem I ran into with the block style method is allowing users to control the content box&rsquo;s background color. The Feature Box plugin wins in the user experience category here because it has an option for this. The block style I created inherits its background from the Cover block parent. It may not be immediately obvious how to change it.</p>



<p>The other &ldquo;problem&rdquo; with the block style is that it does not handle wide and full alignments for the Cover block. That is because I did not take the experiment that far, only replicating the plugin&rsquo;s layout. I will leave that to theme designers to tinker around with. There are many possibilities to explore; <em>don&rsquo;t wait for me to provide all the ideas</em>.</p>



<p>My goal with this post and similar ones is to show how I would approach these things as both a user and developer. As a user, I want flexibility in all things. As a developer, I want to provide the solutions that I desire as a user.</p>



<p>I also want to see plugin and theme authors thinking beyond their initial use case when building blocks, patterns, styles, and more. Lay the groundwork. Then, expand on that initial idea by thinking of all the ways that users might want to customize what you have built.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Jun 2021 05:07:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Delicious Brains Acquires Advanced Custom Fields Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=117769\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:175:\"https://wptavern.com/delicious-brains-acquires-advanced-custom-fields-plugin?utm_source=rss&utm_medium=rss&utm_campaign=delicious-brains-acquires-advanced-custom-fields-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4240:\"<p><a href=\"https://deliciousbrains.com/\">Delicious Brains</a>, the company behind <a href=\"https://deliciousbrains.com/wp-migrate-db-pro/\">WP Migrate DB Pro</a> and <a href=\"https://spinupwp.com/\">SpinupWP</a>, has <a href=\"https://www.advancedcustomfields.com/blog/10-years-of-acf-a-truly-wonderful-time/\">acquired</a> the <a href=\"https://wordpress.org/plugins/advanced-custom-fields/\">Advanced Custom Fields</a> (ACF) plugin from its creator, Elliot Condon. After 10 years, the plugin has more than 1 million active installs and a thriving business based on the Pro version. It has become an indispensable part of the workflow for thousands of WordPress developers around the globe.</p>



<p>The plugin allows developers to easily customize WordPress edit screens and custom field data. In 2019, the Pro version <a href=\"https://wptavern.com/advanced-custom-fields-5-8-0-introduces-acf-blocks-a-php-framework-for-creating-gutenberg-blocks\">introduced ACF Blocks</a>, a PHP-based framework for developing custom blocks. This came as a great relief to many developers who did not know how they were going to keep pace with learning the JavaScript required to use WordPress&rsquo; Block API.</p>



<p>General reaction to the news was positive, as ACF fits in neatly with Delicious Brains&rsquo; suite of well-maintained developer products. The company&rsquo;s founders also possess a genuine appreciation of ACF and its importance to the WordPress developer community.</p>



<p>&ldquo;I don&rsquo;t think WordPress would be where it is today without ACF,&rdquo; Brad Touesnard said on a recent <a href=\"https://delicious-brains.castos.com/episodes/episode-5-a-wordpress-announcement-of-epic-proportions/\">episode</a> of the Delicious Brain Waves podcast.</p>



<p>Condon cited the scale of the project and &ldquo;technology complexity and user expectation&rdquo; as factors in his decision to sell ACF. As a one-person team, he was unable to keep up with the growth of ACF over the years.</p>



<p>&ldquo;Stepping away from ACF has not been an easy decision to make,&rdquo; Condon said. &ldquo;The reasoning behind it comes from a place of humility. As the number of installs have grown from thousands to millions, the needs of the product have outgrown my ability to develop solutions. The last thing I want to do to this amazing community is unintentionally hold back the project, so something needed to change.&rdquo;</p>



<p>Delicious Brains&rsquo; announcement stated that the company will be reviewing Condon&rsquo;s roadmap for the product in hopes of fulfilling his vision moving forward.</p>



<p>&ldquo;Two of our greatest strengths that we&rsquo;ll bring to ACF are design (UI/UX) and developer education,&rdquo; Touesnard said. &ldquo;We&rsquo;ll be focusing our initial efforts in those areas. I have a few UI/UX improvements in mind that would make a huge difference to users. We also see a significant opportunity to produce developer-focused content focused on effectively using ACF in your WordPress projects.&rdquo;</p>



<p>Touesnard also confirmed that Delicious Brains will not be making any drastic changes to ACF or ACF Pro, nor do they plan to adjust the pricing of the product anytime soon. </p>



<p>&ldquo;If we ever decide to update pricing in the future, we won&rsquo;t force existing customers onto the new pricing,&rdquo; he said.</p>



<p>After the initial announcement, there was some <a href=\"https://twitter.com/bradt/status/1400488841123930114\">confusion surrounding lifetime licenses</a> that originated from a hasty response to a customer inquiry. Delicious Brains has since updated the post to clarify the company&rsquo;s commitment to ACF Pro&rsquo;s lifetime customers.</p>



<p>&ldquo;We are committed to honoring lifetime licenses forever,&rdquo; Touesnard said. &ldquo;Lifetime license holders will get&nbsp;<strong>all</strong>&nbsp;ACF Pro software updates forever.&rdquo;</p>



<p>More information on how the acquisition happened, as well as what customers can expect in the future, is available on the most recent <a href=\"https://delicious-brains.castos.com/episodes/episode-5-a-wordpress-announcement-of-epic-proportions/\">episode of the Delicious Brain Waves podcast</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 04 Jun 2021 03:35:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WordPress.org blog: A New Design is Coming to WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"https://wordpress.org/news/?p=10418\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2021/06/a-new-design-is-coming-to-wordpress-news/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1152:\"<p>After many years of a tidy, white-space filled design on WordPress.org/news it&#8217;s time to bring new life to the way we present our content. So much has changed since this site was first created: the people who read it, the type and variety of what is published, even the way WordPress works has changed.</p>



<p>Which means it makes sense to change our theme. </p>



<p>Earlier this year, Matt requested a new design from Beatriz Fialho (who also created the State of the Word slides for 2020). The design keeps a clean, white-space friendly format while incorporating a more jazzy, playful feeling with a refreshed color palette. </p>



<img width=\"632\" height=\"449\" src=\"https://i0.wp.com/wordpress.org/news/files/2021/06/25-1024x728-1.png?resize=632%2C449&ssl=1\" alt=\"\" class=\"wp-image-10420\" />



<p>More detail on this modern exploration have been posted on <a href=\"https://make.wordpress.org/design/2021/06/03/redesign-of-wordpress-org-news/\">make.wordpress.org/design</a>. I encourage you to stop by and read more about the thoughts behind the coming updates; and keep an eye out for the new look here and across WordPress.org!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 03 Jun 2021 20:47:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 26 Jun 2021 02:14:26 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Sat, 26 Jun 2021 02:00:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20201016115008\";}","no"),
("184","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1624716867","no"),
("185","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1624673667","no"),
("186","_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b","1624716867","no"),
("187","_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\'>WordPress 5.8 Beta 4</a></li><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2021/06/wordpress-5-8-beta-3/\'>WordPress 5.8 Beta 3</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2021/06/wordpress-5-8-beta-4/\'>WordPress.org blog: WordPress 5.8 Beta 4</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/gutenberg-10-9-renames-the-query-block-adds-collapsible-list-view-items-and-rolls-out-rich-url-previews?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=gutenberg-10-9-renames-the-query-block-adds-collapsible-list-view-items-and-rolls-out-rich-url-previews\'>WPTavern: Gutenberg 10.9 Renames the Query Block, Adds Collapsible List View Items, and Rolls Out Rich URL Previews</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/jetpack-launches-new-mobile-app?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=jetpack-launches-new-mobile-app\'>WPTavern: Jetpack Launches New Mobile App</a></li></ul></div>","no"),
("188","category_children","a:0:{}","yes"),
("189","_site_transient_timeout_available_translations","1624685579","no"),
("190","_site_transient_available_translations","a:126:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 15:59:22\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-20 20:07:35\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 14:01:58\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.18/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-20 19:46:45\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-10-31 08:48:37\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2020-10-30 03:24:38\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-25 07:27:37\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 13:15:40\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 12:10:54\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 10:32:41\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-18 02:04:16\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-22 16:13:32\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-22 17:40:37\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.7.2/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-14 20:06:23\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-14 20:06:52\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.7.2/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-08 07:32:43\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dsb\";a:8:{s:8:\"language\";s:3:\"dsb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 13:33:04\";s:12:\"english_name\";s:13:\"Lower Sorbian\";s:11:\"native_name\";s:16:\"Dolnoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/dsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"dsb\";i:3;s:3:\"dsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Dalej\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-23 13:24:24\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-16 08:10:36\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 07:22:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:51\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:40\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 04:12:28\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-18 09:35:35\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 16:02:22\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-16 13:07:32\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_EC\";a:8:{s:8:\"language\";s:5:\"es_EC\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 02:05:34\";s:12:\"english_name\";s:17:\"Spanish (Ecuador)\";s:11:\"native_name\";s:19:\"Español de Ecuador\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_EC.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-16 02:17:21\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 02:05:15\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-31 18:33:26\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"5.6.4\";s:7:\"updated\";s:19:\"2020-12-11 02:12:59\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.6.4/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PR\";a:8:{s:8:\"language\";s:5:\"es_PR\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-29 15:36:59\";s:12:\"english_name\";s:21:\"Spanish (Puerto Rico)\";s:11:\"native_name\";s:23:\"Español de Puerto Rico\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/es_PR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-10 20:43:51\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-04 22:59:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-02 03:00:51\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2020-08-12 08:38:59\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-24 16:08:10\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-15 07:03:55\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"fa_AF\";a:8:{s:8:\"language\";s:5:\"fa_AF\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 12:40:09\";s:12:\"english_name\";s:21:\"Persian (Afghanistan)\";s:11:\"native_name\";s:31:\"(فارسی (افغانستان\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fa_AF.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-06 05:21:48\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-02-22 13:54:46\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-24 08:28:29\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-30 13:29:35\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-21 09:58:55\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:6:\"4.4.25\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.4.25/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-28 16:42:59\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-11-06 12:34:38\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 08:03:31\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 13:34:18\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 12:12:19\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-24 02:11:27\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-12-11 10:40:02\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-18 13:45:37\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-20 01:00:08\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-02-16 23:58:56\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-15 08:23:19\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-06 18:16:02\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-07-10 11:35:44\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2019-06-10 16:18:28\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.11/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2020-09-30 14:08:59\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-24 01:16:16\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-17 10:36:11\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-23 12:35:40\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-12 17:16:35\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-01 09:16:57\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.4.6/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2019-11-22 15:32:08\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.18/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2017-12-26 11:57:10\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-08 06:18:21\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:6:\"5.2.11\";s:7:\"updated\";s:19:\"2020-05-31 16:07:59\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.2.11/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-17 11:46:51\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-18 08:55:40\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-10 14:42:01\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.7.2/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-03-18 10:59:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.8.17/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-25 11:57:08\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.3.26\";s:7:\"updated\";s:19:\"2015-12-02 21:41:29\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.3.26/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-18 10:37:59\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-15 08:18:42\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-02 12:53:00\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-30 09:51:29\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-25 22:04:22\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 18:30:49\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-07-07 01:53:37\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.4.6/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 04:10:29\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-04-23 11:54:14\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.7.2/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:6:\"5.1.10\";s:7:\"updated\";s:19:\"2019-04-30 13:03:56\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.1.10/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 15:40:47\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-14 19:47:34\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-21 13:18:38\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.3.8\";s:7:\"updated\";s:19:\"2019-10-13 15:35:35\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.8/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:5:\"ta_LK\";a:8:{s:8:\"language\";s:5:\"ta_LK\";s:7:\"version\";s:6:\"4.2.30\";s:7:\"updated\";s:19:\"2015-12-03 01:07:44\";s:12:\"english_name\";s:17:\"Tamil (Sri Lanka)\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.2.30/ta_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"தொடர்க\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.5.5\";s:7:\"updated\";s:19:\"2021-04-22 18:43:36\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.5.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:6:\"4.8.17\";s:7:\"updated\";s:19:\"2017-09-30 09:04:29\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.17/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-23 09:26:34\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:6:\"4.9.18\";s:7:\"updated\";s:19:\"2018-05-16 07:36:13\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.18/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-17 19:11:00\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.4.6\";s:7:\"updated\";s:19:\"2020-04-09 11:17:33\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.4.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-02-28 12:02:22\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-23 07:16:16\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.7.2/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-15 12:16:10\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-06-15 02:45:12\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.7.2\";s:7:\"updated\";s:19:\"2021-05-13 03:20:55\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.7.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no"),
("196","recently_activated","a:0:{}","yes"),
("202","code_snippets_version","2.14.1","yes"),
("203","code_snippets_settings","a:3:{s:7:\"general\";a:6:{s:19:\"activate_by_default\";b:1;s:21:\"snippet_scope_enabled\";b:1;s:11:\"enable_tags\";b:1;s:18:\"enable_description\";b:1;s:13:\"disable_prism\";b:0;s:18:\"complete_uninstall\";b:0;}s:18:\"description_editor\";a:3:{s:4:\"rows\";i:5;s:12:\"use_full_mce\";b:0;s:13:\"media_buttons\";b:0;}s:6:\"editor\";a:8:{s:5:\"theme\";s:7:\"default\";s:16:\"indent_with_tabs\";b:1;s:8:\"tab_size\";i:4;s:11:\"indent_unit\";i:4;s:10:\"wrap_lines\";b:1;s:12:\"line_numbers\";b:1;s:19:\"auto_close_brackets\";b:1;s:27:\"highlight_selection_matches\";b:1;}}","yes"),
("204","recently_activated_snippets","a:0:{}","yes"),
("214","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1624706157","no"),
("215","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4969;}s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4772;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2717;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2593;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:2004;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1859;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1839;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1519;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1505;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1501;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1497;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1486;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1471;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1311;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1267;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1258;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1230;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1155;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1128;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1059;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:960;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:935;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:909;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:888;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:880;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:829;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:824;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:812;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:807;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:788;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:763;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:747;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:729;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:728;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:720;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:714;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:687;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:683;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:665;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:665;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:664;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:660;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:656;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:648;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:646;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:616;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:600;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:599;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:590;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:590;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:575;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:573;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:566;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:561;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:560;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:558;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:547;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:546;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:545;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:539;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:530;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:523;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:521;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:512;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:511;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:503;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:500;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:497;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:495;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:486;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:478;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:467;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:463;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:461;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:454;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:447;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:447;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:446;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:445;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:443;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:432;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:426;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:420;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:415;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:411;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:408;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:407;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:400;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:395;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:389;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:388;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:380;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:380;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:378;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:371;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:367;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:367;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:358;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:356;}s:6:\"blocks\";a:3:{s:4:\"name\";s:6:\"blocks\";s:4:\"slug\";s:6:\"blocks\";s:5:\"count\";i:352;}}","no"),
("217","_site_transient_timeout_theme_roots","1624697212","no"),
("218","_site_transient_theme_roots","a:4:{s:7:\"sinatra\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}","no"),
("219","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1624695422;s:7:\"checked\";a:4:{s:19:\"akismet/akismet.php\";s:5:\"4.1.9\";s:31:\"code-snippets/code-snippets.php\";s:6:\"2.14.1\";s:9:\"hello.php\";s:5:\"1.7.2\";s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";s:5:\"1.2.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"code-snippets/code-snippets.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/code-snippets\";s:4:\"slug\";s:13:\"code-snippets\";s:6:\"plugin\";s:31:\"code-snippets/code-snippets.php\";s:11:\"new_version\";s:6:\"2.14.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/code-snippets/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/code-snippets.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:58:\"https://ps.w.org/code-snippets/assets/icon.svg?rev=2148878\";s:3:\"svg\";s:58:\"https://ps.w.org/code-snippets/assets/icon.svg?rev=2148878\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/code-snippets/assets/banner-1544x500.png?rev=2260997\";s:2:\"1x\";s:68:\"https://ps.w.org/code-snippets/assets/banner-772x250.png?rev=2256244\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:37:\"w.org/plugins/wp-migration-duplicator\";s:4:\"slug\";s:23:\"wp-migration-duplicator\";s:6:\"plugin\";s:51:\"wp-migration-duplicator/wp-migration-duplicator.php\";s:11:\"new_version\";s:5:\"1.2.2\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/wp-migration-duplicator/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/wp-migration-duplicator.1.2.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:76:\"https://ps.w.org/wp-migration-duplicator/assets/icon-128x128.jpg?rev=1861802\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/wp-migration-duplicator/assets/banner-772x250.jpg?rev=2063406\";}s:11:\"banners_rtl\";a:0:{}}}}","no"),
("220","wtmigrator_start_date","1624695424","yes"),
("221","wt_mgdp_admin_modules","a:8:{s:6:\"logger\";i:1;s:6:\"export\";i:1;s:6:\"import\";i:1;s:7:\"backups\";i:1;s:18:\"uninstall-feedback\";i:1;s:3:\"ftp\";i:1;s:11:\"googledrive\";i:1;s:2:\"s3\";i:1;}","yes");/*END*/




DROP TABLE IF EXISTS `webtoffee_postmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_postmeta VALUES
("1","2","_wp_page_template","default"),
("2","3","_wp_page_template","default"),
("3","2","_edit_lock","1624534108:1"),
("4","2","_edit_lock","1624534108:1"),
("5","2","_wp_trash_meta_status","publish"),
("6","2","_wp_trash_meta_time","1624534155"),
("7","2","_wp_desired_post_slug","sample-page"),
("8","3","_wp_trash_meta_status","draft"),
("9","3","_wp_trash_meta_time","1624534383"),
("10","3","_wp_desired_post_slug","privacy-policy"),
("11","7","_edit_lock","1624538414:1"),
("12","7","_edit_last","1"),
("13","7","sinatra_disable_header",""),
("14","7","sinatra_disable_page_title",""),
("15","7","sinatra_disable_breadcrumbs",""),
("16","7","sinatra_disable_thumbnail",""),
("17","7","sinatra_disable_footer",""),
("18","7","sinatra_disable_copyright",""),
("19","9","_edit_lock","1624538476:1"),
("20","9","_edit_last","1"),
("21","9","sinatra_disable_header",""),
("22","9","sinatra_disable_page_title",""),
("23","9","sinatra_disable_breadcrumbs",""),
("24","9","sinatra_disable_thumbnail",""),
("25","9","sinatra_disable_footer",""),
("26","9","sinatra_disable_copyright",""),
("27","11","_edit_lock","1624538487:1"),
("28","12","_edit_lock","1624692139:1"),
("29","12","_edit_last","1"),
("30","12","sinatra_disable_header",""),
("31","12","sinatra_disable_page_title",""),
("32","12","sinatra_disable_breadcrumbs",""),
("33","12","sinatra_disable_thumbnail",""),
("34","12","sinatra_disable_footer",""),
("35","12","sinatra_disable_copyright",""),
("36","14","_edit_lock","1624538535:1"),
("37","14","_edit_last","1"),
("38","14","sinatra_disable_header",""),
("39","14","sinatra_disable_page_title",""),
("40","14","sinatra_disable_breadcrumbs",""),
("41","14","sinatra_disable_thumbnail",""),
("42","14","sinatra_disable_footer",""),
("43","14","sinatra_disable_copyright",""),
("44","17","_edit_lock","1624538555:1"),
("45","16","_edit_lock","1624538545:1"),
("46","17","_edit_last","1"),
("47","17","sinatra_disable_header",""),
("48","17","sinatra_disable_page_title",""),
("49","17","sinatra_disable_breadcrumbs",""),
("50","17","sinatra_disable_thumbnail",""),
("51","17","sinatra_disable_footer",""),
("52","17","sinatra_disable_copyright",""),
("53","19","_menu_item_type","custom"),
("54","19","_menu_item_menu_item_parent","0"),
("55","19","_menu_item_object_id","19"),
("56","19","_menu_item_object","custom"),
("57","19","_menu_item_target",""),
("58","19","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("59","19","_menu_item_xfn",""),
("60","19","_menu_item_url","http://localhost/wordpress/"),
("62","20","_menu_item_type","post_type"),
("63","20","_menu_item_menu_item_parent","0"),
("64","20","_menu_item_object_id","9"),
("65","20","_menu_item_object","page"),
("66","20","_menu_item_target",""),
("67","20","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("68","20","_menu_item_xfn",""),
("69","20","_menu_item_url",""),
("71","21","_menu_item_type","post_type"),
("72","21","_menu_item_menu_item_parent","0"),
("73","21","_menu_item_object_id","14"),
("74","21","_menu_item_object","page"),
("75","21","_menu_item_target",""),
("76","21","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("77","21","_menu_item_xfn",""),
("78","21","_menu_item_url",""),
("80","22","_menu_item_type","post_type"),
("81","22","_menu_item_menu_item_parent","0"),
("82","22","_menu_item_object_id","17"),
("83","22","_menu_item_object","page"),
("84","22","_menu_item_target",""),
("85","22","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("86","22","_menu_item_xfn",""),
("87","22","_menu_item_url",""),
("89","23","_menu_item_type","post_type"),
("90","23","_menu_item_menu_item_parent","0"),
("91","23","_menu_item_object_id","7"),
("92","23","_menu_item_object","page"),
("93","23","_menu_item_target",""),
("94","23","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("95","23","_menu_item_xfn",""),
("96","23","_menu_item_url",""),
("97","23","_menu_item_orphaned","1624538656"),
("98","24","_menu_item_type","post_type"),
("99","24","_menu_item_menu_item_parent","0"),
("100","24","_menu_item_object_id","12"),
("101","24","_menu_item_object","page"),
("102","24","_menu_item_target",""),
("103","24","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("104","24","_menu_item_xfn","");/*END*/
INSERT INTO webtoffee_postmeta VALUES
("105","24","_menu_item_url",""),
("107","25","_menu_item_type","post_type"),
("108","25","_menu_item_menu_item_parent","0"),
("109","25","_menu_item_object_id","17"),
("110","25","_menu_item_object","page"),
("111","25","_menu_item_target",""),
("112","25","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("113","25","_menu_item_xfn",""),
("114","25","_menu_item_url",""),
("115","25","_menu_item_orphaned","1624538675"),
("116","26","_menu_item_type","post_type"),
("117","26","_menu_item_menu_item_parent","0"),
("118","26","_menu_item_object_id","14"),
("119","26","_menu_item_object","page"),
("120","26","_menu_item_target",""),
("121","26","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("122","26","_menu_item_xfn",""),
("123","26","_menu_item_url",""),
("124","26","_menu_item_orphaned","1624538675"),
("125","27","_menu_item_type","post_type"),
("126","27","_menu_item_menu_item_parent","0"),
("127","27","_menu_item_object_id","12"),
("128","27","_menu_item_object","page"),
("129","27","_menu_item_target",""),
("130","27","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("131","27","_menu_item_xfn",""),
("132","27","_menu_item_url",""),
("133","27","_menu_item_orphaned","1624538675"),
("134","28","_menu_item_type","post_type"),
("135","28","_menu_item_menu_item_parent","0"),
("136","28","_menu_item_object_id","9"),
("137","28","_menu_item_object","page"),
("138","28","_menu_item_target",""),
("139","28","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("140","28","_menu_item_xfn",""),
("141","28","_menu_item_url",""),
("142","28","_menu_item_orphaned","1624538676"),
("143","29","_menu_item_type","post_type"),
("144","29","_menu_item_menu_item_parent","0"),
("145","29","_menu_item_object_id","7"),
("146","29","_menu_item_object","page"),
("147","29","_menu_item_target",""),
("148","29","_menu_item_classes","a:1:{i:0;s:0:\"\";}"),
("149","29","_menu_item_xfn",""),
("150","29","_menu_item_url",""),
("151","29","_menu_item_orphaned","1624538677"),
("153","31","_wp_attached_file","2021/06/finalheaderlogo.png"),
("154","31","_wp_attachment_metadata","a:5:{s:5:\"width\";i:268;s:6:\"height\";i:50;s:4:\"file\";s:27:\"2021/06/finalheaderlogo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("155","30","_customize_restore_dismissed","1"),
("156","32","_edit_lock","1624541747:1"),
("157","33","_edit_lock","1624673652:1"),
("158","32","_customize_restore_dismissed","1"),
("159","34","_wp_trash_meta_status","publish"),
("160","34","_wp_trash_meta_time","1624673830"),
("161","35","_wp_trash_meta_status","publish"),
("162","35","_wp_trash_meta_time","1624673890"),
("163","36","_wp_trash_meta_status","publish"),
("164","36","_wp_trash_meta_time","1624673942"),
("165","37","_wp_trash_meta_status","publish"),
("166","37","_wp_trash_meta_time","1624673970"),
("167","38","_edit_lock","1624674094:1"),
("168","38","_wp_trash_meta_status","publish"),
("169","38","_wp_trash_meta_time","1624674113"),
("170","39","_edit_lock","1624674423:1"),
("171","39","_wp_trash_meta_status","publish"),
("172","39","_wp_trash_meta_time","1624674430"),
("183","19","_wp_old_date","2021-06-24"),
("184","20","_wp_old_date","2021-06-24"),
("185","24","_wp_old_date","2021-06-24"),
("186","21","_wp_old_date","2021-06-24"),
("187","22","_wp_old_date","2021-06-24"),
("188","40","_customize_restore_dismissed","1"),
("190","44","_wp_attached_file","2021/06/images.png"),
("191","44","_wp_attachment_metadata","a:5:{s:5:\"width\";i:220;s:6:\"height\";i:229;s:4:\"file\";s:18:\"2021/06/images.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("192","45","_wp_attached_file","2021/06/images.jpg"),
("193","45","_wp_attachment_metadata","a:5:{s:5:\"width\";i:271;s:6:\"height\";i:186;s:4:\"file\";s:18:\"2021/06/images.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("194","46","_wp_attached_file","2021/06/images-1.png"),
("195","46","_wp_attachment_metadata","a:5:{s:5:\"width\";i:220;s:6:\"height\";i:229;s:4:\"file\";s:20:\"2021/06/images-1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("196","12","_wp_page_template","default"),
("197","43","_customize_restore_dismissed","1"),
("198","51","_edit_lock","1624689390:1"),
("199","51","_wp_trash_meta_status","publish"),
("200","51","_wp_trash_meta_time","1624689391"),
("201","60","_wp_attached_file","2021/06/webdevelopment-photo.png"),
("202","60","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:32:\"2021/06/webdevelopment-photo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("203","61","_wp_attached_file","2021/06/webdevelopment-photo-1.png"),
("204","61","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:34:\"2021/06/webdevelopment-photo-1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("205","63","_wp_attached_file","2021/06/contentcreation-photo.png"),
("206","63","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:33:\"2021/06/contentcreation-photo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("207","65","_wp_attached_file","2021/06/download.png"),
("208","65","_wp_attachment_metadata","a:5:{s:5:\"width\";i:216;s:6:\"height\";i:233;s:4:\"file\";s:20:\"2021/06/download.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("209","66","_wp_attached_file","2021/06/download-1.png"),
("210","66","_wp_attachment_metadata","a:5:{s:5:\"width\";i:216;s:6:\"height\";i:233;s:4:\"file\";s:22:\"2021/06/download-1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("211","67","_wp_attached_file","2021/06/contentcreation-photo-1.png"),
("212","67","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:35:\"2021/06/contentcreation-photo-1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("213","70","_wp_attached_file","2021/06/download-2.png"),
("214","70","_wp_attachment_metadata","a:5:{s:5:\"width\";i:216;s:6:\"height\";i:233;s:4:\"file\";s:22:\"2021/06/download-2.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("215","77","_wp_attached_file","2021/06/seo-photo.png"),
("216","77","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:21:\"2021/06/seo-photo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("217","78","_wp_attached_file","2021/06/socialmedia-photo.png");/*END*/
INSERT INTO webtoffee_postmeta VALUES
("218","78","_wp_attachment_metadata","a:5:{s:5:\"width\";i:368;s:6:\"height\";i:368;s:4:\"file\";s:29:\"2021/06/socialmedia-photo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}"),
("219","80","_edit_lock","1624692234:1"),
("220","80","_wp_trash_meta_status","publish"),
("221","80","_wp_trash_meta_time","1624692235"),
("222","81","_edit_lock","1624692923:1"),
("223","81","_wp_trash_meta_status","publish"),
("224","81","_wp_trash_meta_time","1624692927"),
("225","83","_edit_lock","1624693103:1"),
("226","83","_wp_trash_meta_status","publish"),
("227","83","_wp_trash_meta_time","1624693108");/*END*/




DROP TABLE IF EXISTS `webtoffee_posts` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_posts VALUES
("1","1","2021-06-24 10:07:15","2021-06-24 10:07:15","<!-- wp:paragraph -->
<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>
<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2021-06-24 10:07:15","2021-06-24 10:07:15","","0","http://localhost/wordpress/?p=1","0","post","","1"),
("2","1","2021-06-24 10:07:15","2021-06-24 10:07:15","<!-- wp:paragraph -->
<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...or something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>As a new WordPress user, you should go to <a href=\"http://localhost/wordpress/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>
<!-- /wp:paragraph -->","Sample Page","","trash","closed","open","","sample-page__trashed","","","2021-06-24 11:29:32","2021-06-24 11:29:32","","0","http://localhost/wordpress/?page_id=2","0","page","","0"),
("3","1","2021-06-24 10:07:15","2021-06-24 10:07:15","<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/wordpress.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->","Privacy Policy","","trash","closed","open","","privacy-policy__trashed","","","2021-06-24 11:33:24","2021-06-24 11:33:24","","0","http://localhost/wordpress/?page_id=3","0","page","","0"),
("4","1","2021-06-24 10:08:33","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2021-06-24 10:08:33","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=4","0","post","","0"),
("5","1","2021-06-24 11:29:32","2021-06-24 11:29:32","<!-- wp:paragraph -->
<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...or something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>As a new WordPress user, you should go to <a href=\"http://localhost/wordpress/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>
<!-- /wp:paragraph -->","Sample Page","","inherit","closed","closed","","2-revision-v1","","","2021-06-24 11:29:32","2021-06-24 11:29:32","","2","http://localhost/wordpress/?p=5","0","revision","","0"),
("6","1","2021-06-24 11:33:24","2021-06-24 11:33:24","<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/wordpress.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->","Privacy Policy","","inherit","closed","closed","","3-revision-v1","","","2021-06-24 11:33:24","2021-06-24 11:33:24","","3","http://localhost/wordpress/?p=6","0","revision","","0"),
("7","1","2021-06-24 12:40:11","2021-06-24 12:40:11","","Home","","publish","closed","closed","","home","","","2021-06-24 12:40:13","2021-06-24 12:40:13","","0","http://localhost/wordpress/?page_id=7","0","page","","0"),
("8","1","2021-06-24 12:40:11","2021-06-24 12:40:11","","Home","","inherit","closed","closed","","7-revision-v1","","","2021-06-24 12:40:11","2021-06-24 12:40:11","","7","http://localhost/wordpress/?p=8","0","revision","","0"),
("9","1","2021-06-24 12:41:13","2021-06-24 12:41:13","","About Us","","publish","closed","closed","","about-us","","","2021-06-24 12:41:14","2021-06-24 12:41:14","","0","http://localhost/wordpress/?page_id=9","0","page","","0"),
("10","1","2021-06-24 12:41:13","2021-06-24 12:41:13","","About Us","","inherit","closed","closed","","9-revision-v1","","","2021-06-24 12:41:13","2021-06-24 12:41:13","","9","http://localhost/wordpress/?p=10","0","revision","","0"),
("11","1","2021-06-24 12:41:27","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2021-06-24 12:41:27","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=11","0","post","","0"),
("12","1","2021-06-24 12:41:42","2021-06-24 12:41:42","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":70,\"width\":49,\"height\":53,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png\" alt=\"\" class=\"wp-image-70\" width=\"49\" height=\"53\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"textAlign\":\"center\"} -->
<h2 class=\"has-text-align-center\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}}} -->
<p style=\"font-size:30px\"><strong>SEO MARKETING AND MANAGEMENT</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":77,\"mediaLink\":\"http://localhost/wordpress/services/seo-photo/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/seo-photo.png\" alt=\"\" class=\"wp-image-77 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>To institute a level of consistency in web development, Fullmoon subscribes to the effective marketing strategy of Search Engine Optimization (SEO). SEO marketing helps clients use proper analytics to boost website performance as a core advantage in website maintenance. Clients count on us to deal with the technical side of website optimization, as well as the coordination of web content.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Another fundamental aspect emphasized by Fullmoon’s SEO team, is the continuous process of establishing an online community for our client’s products through backlink building. SEO managers at Fullmoon go through a great amount of effort when it comes to keyword research, market analysis and daily content optimization.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>SEO managers at Fullmoon make use of not only effective, but excellent optimization tools which include AdMob by Google, Links Management, Blackhat Links, and Traffic Junky among many others.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:heading {\"textAlign\":\"right\"} -->
<h2 class=\"has-text-align-right\">SOCIAL MEDIA MANAGEMENT</h2>
<!-- /wp:heading -->

<!-- wp:media-text {\"mediaId\":78,\"mediaLink\":\"http://localhost/wordpress/services/socialmedia-photo/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/socialmedia-photo.png\" alt=\"\" class=\"wp-image-78 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">At Fullmoon, sustaining the process and developmental structure of every website created and optimized is supported by the social media manager. Facebook, Google Plus, LinkedIn and Twitter are some of the social media accounts we use and recommend to our clients.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Applying the basics of digital marketing in managing social media accounts is best delivered with various online strategies we offer our clients. Overseeing every post and profile online is vital in highlighting brand essentials.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Social media management also entails identifying target audience, interacting with followers and cultivating promotion and engagement strategy with what the client wants to convey in their profiles and what their followers adhere to. At Fullmoon, our social media strategist works hand in hand with the SEO manager to flawlessly keep operations smooth for our clients.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","publish","closed","closed","","services","","","2021-06-26 07:22:19","2021-06-26 07:22:19","","0","http://localhost/wordpress/?page_id=12","0","page","","0"),
("13","1","2021-06-24 12:41:42","2021-06-24 12:41:42","","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-24 12:41:42","2021-06-24 12:41:42","","12","http://localhost/wordpress/?p=13","0","revision","","0"),
("14","1","2021-06-24 12:42:12","2021-06-24 12:42:12","","Careers","","publish","closed","closed","","careers","","","2021-06-24 12:42:13","2021-06-24 12:42:13","","0","http://localhost/wordpress/?page_id=14","0","page","","0"),
("15","1","2021-06-24 12:42:12","2021-06-24 12:42:12","","Careers","","inherit","closed","closed","","14-revision-v1","","","2021-06-24 12:42:12","2021-06-24 12:42:12","","14","http://localhost/wordpress/?p=15","0","revision","","0"),
("16","1","2021-06-24 12:42:23","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2021-06-24 12:42:23","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=16","0","post","","0"),
("17","1","2021-06-24 12:42:33","2021-06-24 12:42:33","","Contact Us","","publish","closed","closed","","contact-us","","","2021-06-24 12:42:35","2021-06-24 12:42:35","","0","http://localhost/wordpress/?page_id=17","0","page","","0"),
("18","1","2021-06-24 12:42:33","2021-06-24 12:42:33","","Contact Us","","inherit","closed","closed","","17-revision-v1","","","2021-06-24 12:42:33","2021-06-24 12:42:33","","17","http://localhost/wordpress/?p=18","0","revision","","0"),
("19","1","2021-06-26 03:08:36","2021-06-24 12:47:51","","Home","","publish","closed","closed","","home","","","2021-06-26 03:08:36","2021-06-26 03:08:36","","0","http://localhost/wordpress/?p=19","1","nav_menu_item","","0"),
("20","1","2021-06-26 03:08:37","2021-06-24 12:47:51"," ","","","publish","closed","closed","","20","","","2021-06-26 03:08:37","2021-06-26 03:08:37","","0","http://localhost/wordpress/?p=20","2","nav_menu_item","","0"),
("21","1","2021-06-26 03:08:39","2021-06-24 12:47:52"," ","","","publish","closed","closed","","21","","","2021-06-26 03:08:39","2021-06-26 03:08:39","","0","http://localhost/wordpress/?p=21","4","nav_menu_item","","0"),
("22","1","2021-06-26 03:08:39","2021-06-24 12:47:52"," ","","","publish","closed","closed","","22","","","2021-06-26 03:08:39","2021-06-26 03:08:39","","0","http://localhost/wordpress/?p=22","5","nav_menu_item","","0"),
("23","1","2021-06-24 12:44:15","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:15","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=23","1","nav_menu_item","","0"),
("24","1","2021-06-26 03:08:38","2021-06-24 12:47:51"," ","","","publish","closed","closed","","24","","","2021-06-26 03:08:38","2021-06-26 03:08:38","","0","http://localhost/wordpress/?p=24","3","nav_menu_item","","0"),
("25","1","2021-06-24 12:44:34","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:34","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=25","1","nav_menu_item","","0"),
("26","1","2021-06-24 12:44:35","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:35","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=26","1","nav_menu_item","","0"),
("27","1","2021-06-24 12:44:35","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:35","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=27","1","nav_menu_item","","0"),
("28","1","2021-06-24 12:44:36","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:36","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=28","1","nav_menu_item","","0"),
("29","1","2021-06-24 12:44:36","0000-00-00 00:00:00"," ","","","draft","closed","closed","","","","","2021-06-24 12:44:36","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=29","1","nav_menu_item","","0"),
("30","1","2021-06-24 13:16:50","0000-00-00 00:00:00","{
    \"sinatra::sinatra_header_layout\": {
        \"value\": \"layout-1\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:03:38\"
    },
    \"sinatra::sinatra_header_heading_design_options\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:04:30\"
    },
    \"custom_css[sinatra]\": {
        \"value\": \"\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:16:50\"
    },
    \"sinatra::custom_logo\": {
        \"value\": 31,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:10:52\"
    }
}","","","auto-draft","closed","closed","","a293ada0-0578-46d9-b29b-dc3bcd04f083","","","2021-06-24 13:16:50","2021-06-24 13:16:50","","0","http://localhost/wordpress/?p=30","0","customize_changeset","","0"),
("31","1","2021-06-24 13:10:24","2021-06-24 13:10:24","","finalheaderlogo","","inherit","open","closed","","finalheaderlogo","","","2021-06-24 13:10:24","2021-06-24 13:10:24","","0","http://localhost/wordpress/wp-content/uploads/2021/06/finalheaderlogo.png","0","attachment","image/png","0"),
("32","1","2021-06-24 13:35:47","0000-00-00 00:00:00","{
    \"sinatra::background_color\": {
        \"value\": \"#ffffff\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:35:47\"
    },
    \"sinatra::sinatra_top_bar_enable\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-24 13:35:47\"
    }
}","","","auto-draft","closed","closed","","41088edc-6681-49f2-b8e8-f2d8a7a1fcd8","","","2021-06-24 13:35:47","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=32","0","customize_changeset","","0"),
("33","1","2021-06-26 02:14:00","0000-00-00 00:00:00","","Auto Draft","","auto-draft","closed","closed","","","","","2021-06-26 02:14:00","0000-00-00 00:00:00","","0","http://localhost/wordpress/?page_id=33","0","page","","0"),
("34","1","2021-06-26 02:17:09","2021-06-26 02:17:09","{
    \"sinatra::sinatra_header_heading_widgets\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:17:09\"
    },
    \"sinatra::sinatra_header_heading_design_options\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:17:09\"
    },
    \"sinatra::sinatra_header_background\": {
        \"value\": {
            \"background-type\": \"gradient\",
            \"background-color\": \"#FFFFFF\",
            \"gradient-color-1\": \"#052028\",
            \"gradient-color-1-location\": \"0\",
            \"gradient-color-2\": \"#3A6073\",
            \"gradient-color-2-location\": \"100\",
            \"gradient-type\": \"linear\",
            \"gradient-linear-angle\": \"45\",
            \"gradient-position\": \"center center\",
            \"background-image\": \"\",
            \"background-repeat\": \"no-repeat\",
            \"background-position-x\": \"50\",
            \"background-position-y\": \"50\",
            \"background-size\": \"cover\",
            \"background-attachment\": \"inherit\",
            \"background-color-overlay\": \"rgba(0,0,0,0.5)\",
            \"background-image-id\": \"\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:17:09\"
    }
}","","","trash","closed","closed","","1ce5a84c-aae0-40a4-9b9c-1e46d4682050","","","2021-06-26 02:17:09","2021-06-26 02:17:09","","0","http://localhost/wordpress/2021/06/26/1ce5a84c-aae0-40a4-9b9c-1e46d4682050/","0","customize_changeset","","0"),
("35","1","2021-06-26 02:18:08","2021-06-26 02:18:08","{
    \"sinatra::sinatra_header_background\": {
        \"value\": {
            \"background-type\": \"gradient\",
            \"background-color\": \"#FFFFFF\",
            \"gradient-color-1\": \"#0c0005\",
            \"gradient-color-1-location\": \"0\",
            \"gradient-color-2\": \"#3A6073\",
            \"gradient-color-2-location\": \"100\",
            \"gradient-type\": \"linear\",
            \"gradient-linear-angle\": \"45\",
            \"gradient-position\": \"center center\",
            \"background-image\": \"\",
            \"background-repeat\": \"no-repeat\",
            \"background-position-x\": \"50\",
            \"background-position-y\": \"50\",
            \"background-size\": \"cover\",
            \"background-attachment\": \"inherit\",
            \"background-color-overlay\": \"rgba(0,0,0,0.5)\",
            \"background-image-id\": \"\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:18:08\"
    }
}","","","trash","closed","closed","","36fdb978-228f-4acf-b4a4-81a5e525fed2","","","2021-06-26 02:18:08","2021-06-26 02:18:08","","0","http://localhost/wordpress/2021/06/26/36fdb978-228f-4acf-b4a4-81a5e525fed2/","0","customize_changeset","","0"),
("36","1","2021-06-26 02:19:02","2021-06-26 02:19:02","{
    \"sinatra::custom_logo\": {
        \"value\": 31,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:19:02\"
    },
    \"sinatra::sinatra_header_heading_design_options\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:19:02\"
    }
}","","","trash","closed","closed","","06de38e5-c7aa-44a7-b8f9-d318036a5769","","","2021-06-26 02:19:02","2021-06-26 02:19:02","","0","http://localhost/wordpress/2021/06/26/06de38e5-c7aa-44a7-b8f9-d318036a5769/","0","customize_changeset","","0"),
("37","1","2021-06-26 02:19:30","2021-06-26 02:19:30","{
    \"sinatra::sinatra_sidebar_position\": {
        \"value\": \"no-sidebar\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:19:30\"
    }
}","","","trash","closed","closed","","bbfbeb19-78f8-4aec-b95f-79280591fe38","","","2021-06-26 02:19:30","2021-06-26 02:19:30","","0","http://localhost/wordpress/2021/06/26/bbfbeb19-78f8-4aec-b95f-79280591fe38/","0","customize_changeset","","0"),
("38","1","2021-06-26 02:21:50","2021-06-26 02:21:50","{
    \"sinatra::sinatra_main_nav_heading_animation\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:21:33\"
    },
    \"sinatra::sinatra_main_nav_heading_sub_menus\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:21:33\"
    },
    \"sinatra::sinatra_main_nav_heading_mobile_menu\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:21:33\"
    },
    \"sinatra::sinatra_nav_design_options\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:21:33\"
    },
    \"sinatra::sinatra_main_nav_font_color\": {
        \"value\": {
            \"link-color\": \"#ffffff\",
            \"link-hover-color\": \"\"
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:21:33\"
    }
}","","","trash","closed","closed","","a72633c2-f436-4266-8cae-5d315f1f1260","","","2021-06-26 02:21:50","2021-06-26 02:21:50","","0","http://localhost/wordpress/?p=38","0","customize_changeset","","0"),
("39","1","2021-06-26 02:27:05","2021-06-26 02:27:05","{
    \"sinatra::sinatra_header_layout\": {
        \"value\": \"layout-1\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:26:55\"
    },
    \"sinatra::sinatra_header_heading_widgets\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:26:01\"
    },
    \"sinatra::sinatra_header_heading_design_options\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:26:01\"
    },
    \"sinatra::sinatra_header_widgets\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:26:55\"
    }
}","","","trash","closed","closed","","63cc2200-ea5c-434d-8671-1250e5d178f0","","","2021-06-26 02:27:05","2021-06-26 02:27:05","","0","http://localhost/wordpress/?p=39","0","customize_changeset","","0"),
("40","1","2021-06-26 02:30:29","0000-00-00 00:00:00","{
    \"sinatra::sinatra_single_post_layout_heading\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:29:49\"
    },
    \"sinatra::sinatra_single_title_alignment\": {
        \"value\": \"left\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:29:49\"
    },
    \"sinatra::sinatra_single_post_elements_heading\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:29:49\"
    },
    \"sinatra::sinatra_typography_single_post_heading\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:29:49\"
    },
    \"sinatra::sinatra_blog_entry_meta_elements\": {
        \"value\": {
            \"author\": false,
            \"date\": false,
            \"category\": false,
            \"tag\": false,
            \"comments\": false
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 02:30:29\"
    }
}","","","auto-draft","closed","closed","","fc281d0a-9303-4e7c-84fa-85421016c943","","","2021-06-26 02:30:29","2021-06-26 02:30:29","","0","http://localhost/wordpress/?p=40","0","customize_changeset","","0"),
("41","1","2021-06-26 02:45:49","0000-00-00 00:00:00","","","","draft","closed","closed","","","","","2021-06-26 02:45:49","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=41","1","nav_menu_item","","0"),
("43","1","2021-06-26 03:13:09","0000-00-00 00:00:00","{
    \"sinatra::sinatra_header_heading_widgets\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 03:13:09\"
    },
    \"sinatra::sinatra_header_widgets\": {
        \"value\": [
            {
                \"classname\": \"sinatra_customizer_widget_button\",
                \"type\": \"button\",
                \"values\": {
                    \"text\": \"Facebook\",
                    \"url\": \"www.facebook.com\",
                    \"target\": \"_self\",
                    \"class\": \"\",
                    \"location\": \"left\",
                    \"visibility\": \"all\"
                }
            }
        ],
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 03:13:09\"
    },
    \"sinatra::sinatra_header_widgets_separator\": {
        \"value\": \"regular\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 03:13:09\"
    }
}","","","auto-draft","closed","closed","","c659af4e-9869-454b-b508-9d829e368d1f","","","2021-06-26 03:13:09","0000-00-00 00:00:00","","0","http://localhost/wordpress/?p=43","0","customize_changeset","","0"),
("44","1","2021-06-26 04:22:54","2021-06-26 04:22:54","","images","","inherit","open","closed","","images","","","2021-06-26 04:22:54","2021-06-26 04:22:54","","0","http://localhost/wordpress/wp-content/uploads/2021/06/images.png","0","attachment","image/png","0"),
("45","1","2021-06-26 04:31:31","2021-06-26 04:31:31","","images","","inherit","open","closed","","images-2","","","2021-06-26 04:31:31","2021-06-26 04:31:31","","0","http://localhost/wordpress/wp-content/uploads/2021/06/images.jpg","0","attachment","image/jpeg","0"),
("46","1","2021-06-26 04:43:11","2021-06-26 04:43:11","","images","","inherit","open","closed","","images-3","","","2021-06-26 04:43:11","2021-06-26 04:43:11","","0","http://localhost/wordpress/wp-content/uploads/2021/06/images-1.png","0","attachment","image/png","0"),
("47","1","2021-06-26 06:25:49","2021-06-26 06:25:49","<!-- wp:paragraph -->
<p>hello Dhananjay</p>
<!-- /wp:paragraph -->","","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:25:49","2021-06-26 06:25:49","","12","http://localhost/wordpress/?p=47","0","revision","","0"),
("48","1","2021-06-26 06:26:22","2021-06-26 06:26:22","<!-- wp:paragraph -->
<p>hello Dhananjay</p>
<!-- /wp:paragraph -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:26:22","2021-06-26 06:26:22","","12","http://localhost/wordpress/?p=48","0","revision","","0"),
("49","1","2021-06-26 06:28:24","2021-06-26 06:28:24","<!-- wp:paragraph -->
<p>hello Dhananjay</p>
<!-- /wp:paragraph -->","","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:28:24","2021-06-26 06:28:24","","12","http://localhost/wordpress/?p=49","0","revision","","0"),
("50","1","2021-06-26 06:28:44","2021-06-26 06:28:44","<!-- wp:paragraph -->
<p>hello Dhananjay</p>
<!-- /wp:paragraph -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:28:44","2021-06-26 06:28:44","","12","http://localhost/wordpress/?p=50","0","revision","","0"),
("51","1","2021-06-26 06:36:31","2021-06-26 06:36:31","{
    \"custom_css[sinatra]\": {
        \"value\": \".page-header.si-has-page-title.si-has-breadcrumbs{\\n\\tdisplay: none;\\n\\t\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 06:36:29\"
    }
}","","","trash","closed","closed","","c22d16a5-2bbc-4300-b7fe-b3c56fc080f2","","","2021-06-26 06:36:31","2021-06-26 06:36:31","","0","http://localhost/wordpress/?p=51","0","customize_changeset","","0"),
("52","1","2021-06-26 06:36:31","2021-06-26 06:36:31",".page-header.si-has-page-title.si-has-breadcrumbs{
	display: none;
	
}

.imprint{
visibility: hidden;
position: relative;
}

.imprint:after {
visibility: visible;
position: absolute;
top: 0;
left: 0;
content: \"Mywebsolutions:)\";
}","sinatra","","publish","closed","closed","","sinatra","","","2021-06-26 07:38:28","2021-06-26 07:38:28","","0","http://localhost/wordpress/2021/06/26/sinatra/","0","custom_css","","0"),
("53","1","2021-06-26 06:36:31","2021-06-26 06:36:31",".page-header.si-has-page-title.si-has-breadcrumbs{
	display: none;
	
}","sinatra","","inherit","closed","closed","","52-revision-v1","","","2021-06-26 06:36:31","2021-06-26 06:36:31","","52","http://localhost/wordpress/?p=53","0","revision","","0"),
("54","1","2021-06-26 06:38:34","2021-06-26 06:38:34","","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:38:34","2021-06-26 06:38:34","","12","http://localhost/wordpress/?p=54","0","revision","","0"),
("56","1","2021-06-26 06:41:03","2021-06-26 06:41:03","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:41:03","2021-06-26 06:41:03","","12","http://localhost/wordpress/?p=56","0","revision","","0"),
("58","1","2021-06-26 06:43:18","2021-06-26 06:43:18","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:43:18","2021-06-26 06:43:18","","12","http://localhost/wordpress/?p=58","0","revision","","0"),
("60","1","2021-06-26 06:46:21","2021-06-26 06:46:21","","webdevelopment-photo","","inherit","open","closed","","webdevelopment-photo","","","2021-06-26 06:46:21","2021-06-26 06:46:21","","12","http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo.png","0","attachment","image/png","0"),
("61","1","2021-06-26 06:52:22","2021-06-26 06:52:22","","webdevelopment-photo-1","","inherit","open","closed","","webdevelopment-photo-1","","","2021-06-26 06:52:22","2021-06-26 06:52:22","","12","http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png","0","attachment","image/png","0"),
("62","1","2021-06-26 06:53:18","2021-06-26 06:53:18","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 06:53:18","2021-06-26 06:53:18","","12","http://localhost/wordpress/?p=62","0","revision","","0"),
("63","1","2021-06-26 06:54:28","2021-06-26 06:54:28","","contentcreation-photo","","inherit","open","closed","","contentcreation-photo","","","2021-06-26 06:54:28","2021-06-26 06:54:28","","12","http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo.png","0","attachment","image/png","0"),
("65","1","2021-06-26 07:02:16","2021-06-26 07:02:16","","download","","inherit","open","closed","","download","","","2021-06-26 07:02:16","2021-06-26 07:02:16","","12","http://localhost/wordpress/wp-content/uploads/2021/06/download.png","0","attachment","image/png","0"),
("66","1","2021-06-26 07:04:09","2021-06-26 07:04:09","","download-1","","inherit","open","closed","","download-1","","","2021-06-26 07:04:09","2021-06-26 07:04:09","","12","http://localhost/wordpress/wp-content/uploads/2021/06/download-1.png","0","attachment","image/png","0"),
("67","1","2021-06-26 07:07:47","2021-06-26 07:07:47","","contentcreation-photo-1","","inherit","open","closed","","contentcreation-photo-1","","","2021-06-26 07:07:47","2021-06-26 07:07:47","","12","http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png","0","attachment","image/png","0"),
("68","1","2021-06-26 07:08:54","2021-06-26 07:08:54","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":66,\"width\":58,\"height\":63,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-1.png\" alt=\"\" class=\"wp-image-66\" width=\"58\" height=\"63\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"align\":\"full\"} -->
<h2 class=\"alignfull\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:08:54","2021-06-26 07:08:54","","12","http://localhost/wordpress/?p=68","0","revision","","0"),
("69","1","2021-06-26 07:09:26","2021-06-26 07:09:26","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"align\":\"full\"} -->
<h2 class=\"alignfull\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:09:26","2021-06-26 07:09:26","","12","http://localhost/wordpress/?p=69","0","revision","","0"),
("70","1","2021-06-26 07:10:01","2021-06-26 07:10:01","","download-2","","inherit","open","closed","","download-2","","","2021-06-26 07:10:01","2021-06-26 07:10:01","","12","http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png","0","attachment","image/png","0"),
("72","1","2021-06-26 07:10:31","2021-06-26 07:10:31","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":70,\"width\":49,\"height\":53,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png\" alt=\"\" class=\"wp-image-70\" width=\"49\" height=\"53\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"textAlign\":\"right\",\"align\":\"full\"} -->
<h2 class=\"alignfull has-text-align-right\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:10:31","2021-06-26 07:10:31","","12","http://localhost/wordpress/?p=72","0","revision","","0"),
("73","1","2021-06-26 07:10:44","2021-06-26 07:10:44","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":70,\"width\":49,\"height\":53,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png\" alt=\"\" class=\"wp-image-70\" width=\"49\" height=\"53\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"textAlign\":\"center\",\"align\":\"full\"} -->
<h2 class=\"alignfull has-text-align-center\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:10:44","2021-06-26 07:10:44","","12","http://localhost/wordpress/?p=73","0","revision","","0"),
("75","1","2021-06-26 07:11:05","2021-06-26 07:11:05","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":70,\"width\":49,\"height\":53,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png\" alt=\"\" class=\"wp-image-70\" width=\"49\" height=\"53\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"textAlign\":\"center\"} -->
<h2 class=\"has-text-align-center\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:11:05","2021-06-26 07:11:05","","12","http://localhost/wordpress/?p=75","0","revision","","0"),
("77","1","2021-06-26 07:19:33","2021-06-26 07:19:33","","seo-photo","","inherit","open","closed","","seo-photo","","","2021-06-26 07:19:33","2021-06-26 07:19:33","","12","http://localhost/wordpress/wp-content/uploads/2021/06/seo-photo.png","0","attachment","image/png","0"),
("78","1","2021-06-26 07:21:08","2021-06-26 07:21:08","","socialmedia-photo","","inherit","open","closed","","socialmedia-photo","","","2021-06-26 07:21:08","2021-06-26 07:21:08","","12","http://localhost/wordpress/wp-content/uploads/2021/06/socialmedia-photo.png","0","attachment","image/png","0"),
("79","1","2021-06-26 07:22:18","2021-06-26 07:22:18","<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->
<p style=\"font-size:34px\"><strong>SERVICES OF FULLMOON OUTDOOR WEB SOLUTIONS INC</strong></p>
<!-- /wp:paragraph -->

<!-- wp:separator {\"align\":\"center\",\"className\":\"is-style-wide\"} -->
<hr class=\"wp-block-separator aligncenter is-style-wide\"/>
<!-- /wp:separator -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}},\"textColor\":\"light-green-cyan\"} -->
<p class=\"has-light-green-cyan-color has-text-color\" style=\"font-size:30px\"><strong>WHAT DO WE DO?</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":32}}} -->
<p style=\"font-size:32px\"><strong>&lt;/> Web Development and Design</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":61,\"mediaLink\":\"http://localhost/wordpress/services/webdevelopment-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/webdevelopment-photo-1.png\" alt=\"\" class=\"wp-image-61 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>The core of&nbsp;<strong><a href=\"https://www.fullmoonwsi.com/\">Fullmoon Outdoor Web Solutions</a></strong>’ working process is found in the development and design aspect of website creation. The web development services we provide enable our clients to trust that their expected output is beyond just the aesthetics and visual appeal. Attention to detail and the conveyance of even the most basic information is not overlooked in our products.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Variety in web interface and layout are open to our clients to give them a broad set of ideas that best fits with their vision. At Fullmoon, we make sure to highlight our clients’ own unique brand, incorporating viable strategies into a precise method of information layout.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Design is highly integrated with web development at Fullmoon. Using the latest editing software like Adobe Photoshop and Camtasia Studio 8, Fullmoon believes in more than just visual appeal and display, but as well as easy direction and functionality for viewers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Developing websites with Fullmoon also gives our clients a chance to see the versatility in product usage. Navigation in devices is a significant factor we keep in mind when we build websites, establishing a more mobile friendly experience for viewers.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:columns {\"verticalAlignment\":null} -->
<div class=\"wp-block-columns\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:columns {\"verticalAlignment\":\"top\"} -->
<div class=\"wp-block-columns are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"66.66%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:66.66%\"><!-- wp:image {\"align\":\"right\",\"id\":70,\"width\":49,\"height\":53,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->
<div class=\"wp-block-image\"><figure class=\"alignright size-large is-resized\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/download-2.png\" alt=\"\" class=\"wp-image-70\" width=\"49\" height=\"53\"/></figure></div>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {\"verticalAlignment\":\"top\",\"width\":\"33.33%\"} -->
<div class=\"wp-block-column is-vertically-aligned-top\" style=\"flex-basis:33.33%\"><!-- wp:heading {\"textAlign\":\"center\"} -->
<h2 class=\"has-text-align-center\">CONTENT CREATION</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:media-text {\"mediaId\":67,\"mediaLink\":\"http://localhost/wordpress/services/contentcreation-photo-1/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/contentcreation-photo-1.png\" alt=\"\" class=\"wp-image-67 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Content writing and creation highly depends on cohesion and structure when it comes to delivering quality output. Web development establishes a certain type of flair by integrating suitable content for various themed websites. Establishing well-written content for our clients’ websites also rely on the nature of every project’s main vision.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Fullmoon ensures all produced content fall into an element beyond an archetypal brand that suits every client’s business idea. Some of the mediums used in content production at Fullmoon include, articles, tutorials, reviews, entertainment&nbsp;<em>listicles</em>&nbsp;and videos that are all pieced together in a free flowing style that is geared towards every client’s main vision.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":30}}} -->
<p style=\"font-size:30px\"><strong>SEO MARKETING AND MANAGEMENT</strong></p>
<!-- /wp:paragraph -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":77,\"mediaLink\":\"http://localhost/wordpress/services/seo-photo/\",\"mediaType\":\"image\",\"mediaWidth\":28} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\" style=\"grid-template-columns:auto 28%\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/seo-photo.png\" alt=\"\" class=\"wp-image-77 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph -->
<p>To institute a level of consistency in web development, Fullmoon subscribes to the effective marketing strategy of Search Engine Optimization (SEO). SEO marketing helps clients use proper analytics to boost website performance as a core advantage in website maintenance. Clients count on us to deal with the technical side of website optimization, as well as the coordination of web content.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Another fundamental aspect emphasized by Fullmoon’s SEO team, is the continuous process of establishing an online community for our client’s products through backlink building. SEO managers at Fullmoon go through a great amount of effort when it comes to keyword research, market analysis and daily content optimization.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>SEO managers at Fullmoon make use of not only effective, but excellent optimization tools which include AdMob by Google, Links Management, Blackhat Links, and Traffic Junky among many others.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:heading {\"textAlign\":\"right\"} -->
<h2 class=\"has-text-align-right\">SOCIAL MEDIA MANAGEMENT</h2>
<!-- /wp:heading -->

<!-- wp:media-text {\"mediaId\":78,\"mediaLink\":\"http://localhost/wordpress/services/socialmedia-photo/\",\"mediaType\":\"image\",\"mediaWidth\":27} -->
<div class=\"wp-block-media-text alignwide is-stacked-on-mobile\" style=\"grid-template-columns:27% auto\"><figure class=\"wp-block-media-text__media\"><img src=\"http://localhost/wordpress/wp-content/uploads/2021/06/socialmedia-photo.png\" alt=\"\" class=\"wp-image-78 size-full\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">At Fullmoon, sustaining the process and developmental structure of every website created and optimized is supported by the social media manager. Facebook, Google Plus, LinkedIn and Twitter are some of the social media accounts we use and recommend to our clients.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Applying the basics of digital marketing in managing social media accounts is best delivered with various online strategies we offer our clients. Overseeing every post and profile online is vital in highlighting brand essentials.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">Social media management also entails identifying target audience, interacting with followers and cultivating promotion and engagement strategy with what the client wants to convey in their profiles and what their followers adhere to. At Fullmoon, our social media strategist works hand in hand with the SEO manager to flawlessly keep operations smooth for our clients.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->","Services","","inherit","closed","closed","","12-revision-v1","","","2021-06-26 07:22:18","2021-06-26 07:22:18","","12","http://localhost/wordpress/?p=79","0","revision","","0"),
("80","1","2021-06-26 07:23:55","2021-06-26 07:23:55","{
    \"sidebars_widgets[sinatra-footer-1]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:23:55\"
    },
    \"sinatra::sinatra_enable_footer\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:23:55\"
    }
}","","","trash","closed","closed","","95543ce9-561f-40ac-be6a-a430f460d6cc","","","2021-06-26 07:23:55","2021-06-26 07:23:55","","0","http://localhost/wordpress/?p=80","0","customize_changeset","","0"),
("81","1","2021-06-26 07:35:26","2021-06-26 07:35:26","{
    \"sinatra::sinatra_header_heading_widgets\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:31:05\"
    },
    \"sinatra::sinatra_copyright_heading_widgets\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:31:05\"
    },
    \"sinatra::sinatra_copyright_heading_design_options\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:31:05\"
    },
    \"custom_css[sinatra]\": {
        \"value\": \".page-header.si-has-page-title.si-has-breadcrumbs{\\n\\tdisplay: none;\\n\\t\\n}\\n\\n.imprint{\\nvisibility: hidden;\\nposition: relative;\\n}\\n\\n.imprint:after {\\nvisibility: visible;\\nposition: absolute;\\ntop: 0;\\nleft: 0;\\ncontent: \\\"Mywebsolutions:)\\\";\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:35:26\"
    }
}","","","trash","closed","closed","","a16f0820-c0db-4763-a181-41a5023daffa","","","2021-06-26 07:35:26","2021-06-26 07:35:26","","0","http://localhost/wordpress/?p=81","0","customize_changeset","","0"),
("82","1","2021-06-26 07:35:26","2021-06-26 07:35:26",".page-header.si-has-page-title.si-has-breadcrumbs{
	display: none;
	
}

.imprint{
visibility: hidden;
position: relative;
}

.imprint:after {
visibility: visible;
position: absolute;
top: 0;
left: 0;
content: \"Mywebsolutions:)\";
}","sinatra","","inherit","closed","closed","","52-revision-v1","","","2021-06-26 07:35:26","2021-06-26 07:35:26","","52","http://localhost/wordpress/?p=82","0","revision","","0"),
("83","1","2021-06-26 07:38:28","2021-06-26 07:38:28","{
    \"custom_css[sinatra]\": {
        \"value\": \".page-header.si-has-page-title.si-has-breadcrumbs{\\n\\tdisplay: none;\\n\\t\\n}\\n\\n.imprint{\\nvisibility: hidden;\\nposition: relative;\\n}\\n\\n.imprint:after {\\nvisibility: visible;\\nposition: absolute;\\ntop: 0;\\nleft: 0;\\ncontent: \\\"Mywebsolutions:)\\\";\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2021-06-26 07:38:19\"
    }
}","","","trash","closed","closed","","54f5359e-d335-4c65-92de-1033bef2569f","","","2021-06-26 07:38:28","2021-06-26 07:38:28","","0","http://localhost/wordpress/?p=83","0","customize_changeset","","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_snippets` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_snippets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tags` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scope` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `priority` smallint(6) NOT NULL DEFAULT 10,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_snippets VALUES
("1","Example HTML shortcode","This is an example snippet for demonstrating how to add an HTML shortcode.

You can remove it, or edit it to add your own content.","
add_shortcode( \'shortcode_name\', function () {

	$out = \'<p>write your HTML shortcode content here</p>\';

	return $out;
} );","shortcode","global","10","0","2021-06-26 04:13:27"),
("2","Example CSS snippet","This is an example snippet for demonstrating how to add custom CSS code to your website.

You can remove it, or edit it to add your own content.","
add_action( \'wp_head\', function () { ?>
<style>

	/* write your CSS code here */

</style>
<?php } );
","css","front-end","10","0","2021-06-26 04:13:27"),
("3","Example JavaScript snippet","This is an example snippet for demonstrating how to add custom JavaScript code to your website.

You can remove it, or edit it to add your own content.","
add_action( \'wp_head\', function () { ?>
<script>

	/* write your JavaScript code here */

</script>
<?php } );
","javascript","front-end","10","0","2021-06-26 04:13:27"),
("4","Order snippets by name","Order snippets by name by default in the snippets table.","
add_filter( \'code_snippets/list_table/default_orderby\', function () {
	return \'name\';
} );
","code-snippets-plugin","admin","10","0","2021-06-26 04:13:28"),
("5","Order snippets by date","Order snippets by last modification date by default in the snippets table.","
add_filter( \'code_snippets/list_table/default_orderby\', function () {
	return \'modified\';
} );

add_filter( \'code_snippets/list_table/default_order\', function () {
	return \'desc\';
} );
","code-snippets-plugin","admin","10","0","2021-06-26 04:13:28");/*END*/




DROP TABLE IF EXISTS `webtoffee_term_relationships` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_term_relationships VALUES
("1","1","0"),
("19","2","0"),
("20","2","0"),
("21","2","0"),
("22","2","0"),
("24","2","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_term_taxonomy` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_term_taxonomy VALUES
("1","1","category","","0","1"),
("2","2","nav_menu","","0","5");/*END*/




DROP TABLE IF EXISTS `webtoffee_termmeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/






DROP TABLE IF EXISTS `webtoffee_terms` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_terms VALUES
("1","Uncategorized","uncategorized","0"),
("2","Menu 1","menu-1","0");/*END*/




DROP TABLE IF EXISTS `webtoffee_usermeta` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_usermeta VALUES
("1","1","nickname","admin"),
("2","1","first_name",""),
("3","1","last_name",""),
("4","1","description",""),
("5","1","rich_editing","true"),
("6","1","syntax_highlighting","true"),
("7","1","comment_shortcuts","false"),
("8","1","admin_color","fresh"),
("9","1","use_ssl","0"),
("10","1","show_admin_bar_front","true"),
("11","1","locale",""),
("12","1","webtoffee_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
("13","1","webtoffee_user_level","10"),
("14","1","dismissed_wp_pointers","theme_editor_notice"),
("15","1","show_welcome_panel","1"),
("16","1","session_tokens","a:1:{s:64:\"4b64d6d7916ba054cb6f87bfd6ed3222cf338e78d0f13ed6fbaeb23111911061\";a:4:{s:10:\"expiration\";i:1624702110;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36\";s:5:\"login\";i:1624529310;}}"),
("17","1","webtoffee_dashboard_quick_press_last_post_id","4"),
("18","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}"),
("19","1","metaboxhidden_nav-menus","a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}"),
("20","1","webtoffee_user-settings","libraryContent=browse"),
("21","1","webtoffee_user-settings-time","1624540873"),
("22","1","nav_menu_recently_edited","2");/*END*/




DROP TABLE IF EXISTS `webtoffee_users` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;/*END*/


INSERT INTO webtoffee_users VALUES
("1","admin","$P$BqIhmEQlU5M83r8k1xCTcz8DMMVxbI1","admin","admin@gmail.com","http://localhost/wordpress","2021-06-24 10:07:14","","0","admin");/*END*/




DROP TABLE IF EXISTS `webtoffee_wt_mgdp_ftp` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_wt_mgdp_ftp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `server` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `port` int(11) NOT NULL DEFAULT 21,
  `export_path` varchar(255) NOT NULL,
  `import_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/*END*/






DROP TABLE IF EXISTS `webtoffee_wtmgdp_log` ;/*END*/ 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";/*END*/
SET time_zone = "+00:00";/*END*/


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;/*END*/
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;/*END*/
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;/*END*/
/*!40101 SET NAMES utf8 */;/*END*/
--
-- Database: `wordpress_tutorial`
--




CREATE TABLE `webtoffee_wtmgdp_log` (
  `id_wtmgdp_log` int(11) NOT NULL AUTO_INCREMENT,
  `log_name` varchar(200) NOT NULL,
  `log_data` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `log_type` varchar(200) NOT NULL,
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_wtmgdp_log`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/*END*/


INSERT INTO webtoffee_wtmgdp_log VALUES
("1","2021-06-26 08:18:21 AM","{\"tables\":[\"wp_commentmeta\",\"wp_comments\",\"wp_links\",\"wp_ms_snippets\",\"wp_options\",\"wp_postmeta\",\"wp_posts\",\"wp_snippets\",\"wp_term_relationships\",\"wp_term_taxonomy\",\"wp_termmeta\",\"wp_terms\",\"wp_usermeta\",\"wp_users\",\"wp_wt_mgdp_ftp\",\"wp_wtmgdp_log\"],\"files\":[\"index.php\"],\"dirs\":[\"migrator_database\",\"plugins\",\"themes\",\"upgrade\",\"uploads\"],\"find\":[\"\",\"webtoffee_capabilities\",\"webtoffee_user_level\",\"webtoffee_user-settings\",\"webtoffee_user-settings-time\",\"webtoffee_dashboard_quick_press_last_post_id\",\"webtoffee_user_roles\"],\"replace\":[\"\",\"webtoffee_capabilities\",\"webtoffee_user_level\",\"webtoffee_user-settings\",\"webtoffee_user-settings-time\",\"webtoffee_dashboard_quick_press_last_post_id\",\"webtoffee_user_roles\"],\"backup_file\":\"2021-06-26-08-18-21am.zip\"}","2","export","1624695501","1624695501");/*END*/


